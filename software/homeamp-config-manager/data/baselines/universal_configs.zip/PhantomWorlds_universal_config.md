# PhantomWorlds Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
advancedSettings.advanced.file-version: 1
advancedSettings.advanced.generated-with: ${project.version}
data.advanced.file-version: 2
data.advanced.generated-with: ${project.version}
data.worlds-to-load: None
settings.advanced.file-version: 7
settings.advanced.generated-with: ${project.version}
settings.backup-delay: 600
settings.backup-scheduler: False
settings.delete-archive: True
settings.import-auto: True
settings.regenerate-missing-worlds: False
settings.run-update-checker: True
settings.spawning.change: False
settings.spawning.default-first: True
settings.spawning.default-world: world
settings.spawning.respawn-always: True
settings.spawning.respawn-default-world: False
settings.spawning.respawn-world: True
```
