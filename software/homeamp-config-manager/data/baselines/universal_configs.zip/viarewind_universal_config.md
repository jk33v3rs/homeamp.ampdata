# viarewind Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
config: {'always-show-original-mob-name': True, 'cooldown-indicator': 'TITLE', 'emulate-levitation-effect': True, 'emulate-world-border': True, 'enable-offhand': True, 'handle-player-combat-packet': True, 'max-book-page-length': 5000, 'max-book-pages': 100, 'offhand-command': '/offhand', 'replace-adventure': False, 'replace-particles': False, 'world-border-particle': 'fireworksSpark'}
```
