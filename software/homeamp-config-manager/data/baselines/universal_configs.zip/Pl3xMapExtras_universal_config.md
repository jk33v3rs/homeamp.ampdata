# Pl3xMapExtras - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Marker

`marker.banners` = true

`marker.claims` = true

`marker.mobs` = true

`marker.signs` = true

`marker.warps` = true

## Messages

`messages.help-message` = ['{prefix} <red>/pl3xmapextras reload <gray>- <white>reloads the plugin.', '{prefix} <red>/pl3xmapextras help <gray>- <white>shows this menu.']

`messages.no-permission` = "{prefix} <red>You do not have permission to perform this command."

`messages.prefix` = "<gray>[<red>Pl3xMapExtras<gray>]"

`messages.reloaded-plugin` = "{prefix} <green>You have reloaded the plugin."

