# ExcellentChallenges - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Challenges

`Challenges.Action_Types.block_break.DisplayName` = "Block Break"

`Challenges.Action_Types.block_break.Enabled` = true

`Challenges.Action_Types.block_break.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.block_break.Icon.SkinURL` = "1e1d4bc469d29d22a7ef6d21a61b451291f21bf51fd167e7fd07b719512e87a1"

`Challenges.Action_Types.block_fertilize.DisplayName` = "Block Fertilize"

`Challenges.Action_Types.block_fertilize.Enabled` = true

`Challenges.Action_Types.block_fertilize.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.block_fertilize.Icon.SkinURL` = "b451845943fd0c07f629711e3401a71a31cd371cc3cb36f3f9637b0e759cc48a"

`Challenges.Action_Types.block_place.DisplayName` = "Block Place"

`Challenges.Action_Types.block_place.Enabled` = true

`Challenges.Action_Types.block_place.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.block_place.Icon.SkinURL` = "c0d20f6033a58626841c80dc25e604fc22f8dba8eadad7de921330ff26e1659c"

`Challenges.Action_Types.breed_entity.DisplayName` = "Breed Entity"

`Challenges.Action_Types.breed_entity.Enabled` = true

`Challenges.Action_Types.breed_entity.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.breed_entity.Icon.SkinURL` = "319b7fcd8ab72e293edbdb1c615d658908d2ed354880eb6964634a4657898c60"

`Challenges.Action_Types.brew_potion.DisplayName` = "Brew Potion"

`Challenges.Action_Types.brew_potion.Enabled` = true

`Challenges.Action_Types.brew_potion.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.brew_potion.Icon.SkinURL` = "93a728ad8d31486a7f9aad200edb373ea803d1fc5fd4321b2e2a971348234443"

`Challenges.Action_Types.consume_item.DisplayName` = "Consume Item"

`Challenges.Action_Types.consume_item.Enabled` = true

`Challenges.Action_Types.consume_item.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.consume_item.Icon.SkinURL` = "10d71fe099e8bee600213ade9e38bc3b9217dd1dc3b44aab414635bcb68ac548"

`Challenges.Action_Types.craft_item.DisplayName` = "Craft Item"

`Challenges.Action_Types.craft_item.Enabled` = true

`Challenges.Action_Types.craft_item.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.craft_item.Icon.SkinURL` = "4c36045208f9b5ddcf8c4433e424b1ca17b94f6b96202fb1e5270ee8d53881b1"

`Challenges.Action_Types.disenchant_item.DisplayName` = "Disenchant Item"

`Challenges.Action_Types.disenchant_item.Enabled` = true

`Challenges.Action_Types.disenchant_item.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.disenchant_item.Icon.SkinURL` = "8e99bfa61fe552f1e6636b03fbe40f4e470c3b3cb14f70e9012813790ead568f"

`Challenges.Action_Types.drink_potion.DisplayName` = "Drink Potion"

`Challenges.Action_Types.drink_potion.Enabled` = true

`Challenges.Action_Types.drink_potion.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.drink_potion.Icon.SkinURL` = "5522185926708535dc2dd6024cdde8317ec350e74c3ca3645e9902b2c7870ba5"

`Challenges.Action_Types.enchant_item.DisplayName` = "Enchant Item"

`Challenges.Action_Types.enchant_item.Enabled` = true

`Challenges.Action_Types.enchant_item.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.enchant_item.Icon.SkinURL` = "b2f79016cad84d1ae21609c4813782598e387961be13c15682752f126dce7a"

`Challenges.Action_Types.fish_item.DisplayName` = "Fish Item"

`Challenges.Action_Types.fish_item.Enabled` = true

`Challenges.Action_Types.fish_item.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.fish_item.Icon.SkinURL` = "1352df85a02d7fac5dca72dfbc6ba8ac0a7f96208bc8048247791ef2216f5c94"

`Challenges.Action_Types.get_enchant.DisplayName` = "Get Enchant"

`Challenges.Action_Types.get_enchant.Enabled` = true

`Challenges.Action_Types.get_enchant.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.get_enchant.Icon.SkinURL` = "b62651879d870499da50e34036800ddffd52f3e4e1993c5fc0fc825d03446d8b"

`Challenges.Action_Types.inflict_damage.DisplayName` = "Inflict Damage"

`Challenges.Action_Types.inflict_damage.Enabled` = true

`Challenges.Action_Types.inflict_damage.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.inflict_damage.Icon.SkinURL` = "ea5fb227a87a953e7225fbe6c1f4fb4884d9c023c1906654b8dca3a9290a54d3"

`Challenges.Action_Types.kill_entity.DisplayName` = "Kill Entity"

`Challenges.Action_Types.kill_entity.Enabled` = true

`Challenges.Action_Types.kill_entity.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.kill_entity.Icon.SkinURL` = "783aaaee22868cafdaa1f6f4a0e56b0fdb64cd0aeaabd6e83818c312ebe66437"

`Challenges.Action_Types.launch_projectile.DisplayName` = "Launch Projectile"

`Challenges.Action_Types.launch_projectile.Enabled` = true

`Challenges.Action_Types.launch_projectile.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.launch_projectile.Icon.SkinURL` = "1dfd7724c69a024dcfc60b16e00334ab5738f4a92bafb8fbc76cf15322ea0293"

`Challenges.Action_Types.receive_damage.DisplayName` = "Receive Damage"

`Challenges.Action_Types.receive_damage.Enabled` = true

`Challenges.Action_Types.receive_damage.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.receive_damage.Icon.SkinURL` = "f25def6560cacfeeaa03886e525324ddddae49eb6eb749dc6df207ca3a135ad5"

`Challenges.Action_Types.remove_enchant.DisplayName` = "Remove Enchant"

`Challenges.Action_Types.remove_enchant.Enabled` = true

`Challenges.Action_Types.remove_enchant.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.remove_enchant.Icon.SkinURL` = "8e99bfa61fe552f1e6636b03fbe40f4e470c3b3cb14f70e9012813790ead568f"

`Challenges.Action_Types.rename_item.DisplayName` = "Rename Item"

`Challenges.Action_Types.rename_item.Enabled` = true

`Challenges.Action_Types.rename_item.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.rename_item.Icon.SkinURL` = "692d5df805c239022fe1b45f940882bf40b559671937dc71fbc96f630250ebc4"

`Challenges.Action_Types.repair_item.DisplayName` = "Repair Item"

`Challenges.Action_Types.repair_item.Enabled` = true

`Challenges.Action_Types.repair_item.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.repair_item.Icon.SkinURL` = "55fddec36655d3b371c79d6113354877577089c1fcb1b3d8e00af32612f26f28"

`Challenges.Action_Types.shear_entity.DisplayName` = "Shear Entity"

`Challenges.Action_Types.shear_entity.Enabled` = true

`Challenges.Action_Types.shear_entity.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.shear_entity.Icon.SkinURL` = "a723893df4cfb9c7240fc47b560ccf6ddeb19da9183d33083f2c71f46dad290a"

`Challenges.Action_Types.shoot_entity.DisplayName` = "Shoot Entity"

`Challenges.Action_Types.shoot_entity.Enabled` = true

`Challenges.Action_Types.shoot_entity.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.shoot_entity.Icon.SkinURL` = "c787b7afb5a59953975bba2473749b601d54d6f93ceac7a02ac69aae7f9b8"

`Challenges.Action_Types.smelt_item.DisplayName` = "Smelt Item"

`Challenges.Action_Types.smelt_item.Enabled` = true

`Challenges.Action_Types.smelt_item.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.smelt_item.Icon.SkinURL` = "53bf0b8859a1e57f3abd629c0c736e644e81651d4de034feea49f883f00e82b0"

`Challenges.Action_Types.tame_entity.DisplayName` = "Tame Entity"

`Challenges.Action_Types.tame_entity.Enabled` = true

`Challenges.Action_Types.tame_entity.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.tame_entity.Icon.SkinURL` = "28d408842e76a5a454dc1c7e9ac5c1a8ac3f4ad34d6973b5275491dff8c5c251"

`Challenges.Action_Types.trade_item.DisplayName` = "Trade Item"

`Challenges.Action_Types.trade_item.Enabled` = true

`Challenges.Action_Types.trade_item.Icon.Material` = "PLAYER_HEAD"

`Challenges.Action_Types.trade_item.Icon.SkinURL` = "7e5995106d080f10b2052de08e355f34a2213904d9d32f6dc2d1b27bec753b74"

`Challenges.Difficulties.childish.Levels.Max` = 10

`Challenges.Difficulties.childish.Levels.Min` = 1

`Challenges.Difficulties.childish.Modifiers.conditions_amount.Base` = 0.0

`Challenges.Difficulties.childish.Modifiers.conditions_amount.Per_Level` = 0.0

`Challenges.Difficulties.childish.Modifiers.objective_amount.Base` = 0.0

`Challenges.Difficulties.childish.Modifiers.objective_amount.Per_Level` = 0.0

`Challenges.Difficulties.childish.Modifiers.objective_progress.Base` = 1.05

`Challenges.Difficulties.childish.Modifiers.objective_progress.Per_Level` = 0.05

`Challenges.Difficulties.childish.Modifiers.rewards_amount.Base` = 0.0

`Challenges.Difficulties.childish.Modifiers.rewards_amount.Per_Level` = 0.0

`Challenges.Difficulties.childish.Name` = "Childish"

`Challenges.Difficulties.easy.Levels.Max` = 20

`Challenges.Difficulties.easy.Levels.Min` = 11

`Challenges.Difficulties.easy.Modifiers.conditions_amount.Base` = 0.0

`Challenges.Difficulties.easy.Modifiers.conditions_amount.Per_Level` = 0.0

`Challenges.Difficulties.easy.Modifiers.objective_amount.Base` = 0.0

`Challenges.Difficulties.easy.Modifiers.objective_amount.Per_Level` = 0.05

`Challenges.Difficulties.easy.Modifiers.objective_progress.Base` = 1.25

`Challenges.Difficulties.easy.Modifiers.objective_progress.Per_Level` = 0.05

`Challenges.Difficulties.easy.Modifiers.rewards_amount.Base` = 0.0

`Challenges.Difficulties.easy.Modifiers.rewards_amount.Per_Level` = 0.0

`Challenges.Difficulties.easy.Name` = "Easy"

`Challenges.Difficulties.extreme.Levels.Max` = 50

`Challenges.Difficulties.extreme.Levels.Min` = 41

`Challenges.Difficulties.extreme.Modifiers.conditions_amount.Base` = 0.0

`Challenges.Difficulties.extreme.Modifiers.conditions_amount.Per_Level` = 0.0

`Challenges.Difficulties.extreme.Modifiers.objective_amount.Base` = 0.0

`Challenges.Difficulties.extreme.Modifiers.objective_amount.Per_Level` = 0.05

`Challenges.Difficulties.extreme.Modifiers.objective_progress.Base` = 5.0

`Challenges.Difficulties.extreme.Modifiers.objective_progress.Per_Level` = 0.3

`Challenges.Difficulties.extreme.Modifiers.rewards_amount.Base` = 0.0

`Challenges.Difficulties.extreme.Modifiers.rewards_amount.Per_Level` = 0.04

`Challenges.Difficulties.extreme.Name` = "Extreme"

`Challenges.Difficulties.hard.Levels.Max` = 40

`Challenges.Difficulties.hard.Levels.Min` = 21

`Challenges.Difficulties.hard.Modifiers.conditions_amount.Base` = 0.0

`Challenges.Difficulties.hard.Modifiers.conditions_amount.Per_Level` = 0.0

`Challenges.Difficulties.hard.Modifiers.objective_amount.Base` = 0.0

`Challenges.Difficulties.hard.Modifiers.objective_amount.Per_Level` = 0.05

`Challenges.Difficulties.hard.Modifiers.objective_progress.Base` = 4.0

`Challenges.Difficulties.hard.Modifiers.objective_progress.Per_Level` = 0.2

`Challenges.Difficulties.hard.Modifiers.rewards_amount.Base` = 0.0

`Challenges.Difficulties.hard.Modifiers.rewards_amount.Per_Level` = 0.04

`Challenges.Difficulties.hard.Name` = "Hard"

`Challenges.Difficulties.medium.Levels.Max` = 30

`Challenges.Difficulties.medium.Levels.Min` = 21

`Challenges.Difficulties.medium.Modifiers.conditions_amount.Base` = 0.0

`Challenges.Difficulties.medium.Modifiers.conditions_amount.Per_Level` = 0.0

`Challenges.Difficulties.medium.Modifiers.objective_amount.Base` = 0.0

`Challenges.Difficulties.medium.Modifiers.objective_amount.Per_Level` = 0.05

`Challenges.Difficulties.medium.Modifiers.objective_progress.Base` = 2.0

`Challenges.Difficulties.medium.Modifiers.objective_progress.Per_Level` = 0.1

`Challenges.Difficulties.medium.Modifiers.rewards_amount.Base` = 0.0

`Challenges.Difficulties.medium.Modifiers.rewards_amount.Per_Level` = 0.04

`Challenges.Difficulties.medium.Name` = "Medium"

`Challenges.Reroll.Condition` = "ANYTIME"

`Challenges.Reroll.Enabled` = true

`Challenges.Types.daily.Amount_Per_Rank.Default_Value` = 5

`Challenges.Types.daily.Amount_Per_Rank.Mode` = "RANK"

`Challenges.Types.daily.Amount_Per_Rank.Permission_Prefix` = "excellentchallenges.amount.daily."

`Challenges.Types.daily.Amount_Per_Rank.Values.donor` = 7

`Challenges.Types.daily.Completion_Rewards` = []

`Challenges.Types.daily.Difficulties.childish` = 70.0

`Challenges.Types.daily.Difficulties.easy` = 50.0

`Challenges.Types.daily.Difficulties.medium` = 25.0

`Challenges.Types.daily.Excluded_Generators` = []

`Challenges.Types.daily.Icon.Material` = "PLAYER_HEAD"

`Challenges.Types.daily.Icon.SkinURL` = "68ac632e7b2d20c9cce5cc9e6486a7dfd933aeeb3513febd232031e0e758b00e"

`Challenges.Types.daily.Milestones.15.Repeatable` = true

`Challenges.Types.daily.Milestones.15.Rewards` = ['reward_1', 'reward_2']

`Challenges.Types.daily.Milestones.5.Repeatable` = false

`Challenges.Types.daily.Milestones.5.Rewards` = ['reward_1', 'reward_2']

`Challenges.Types.daily.Name` = "Daily"

`Challenges.Types.daily.Refresh_Time` = 86400

`Challenges.Types.daily.Unique_Types` = true

`Challenges.Types.monthly.Amount_Per_Rank.Default_Value` = 5

`Challenges.Types.monthly.Amount_Per_Rank.Mode` = "RANK"

`Challenges.Types.monthly.Amount_Per_Rank.Permission_Prefix` = "excellentchallenges.amount.monthly."

`Challenges.Types.monthly.Amount_Per_Rank.Values.donor` = 7

`Challenges.Types.monthly.Completion_Rewards` = []

`Challenges.Types.monthly.Difficulties.extreme` = 80.0

`Challenges.Types.monthly.Difficulties.hard` = 50.0

`Challenges.Types.monthly.Difficulties.medium` = 35.0

`Challenges.Types.monthly.Excluded_Generators` = []

`Challenges.Types.monthly.Icon.Material` = "PLAYER_HEAD"

`Challenges.Types.monthly.Icon.SkinURL` = "930423127bb0269c508333c6966578c1317db3368c1fbd0503dc38b642c5d193"

`Challenges.Types.monthly.Milestones.15.Repeatable` = true

`Challenges.Types.monthly.Milestones.15.Rewards` = ['reward_1', 'reward_2']

`Challenges.Types.monthly.Milestones.5.Repeatable` = false

`Challenges.Types.monthly.Milestones.5.Rewards` = ['reward_1', 'reward_2']

`Challenges.Types.monthly.Name` = "Monthly"

`Challenges.Types.monthly.Refresh_Time` = 2628288

`Challenges.Types.monthly.Unique_Types` = true

`Challenges.Types.weekly.Amount_Per_Rank.Default_Value` = 5

`Challenges.Types.weekly.Amount_Per_Rank.Mode` = "RANK"

`Challenges.Types.weekly.Amount_Per_Rank.Permission_Prefix` = "excellentchallenges.amount.weekly."

`Challenges.Types.weekly.Amount_Per_Rank.Values.donor` = 7

`Challenges.Types.weekly.Completion_Rewards` = []

`Challenges.Types.weekly.Difficulties.easy` = 25.0

`Challenges.Types.weekly.Difficulties.extreme` = 15.0

`Challenges.Types.weekly.Difficulties.hard` = 50.0

`Challenges.Types.weekly.Difficulties.medium` = 60.0

`Challenges.Types.weekly.Excluded_Generators` = []

`Challenges.Types.weekly.Icon.Material` = "PLAYER_HEAD"

`Challenges.Types.weekly.Icon.SkinURL` = "a93dfb3ae8177784a645779dca2c12dfba1258c202afdc04d87d80f2cecea1d7"

`Challenges.Types.weekly.Milestones.15.Repeatable` = true

`Challenges.Types.weekly.Milestones.15.Rewards` = ['reward_1', 'reward_2']

`Challenges.Types.weekly.Milestones.5.Repeatable` = false

`Challenges.Types.weekly.Milestones.5.Rewards` = ['reward_1', 'reward_2']

`Challenges.Types.weekly.Name` = "Weekly"

`Challenges.Types.weekly.Refresh_Time` = 604800

`Challenges.Types.weekly.Unique_Types` = true

## Database

`Database.MySQL.Options` = "?allowPublicKeyRetrieval=true&useSSL=false"

`Database.Purge.Enabled` = false

`Database.Purge.For_Period` = 60

`Database.SQLite.FileName` = "data.db"

`Database.UserData.Cache_LifeTime` = 300

`Database.UserData.Scheduled_Save_Sync_Pause` = 3

## Objectives

`Objectives.Anti_Glitch.Track_Player_Blocks` = true

