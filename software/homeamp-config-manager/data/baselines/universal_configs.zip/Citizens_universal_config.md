# Citizens - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Advanced

`advanced.check-minecraft-version` = true

## General

`general.authlib.profile-url` = "https://sessionserver.mojang.com/session/minecraft/profile/"

`general.color-scheme.message` = "<green>"

`general.color-scheme.message-error` = "<red>"

`general.color-scheme.message-highlight` = "<yellow>"

`general.debug-chunk-loads` = false

`general.debug-file` = ""

`general.debug-mode` = false

`general.experimental-list-storage` = false

`general.interop.protocollib` = true

`general.reload-warning-enabled` = true

`general.reset-formatting-on-color-change` = false

`general.resource-pack-path` = "plugins/Citizens/resourcepack"

`general.translation.locale` = ""

`general.wait-for-entity-spawn` = "1s"

## Npc

`npc.always-use-name-holograms` = false

`npc.chat.format.no-targets` = "[<npc>]: <text>"

`npc.chat.format.to-target` = "<npc>: <text>"

`npc.chat.format.with-target-to-bystanders` = "[<npc>] -> [<target>]: <text>"

`npc.chat.format.with-targets-to-bystanders` = "[<npc>] -> [<targets>]: <text>"

`npc.chat.options.bystanders-hear-targeted-chat` = false

`npc.chat.options.max-number-of-targets-to-show` = 2

`npc.chat.options.multiple-targets-format` = "<target>|, <target>| & <target>| & others"

`npc.chat.options.range` = 5

`npc.chat.options.talk-to-npcs` = true

`npc.chunks.always-keep-loaded` = false

`npc.commands.error-messages.global-maximum-times-used` = "You have reached the maximum number of uses ({0})."

`npc.commands.error-messages.maximum-times-used` = "You have reached the maximum number of uses ({0})."

`npc.commands.error-messages.missing-item` = "Missing {1} {0}"

`npc.commands.error-messages.no-permission` = "You don't have permission to do that."

`npc.commands.error-messages.not-enough-experience` = "You need at least {0} experience."

`npc.commands.error-messages.not-enough-money` = "You need at least ${0}."

`npc.commands.error-messages.on-cooldown` = "Please wait for {minutes} minutes and {seconds_over} seconds."

`npc.commands.error-messages.on-global-cooldown` = "Please wait for {minutes} minutes and {seconds_over} seconds."

`npc.commands.global-cooldown` = "1s"

`npc.controllable.ground-direction-modifier` = 1.0

`npc.controllable.max-flying-speed` = 0.75

`npc.controllable.max-ground-speed` = 0.5

`npc.controllable.use-boat-controls` = true

`npc.default.block-breaker-radius` = -1

`npc.default.bossbar-view-range` = 64

`npc.default.enable-scoreboard-teams` = true

`npc.default.look-close.disable-while-navigating` = true

`npc.default.look-close.enabled` = false

`npc.default.look-close.random-look-delay` = "3s"

`npc.default.look-close.random-look-enabled` = false

`npc.default.look-close.range` = 10

`npc.default.look-close.realistic-looking` = false

`npc.default.npc-cost` = 100.0

`npc.default.reset-yaw-on-spawn` = true

`npc.default.spawn-invincibility-duration` = "1s"

`npc.default.talk-close.enabled` = false

`npc.default.talk-close.random-talker` = false

`npc.default.talk-close.range` = 5

`npc.default.talk-close.text` = ["Hi, I'm <npc>!"]

`npc.default.waypoints.cache-paths` = false

`npc.delay-player-teleport` = -1

`npc.follow.teleport-across-worlds` = false

`npc.hologram.always-update-position` = false

`npc.hologram.default-background-color` = ""

`npc.hologram.default-line-height` = 0.4

`npc.hologram.default-renderer` = "display"

`npc.hologram.update-rate` = "1s"

`npc.limits.default-limit` = 10

`npc.limits.max-permission-checks` = 100

`npc.movement.water-speed-modifier` = 1.15

`npc.packets.update-delay` = 30

`npc.pathfinding.allowed-fall-distance` = -1

`npc.pathfinding.attack-range` = 1.75

`npc.pathfinding.debug-paths` = false

`npc.pathfinding.default-destination-teleport-margin` = -1

`npc.pathfinding.default-distance-margin` = 1

`npc.pathfinding.default-path-distance-margin` = 1

`npc.pathfinding.default-range-blocks` = 75.0

`npc.pathfinding.default-stationary-duration` = -1

`npc.pathfinding.default-stuck-action` = "none"

`npc.pathfinding.minecraft.disable-fallback-navigation` = true

`npc.pathfinding.minecraft.max-visited-blocks` = 1024

`npc.pathfinding.new-finder.check-bounding-boxes` = false

`npc.pathfinding.new-finder.iterations-per-tick` = 250

`npc.pathfinding.new-finder.maximum-iterations` = 1024

`npc.pathfinding.new-finder.open-doors` = false

`npc.pathfinding.pathfinder-type` = "MINECRAFT"

`npc.pathfinding.straight-line-targeting-distance` = 5

`npc.pathfinding.update-path-rate` = "1s"

`npc.player.remove-from-list` = true

`npc.selection.item` = "stick"

`npc.selection.message` = "Selected [[<npc>]] (ID [[<id>]])."

`npc.server-ownership` = false

`npc.shops.default-item.already-purchased-message` = ""

`npc.shops.default-item.click-to-confirm-message` = ""

`npc.shops.default-item.cost-message` = ""

`npc.shops.default-item.lore` = ""

`npc.shops.default-item.max-repeats-on-shift-click` = ""

`npc.shops.default-item.name` = ""

`npc.shops.default-item.result-message` = ""

`npc.shops.default-item.times-purchasable` = ""

`npc.shops.global-view-permission` = ""

`npc.skins.max-retries` = -1

`npc.skins.placeholder-update-frequency` = "5m"

`npc.skins.player-join-update-delay` = "1s"

`npc.skins.retry-delay` = "5s"

`npc.skins.rotation-update-degrees` = 90.0

`npc.skins.try-fetch-default-skin` = true

`npc.skins.use-latest-by-default` = false

`npc.skins.view-distance` = 100

`npc.tablist.disable` = true

`npc.tablist.remove-packet-delay` = "2t"

`npc.text.default-random-text-delay-max` = "10s"

`npc.text.default-random-text-delay-min` = "5s"

`npc.text.speech-bubble-duration` = "50t"

`npc.text.talk-item` = "*"

`npc.use-packet-holograms` = false

## Storage

`storage.file` = "saves.yml"

`storage.save-task-frequency` = "1hr"

