# QualityArmory - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Blockbullets

`BlockBullets.door` = false

`BlockBullets.glass` = false

`BlockBullets.halfslabs` = false

`BlockBullets.leaves` = false

`BlockBullets.water` = false

## Bulletdetection

`BulletDetection.step` = 0.1

## Defaultresourcepack

`DefaultResourcepack.0` = "https://github.com/ZombieStriker/QualityArmory-Resourcepack/releases/download/latest/QualityArmory.zip"

`DefaultResourcepack.21-4` = "https://github.com/ZombieStriker/QualityArmory-Resourcepack/releases/download/latest/QualityArmory-21.zip"

## General

`AUTO-UPDATE` = true

`Auto-Detect-Resourcepack` = true

`Break-Block-Texture-If-Shot` = true

`BulletTrailsSpacing` = 0.5

`DefaultResourcepackOverride` = false

`DestructableMaterials` = ['MATERIAL_NAME_HERE']

`ENABLE-DEBUG` = false

`EnableGlowEffects` = false

`EnableWeaponDurability` = false

`Enable_AutoArm_Grenades` = false

`Enable_Creation_Of_Default_Files` = true

`Enable_Headshot_Instantkill` = true

`Enable_Headshot_Notification_Sound` = true

`Enable_Hit_Sound` = false

`FriendlyFireEnabled` = false

`Headshot_Blacklist` = []

`Headshot_Notification_Sound` = "entity.experience_orb.pickup"

`Hit_Notification_Sound` = "entity.experience_orb.pickup"

`IronSightsOnRightClick` = false

`KickPlayerIfDeniedResourcepack` = false

`ManuallyOverrideTo_1_13_systems` = false

`ManuallyOverrideTo_1_14_systems` = false

`ManuallyOverrideTo_1_8_systems` = false

`Order-Shop-By-Price` = false

`RegenDestructableBlocksAfter` = -1

`SecondsTillRPIsSent` = 5.0

`Swap-Reload-and-Shooting-Controls` = false

`SwapSneakToSingleFire` = false

`allowGunHitEntities` = true

`allowGunReload` = true

`anticheatFix` = false

`automaticallyReloadGunWhenOutOfAmmo` = false

`enableBulletTrails` = true

`enableCrafting` = true

`enableExplosionDamage` = false

`enableExplosionDamageDrop` = false

`enableIgnoreArmorProtection` = false

`enableIgnoreSkipForBasegameItems` = false

`enableIgnoreUnbreakingChecks` = false

`enablePrimaryWeaponLimiter` = false

`enableRecoil` = true

`enableReloadOnlyWhenSwapToOffhand` = false

`enableReloadingOnDrop` = false

`enableReloadingWhenSwapToOffhand` = true

`enableShop` = true

`enable_lore_control-help_messages` = true

`enable_lore_gun-bullets` = false

`enable_lore_gun-info_messages` = true

`enable_permssionsToShoot` = false

`gravityConstantForDropoffCalculations` = 0.05

`impenetrableEntityTypes` = ['ARROW']

`language` = "en"

`overrideAnvil` = false

`overrideAttackSpeed` = true

`perWeaponPermission` = false

`preventGunsInHoppers` = true

`preventHiddenPlayers` = true

`resourcepackInvincibility` = false

`restoreOffHand` = false

`sendOnJoin` = true

`sendTitleOnJoin` = false

`showAmmoInXPBar` = false

`showOutOfAmmoOnTitle` = false

`showPossibleCrashHelpMessage` = true

`showReloadingTitle` = false

`unknownTranslationKeyFixer` = false

`useDefaultResourcepack` = true

`useMoveForRecoil` = true

`verboseItemLogging` = false

`weaponSwitchDelay` = 0.0

`weaponlimiter_primaries` = 2

`weaponlimiter_secondaries` = 2

## Items

`Items.enable_Unbreaking` = true

## Deathmessages

`deathmessages.enable` = true

## Disablehotbarmessages

`disableHotbarMessages.OutOfAmmo` = false

`disableHotbarMessages.Reload` = false

`disableHotbarMessages.Shoot` = false

## Enableinteract

`enableInteract.Chests` = false

## Experimental

`experimental.BulletWounds.BloodIncreasePerSecond` = 0.01

`experimental.BulletWounds.InitialBloodLevel` = 1500.0

`experimental.BulletWounds.Medkit_Heal_Bloodloss_Rate` = 0.05

`experimental.BulletWounds.enableBleeding` = false

## Generalmodifiers

`generalModifiers.sway.Ironsights` = 0.8

`generalModifiers.sway.Run` = 1.3

`generalModifiers.sway.Sneak` = 0.7

`generalModifiers.sway.Walk` = 1.5

