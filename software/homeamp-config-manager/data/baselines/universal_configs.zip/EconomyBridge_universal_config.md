# EconomyBridge - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`General.Disabled_Currencies` = ['currency1', 'currency2']

`General.Disabled_ItemHandlers` = ['CustomSuperItems', 'UltimateItemsPlugin']

`General.PlaceholderAPI_In_Format` = true

