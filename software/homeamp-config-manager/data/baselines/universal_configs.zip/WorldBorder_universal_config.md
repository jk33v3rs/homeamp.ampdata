# WorldBorder - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`bypass-list-uuids` = []

`cfg-version` = 11

`debug-mode` = false

`deny-enderpearl` = true

`dynmap-border-enabled` = true

`dynmap-border-hideByDefault` = false

`dynmap-border-message` = "The border of the world."

`dynmap-border-priority` = 0

`fill-autosave-frequency` = 30

`fill-memory-tolerance` = 500

`knock-back-dist` = 3.0

`message` = "&cYou have reached the edge of this world."

`player-killed-bad-spawn` = false

`portal-redirection` = true

`prevent-block-place` = false

`prevent-mob-spawn` = false

`remount-delay-ticks` = 0

`round-border` = true

`timer-delay-ticks` = 5

`whoosh-effect` = true

