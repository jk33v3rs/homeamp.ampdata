# floodgate Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
config.config-version: 3
config.disconnect.invalid-arguments-length: Expected {} arguments, got {}. Is Geyser up-to-date?
config.disconnect.invalid-key: Please connect through the official Geyser
config.key-file-name: asmp.pem
config.metrics.enabled: True
config.player-link.allowed: True
config.player-link.enable-global-linking: True
config.player-link.enable-own-linking: False
config.player-link.enabled: True
config.player-link.link-code-timeout: 300
config.player-link.require-link: False
config.player-link.type: sqlite
config.replace-spaces: True
config.send-floodgate-data: True
config.username-prefix: .
```
