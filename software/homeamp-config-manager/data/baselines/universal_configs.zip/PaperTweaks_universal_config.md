# PaperTweaks - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`enable-bstats` = true

## Database

`database.password` = "password"

`database.type` = "H2"

`database.user` = "user"

