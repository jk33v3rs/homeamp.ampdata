# GlowingItems - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`check-dropped-items` = true

`enabled` = true

`entity-scan-box-size` = 30

## Glowing_Materials

`glowing_materials.AMETHYST_CLUSTER.level` = 8

`glowing_materials.AMETHYST_SHARD.level` = 6

`glowing_materials.GLOWSTONE.level` = 15

`glowing_materials.GLOW_BERRIES.level` = 12

`glowing_materials.GLOW_INK_SAC.level` = 12

`glowing_materials.LANTERN.level` = 14

`glowing_materials.SEA_LANTERN.level` = 15

`glowing_materials.SOUL_LANTERN.level` = 10

`glowing_materials.SOUL_TORCH.level` = 10

`glowing_materials.TORCH.level` = 15

