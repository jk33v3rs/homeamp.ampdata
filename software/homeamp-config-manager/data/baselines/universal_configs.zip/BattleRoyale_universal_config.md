# BattleRoyale Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
config: {'Messages.Join': '&f Joined', 'Messages.Left': '&fleft the game.', 'Messages.Prefix': '&cBattleRoyale  &7>>&f', 'Messages.Start': '&fseconds before the game starts.', 'Messages.Started': '&fgame started, good luck.', 'Messages.WinGoal': '&fTo win you need to be the last one standing alive.', 'Messages.startIn1Minute': '&fGame starting in 1 minute.', 'Potion.Potion1': 10.0, 'Potion.Potion2': 20.0}
```
