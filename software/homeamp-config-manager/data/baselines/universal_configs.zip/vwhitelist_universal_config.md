# vwhitelist Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
config: {'database.host': '135.181.212.169', 'database.name': 'asmp_SQL', 'database.password': 'SQLdb2024!', 'database.port': 3369, 'database.username': 'sqlworkerSMP', 'discord.allowed_channels': ['1283860074699423897', '1283456419298803742'], 'discord.bot_token': 'MTMwNjEzMzAzMzQ1OTM4NDM1MA.GHarPi.ZrX2hBnSp2YDREt60zkAlidA4utBoa6_6VcY9M', 'discord.guild_id': '1280672118857662618', 'discord.required_roles': ['1286775757573460001', '1381052066109325342'], 'max_players_per_user': 3, 'validation.cleanup_interval_minutes': 5, 'validation.timeout_minutes': 10}
```
