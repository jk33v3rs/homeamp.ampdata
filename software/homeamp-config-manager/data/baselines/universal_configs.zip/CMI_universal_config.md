# CMI - Universal Configuration

These settings are **identical across all 17 Paper 1.21.8 servers** that use this plugin.

## Alert

`Alert.Timer` = 1440

## Animations

`Animations.CarpetsAsChairs` = false

`Animations.ChairRange` = 4

`Animations.DoubleClick` = true

`Animations.DoubleClickDelay` = 200

`Animations.RemoveFromChairOnDamage` = true

`Animations.SitOnStairs` = true

`Animations.SlabsAsChairs` = true

`Animations.StairsAsChairs` = true

## Ban

`Ban.OverrideLoginMessage` = false

## Bluemap

`BlueMap.Warps.BlackList` = []

`BlueMap.Warps.Enabled` = true

`BlueMap.Warps.Icon` = "https://www.zrips.net/ICON_Warp.png"

`BlueMap.Warps.IconAnchor` = 16

`BlueMap.Warps.Label` = "Warps"

`BlueMap.Warps.ToggledOffDefault` = false

## Books

`Books.AddDate` = false

`Books.DefaultAuthor` = "Server"

## Bossbar

`BossBar.HpBarBlackList` = ['Ender_dragon']

`BossBar.HpBarEnabled` = true

## Bungeecord

`BungeeCord.BackToPreviousServer` = false

`BungeeCord.Enabled` = true

`BungeeCord.TabComplete.PlayerNames` = false

`BungeeCord.TabComplete.Servers` = []

## Checkfornamechange

`CheckForNameChange.NameChangeCommands` = ['asConsole! cmi broadcast !&2[oldname] logged in with new name: [newname]']

`CheckForNameChange.PerformCommandsOnNewName` = false

## Command

`Command.CommandFilter.Duplicate.Interval` = 5

`Command.CommandFilter.Duplicate.MinAmount` = 6

`Command.CommandFilter.Duplicate.Percentage` = 80

`Command.CommandFilter.Duplicate.Use` = true

`Command.CommandFilter.Duplicate.WhiteList` = ['msg', 'tell', 'login', 'register']

`Command.CommandFilter.Priority` = "LOW"

`Command.Mail.ConsoleMailSender` = "server"

`Command.Mail.ExpiresIn` = 30

`Command.Mail.MaxMails` = 50

`Command.Mail.mailAllDays` = 28

`Command.Notes.ExpiresIn` = 30

`Command.Spy.BlackListed` = ['register', 'login', 'l']

`Command.Spy.CommandList` = []

`Command.Spy.DelayForTrigger` = 60

## Compass

`Compass.BossBar` = false

`Compass.Color` = "&7"

`Compass.CompassTarget` = "ꖴ"

`Compass.Death` = "☠"

`Compass.Gradient.EastColor` = "bitter_lemon"

`Compass.Gradient.NorthColor` = "vulcan"

`Compass.Gradient.SouthColor` = "white"

`Compass.Gradient.Use` = true

`Compass.Gradient.WestColor` = "orange"

`Compass.Home` = "۩"

`Compass.RecoveryAsRegular` = false

`Compass.RequireCompass` = false

`Compass.RequireRecoveryCompass` = false

`Compass.Shape` = "------------SW-------------W-------------NW-------------N-------------NE-------------E-------------SE-------------S-"

`Compass.ShowCompassTarget` = true

`Compass.ShowDeath` = true

`Compass.ShowHome` = true

`Compass.ShowSpawn` = true

`Compass.Spawn` = "⤋"

`Compass.UpdateInterval` = 200

## Cooldowns

`Cooldowns.Enabled` = false

`Cooldowns.List` = ['cmi heal:180', 'cmi feed:120']

## Counter

`Counter.Range` = 10

## Cuff

`Cuff.AllowedCommands` = ['msg', 'r', 'tell']

`Cuff.Mute` = true

## Displayname

`DisplayName.Change` = true

`DisplayName.Format` = "{nickName}"

`DisplayName.ValidNicknameRegex` = "[^a-zA-Z0-9\-\_]"

## Dispose

`Dispose.AttachedCommands` = true

`Dispose.CustomModelData` = true

`Dispose.Materials` = []

`Dispose.UILines` = 4

## Dye

`Dye.BoundToPlayer` = false

## Dynamicviewrange

`DynamicViewRange.Enabled` = false

## Economy

`Economy.BalTop.DisplayWithShorts` = false

`Economy.BalTop.Exclude` = ['Notch']

`Economy.BalTop.ExcludeInactive` = 0

`Economy.BalTop.ExcludeStartingWith` = ['town_', 'town-', 'towny_', 'towny-', 'debt-', 'debt_']

`Economy.BalTop.IncludeFakes` = false

`Economy.Cheque.AcceptNotEncoded` = false

`Economy.Cheque.InCreative` = false

`Economy.Cheque.MaxValue` = "1.0E8"

`Economy.Cheque.Paper` = true

`Economy.Cheque.Permission` = false

`Economy.Confirmation` = false

`Economy.Enabled` = false

`Economy.Global.CurrencySymbol` = "€"

`Economy.Global.Fractions` = true

`Economy.Global.MaximumAmount` = "1.0E8"

`Economy.Global.MinimalAmount` = 0.0

`Economy.Global.MinimalPay` = 0.5

`Economy.Global.MoneyFormat` = "###,##0.00"

`Economy.Global.Placing` = "[money][symbol]"

`Economy.Global.ShortNumbersSuffixes` = ['', 'k-1000', 'm-1000000', 'b-1000000000', 't-1000000000000', 'q-1000000000000000']

`Economy.Global.StartingAmount` = 100.0

`Economy.Global.SwitchPlaces` = false

`Economy.Global.UseShortNumbers` = false

`Economy.Global.shortNumbersFormat` = "###,##0.0"

`Economy.LogEnabled` = false

`Economy.PaymentWithShorts.Allow` = true

`Economy.PaymentWithShorts.values` = ['k-1000', 'm-1000000', 'b-1000000000', 't-1000000000000', 'q-1000000000000000']

`Economy.log.IgnoredUsers` = ['Zrips']

`Economy.log.Transfer` = true

`Economy.log.Unknown` = true

## Elytra

`Elytra.Boost.Amount` = 1

`Elytra.Boost.ConsumedItem` = "STONE"

`Elytra.Boost.GeneralMultyplier` = 0.1

`Elytra.Boost.Item` = "FEATHER"

`Elytra.Boost.LaunchItem` = "FEATHER"

`Elytra.Boost.RequiresItem` = true

`Elytra.Boost.ShowParticles` = true

`Elytra.Boost.SpeedDecimals` = true

`Elytra.Boost.SpeedLimit` = 200

`Elytra.Boost.SpeedLimitStop` = false

`Elytra.Boost.SuperAmount` = 5

`Elytra.Boost.SuperMultyplier` = 0.3

`Elytra.Boost.UseItems` = false

`Elytra.DisableRiptide` = false

`Elytra.Fix.PreventRocketUsage` = false

`Elytra.Fix.PreventSelfDamage` = false

`Elytra.Launch.Time` = 2

## Enchanting

`Enchanting.EnforceValidEnchants` = true

`Enchanting.PermissionLevelLimit` = false

`Enchanting.RequireSpecificPermission` = false

`Enchanting.enchantLimits.Enabled` = false

`Enchanting.enchantLimits.MaxLevel.arrow_damage` = 5

`Enchanting.enchantLimits.MaxLevel.arrow_fire` = 1

`Enchanting.enchantLimits.MaxLevel.arrow_infinite` = 1

`Enchanting.enchantLimits.MaxLevel.arrow_knockback` = 2

`Enchanting.enchantLimits.MaxLevel.binding_curse` = 1

`Enchanting.enchantLimits.MaxLevel.breach` = 4

`Enchanting.enchantLimits.MaxLevel.channeling` = 1

`Enchanting.enchantLimits.MaxLevel.damage_all` = 5

`Enchanting.enchantLimits.MaxLevel.damage_arthropods` = 5

`Enchanting.enchantLimits.MaxLevel.damage_undead` = 5

`Enchanting.enchantLimits.MaxLevel.density` = 5

`Enchanting.enchantLimits.MaxLevel.depth_strider` = 3

`Enchanting.enchantLimits.MaxLevel.dig_speed` = 5

`Enchanting.enchantLimits.MaxLevel.durability` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:auto_reel` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:bane_of_netherspawn` = 5

`Enchanting.enchantLimits.MaxLevel.excellentenchants:blast_mining` = 5

`Enchanting.enchantLimits.MaxLevel.excellentenchants:blindness` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:bomber` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:cold_steel` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:confusing_arrows` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:confusion` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:cure` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:curse_of_breaking` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:curse_of_death` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:curse_of_drowned` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:curse_of_fragility` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:curse_of_mediocrity` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:curse_of_misfortune` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:cutter` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:darkness_arrows` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:darkness_cloak` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:decapitator` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:double_catch` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:double_strike` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:dragonfire_arrows` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:electrified_arrows` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:elemental_protection` = 4

`Enchanting.enchantLimits.MaxLevel.excellentenchants:ender_bow` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:exhaust` = 4

`Enchanting.enchantLimits.MaxLevel.excellentenchants:explosive_arrows` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:fire_shield` = 4

`Enchanting.enchantLimits.MaxLevel.excellentenchants:flame_walker` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:flare` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:ghast` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:glassbreaker` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:hardened` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:haste` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:hover` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:ice_aspect` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:ice_shield` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:infernus` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:jumping` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:kamikadze` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:lingering` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:lucky_miner` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:night_vision` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:nimble` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:paralyze` = 5

`Enchanting.enchantLimits.MaxLevel.excellentenchants:poisoned_arrows` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:rage` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:rebound` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:regrowth` = 4

`Enchanting.enchantLimits.MaxLevel.excellentenchants:replanter` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:restore` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:river_master` = 5

`Enchanting.enchantLimits.MaxLevel.excellentenchants:rocket` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:saturation` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:seasoned_angler` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:silk_chest` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:silk_spawner` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:smelter` = 5

`Enchanting.enchantLimits.MaxLevel.excellentenchants:sniper` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:soulbound` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:speed` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:stopping_force` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:survivalist` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:swiper` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:telekinesis` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:temper` = 5

`Enchanting.enchantLimits.MaxLevel.excellentenchants:thrifty` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:thunder` = 5

`Enchanting.enchantLimits.MaxLevel.excellentenchants:treefeller` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:tunnel` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:vampire` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:vampiric_arrows` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:veinminer` = 3

`Enchanting.enchantLimits.MaxLevel.excellentenchants:venom` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:village_defender` = 5

`Enchanting.enchantLimits.MaxLevel.excellentenchants:water_breathing` = 1

`Enchanting.enchantLimits.MaxLevel.excellentenchants:wisdom` = 5

`Enchanting.enchantLimits.MaxLevel.excellentenchants:wither` = 2

`Enchanting.enchantLimits.MaxLevel.excellentenchants:withered_arrows` = 3

`Enchanting.enchantLimits.MaxLevel.fire_aspect` = 2

`Enchanting.enchantLimits.MaxLevel.frost_walker` = 2

`Enchanting.enchantLimits.MaxLevel.impaling` = 5

`Enchanting.enchantLimits.MaxLevel.knockback` = 2

`Enchanting.enchantLimits.MaxLevel.loot_bonus_blocks` = 3

`Enchanting.enchantLimits.MaxLevel.loot_bonus_mobs` = 3

`Enchanting.enchantLimits.MaxLevel.loyalty` = 3

`Enchanting.enchantLimits.MaxLevel.luck` = 3

`Enchanting.enchantLimits.MaxLevel.lure` = 3

`Enchanting.enchantLimits.MaxLevel.mending` = 1

`Enchanting.enchantLimits.MaxLevel.multishot` = 1

`Enchanting.enchantLimits.MaxLevel.oxygen` = 3

`Enchanting.enchantLimits.MaxLevel.piercing` = 4

`Enchanting.enchantLimits.MaxLevel.protection_environmental` = 4

`Enchanting.enchantLimits.MaxLevel.protection_explosions` = 4

`Enchanting.enchantLimits.MaxLevel.protection_fall` = 4

`Enchanting.enchantLimits.MaxLevel.protection_fire` = 4

`Enchanting.enchantLimits.MaxLevel.protection_projectile` = 4

`Enchanting.enchantLimits.MaxLevel.quick_charge` = 3

`Enchanting.enchantLimits.MaxLevel.riptide` = 3

`Enchanting.enchantLimits.MaxLevel.silk_touch` = 1

`Enchanting.enchantLimits.MaxLevel.soul_speed` = 3

`Enchanting.enchantLimits.MaxLevel.sweeping_edge` = 3

`Enchanting.enchantLimits.MaxLevel.swift_sneak` = 3

`Enchanting.enchantLimits.MaxLevel.thorns` = 3

`Enchanting.enchantLimits.MaxLevel.vanishing_curse` = 1

`Enchanting.enchantLimits.MaxLevel.water_worker` = 1

`Enchanting.enchantLimits.MaxLevel.wind_burst` = 3

## Exploitpatcher

`ExploitPatcher.BlockEndPortalItemTransfers` = true

`ExploitPatcher.LimitBooks` = true

`ExploitPatcher.NoCommandsInBed` = false

`ExploitPatcher.Placeholders.blocked.checkItem` = true

`ExploitPatcher.PreventExpPortals` = true

`ExploitPatcher.Riptide` = true

## Filesave

`FileSave.Async` = true

## Flightcharge

`FlightCharge.AutoRecharge.Amount` = 25.0

`FlightCharge.AutoRecharge.From` = 10.0

`FlightCharge.AutoSwitch` = false

`FlightCharge.DamageOnFall` = true

`FlightCharge.DamageOnToggle` = false

`FlightCharge.DeductOnFallMulti` = 2

`FlightCharge.DeductOnIdling` = 1.0

`FlightCharge.DeductOnlyForTime` = 0.0

`FlightCharge.EnabledByDefault` = true

`FlightCharge.ExpRechargeCost` = 1.0

`FlightCharge.GlowColor` = "none"

`FlightCharge.KillOnFall` = false

`FlightCharge.MaxChargeLevel` = 1000

`FlightCharge.MoneyRechargeCost` = 1.0

`FlightCharge.ShowBossBar` = true

## General

`DamageControl` = ['nowalldamage:fly_into_wall:1', 'lowermagmacubedamage:hot_floor:0.9']

`Language` = "EN"

`LanguageDownload` = true

`Motd` = "welcomeMessage"

`ShowNewVersion` = true

## Groundclean

`GroundClean.WhiteList.EntityType` = ['entityType']

`GroundClean.WhiteList.Material` = ['itemType']

## Holograms

`Holograms.CheckInterval` = 2000

`Holograms.Defaults.pageChangeInterval` = 0.0

`Holograms.Defaults.placeUp` = true

`Holograms.Defaults.updateInterval` = 0.0

`Holograms.Defaults.updateRange` = 8

`Holograms.Defaults.viewRange` = 16

## Interactivecommands

`InteractiveCommands.SignRegex` = "(\[ic:([a-zA-Z0-9]+)\])"

`InteractiveCommands.SortByDistance` = true

## Itemrenaming

`ItemRenaming.Anvil.ItalicByDefault` = true

`ItemRenaming.CheckSource` = true

`ItemRenaming.GlobalDisable` = false

`ItemRenaming.List` = ['mobspawner:([A-z]+ (?i)\\w*spawner)']

`ItemRenaming.MaxLength` = 64

`ItemRenaming.Prevent` = false

## Itemrepair

`ItemRepair.Repair.BasePrice` = 100.0

`ItemRepair.Repair.BlockedCustomDataID` = [298785423]

`ItemRepair.Repair.CheckDurability` = true

`ItemRepair.Repair.Confirmation` = true

`ItemRepair.Repair.CostsMoney` = false

`ItemRepair.Repair.WorthPercentage` = 10.0

`ItemRepair.Repair.enchantWorthPercentage` = 10.0

`ItemRepair.RepairShare.AddLore` = true

`ItemRepair.RepairShare.BypassWithRepairPermission` = true

`ItemRepair.RepairShare.CancelEvent` = true

`ItemRepair.RepairShare.Durability` = 1

`ItemRepair.RepairShare.InformWithMessage` = true

`ItemRepair.RepairShare.ProtectCommandRepair` = false

`ItemRepair.RepairShare.ProtectNormalRepair` = false

## Jail

`Jail.ChatRange` = 20

`Jail.CheckInterval` = 500

`Jail.Commands.OnJail` = ['']

`Jail.Commands.OnUnJail` = ['']

`Jail.CountWhileOffline` = false

`Jail.DefaultTime` = 300

`Jail.NoAfk` = false

`Jail.PreventDamage` = true

`Jail.PreventHunger` = true

`Jail.WhiteListedCmds` = ['cmi msg', 'cmi reply']

## Kits

`Kits.Buttons.Back` = "Fence"

`Kits.Buttons.Cooldown` = "Watch"

`Kits.Buttons.Desc` = "GreenWool"

`Kits.Buttons.Exp` = "EXP_BOTTLE"

`Kits.Buttons.Money` = "GOLD_INGOT"

`Kits.Buttons.Usages` = "STONE_PLATE"

`Kits.Complex.CloseButton.Commands` = ['closeinv!']

`Kits.Complex.CloseButton.Material` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNmNjYmY5ODgzZGQzNTlmZGYyMzg1YzkwYTQ1OWQ3Mzc3NjUzODJlYzQxMTdiMDQ4OTVhYzRkYzRiNjBmYyJ9fX0="

`Kits.Complex.CloseButton.Slot` = 9

`Kits.Complex.CloseButton.Use` = true

`Kits.Complex.InfoButton.Commands` = ['closeinv!']

`Kits.Complex.InfoButton.Material` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDZiYTYzMzQ0ZjQ5ZGQxYzRmNTQ4OGU5MjZiZjNkOWUyYjI5OTE2YTZjNTBkNjEwYmI0MGE1MjczZGM4YzgyIn19fQ=="

`Kits.Complex.InfoButton.Slot` = 1

`Kits.Complex.InfoButton.Use` = false

`Kits.FillEmptyFields` = true

`Kits.GUI` = true

`Kits.KitPreview` = true

## Messages

`Messages.Filter.ForLogin` = false

`Messages.Filter.ForLogout` = false

`Messages.Filter.Regex` = ['b[a@][s\\$][t\\+][a@]rd', '(c|k|ck|q)[o0](c|k|ck|q)[s\\$]u(c|k|ck|q)[e3]r', 'mast(e|ur)b(8|ait|ate)']

`Messages.FirstJoinMessage.Use` = false

`Messages.Login.AutoHideFrom` = -1

`Messages.Login.Custom.ServerSwitch` = true

`Messages.Login.Custom.Use` = false

`Messages.Login.Disabled` = false

`Messages.Logout.AutoHideFrom` = -1

`Messages.Logout.Custom.ServerSwitch` = true

`Messages.Logout.Custom.Use` = false

`Messages.Logout.Disabled` = false

## Mirror

`Mirror.BreakDisabled` = false

`Mirror.MaxRange` = 50

## Mute

`Mute.DenyPrivateMessages` = true

## Netherportal

`NetherPortal.MaxHeight` = 23

`NetherPortal.MaxWidth` = 23

`NetherPortal.PreventCreation` = false

## Newbie

`Newbie.Kit` = "Newbie"

## Nickname

`NickName.BlackList` = ['admin', 'administrator', 'server', 'staff', 'staf']

`NickName.MaxLength` = 16

`NickName.MinLength` = 4

`NickName.Prefix` = "~"

`NickName.PrefixWhenDifferent` = false

`NickName.TabComplete.IncludeReal` = true

`NickName.TabComplete.ReplaceReal` = true

## Notes

`Notes.ShowOnAlertEvent` = true

## Optimizations

`Optimizations.AllowRconCommands` = false

`Optimizations.ArmorStands.CheckBlockPlace` = false

`Optimizations.ArmorStands.MaxScale` = 3

`Optimizations.ArmorStands.MinScale` = 0.5

`Optimizations.ArmorStands.Templates.SpecificPermission` = false

`Optimizations.AutoDownload.GeoIp` = true

`Optimizations.AutoDownload.GeoLiteCity` = true

`Optimizations.CMIPlayTimeTracking` = true

`Optimizations.CleanRconCommands` = false

`Optimizations.CommandSorting` = true

`Optimizations.Commands.Clear.Confirmation` = true

`Optimizations.Commands.Clear.Exclude` = ['NBT:ItemJoin Name', 'NBT:ItemJoin.Name']

`Optimizations.Commands.Inv.BlackList` = ['Zrips']

`Optimizations.Commands.Inv.DisableOffline` = false

`Optimizations.Commands.List.ASCOrder` = true

`Optimizations.Commands.Near.Approximate` = true

`Optimizations.Commands.Near.Count` = 10

`Optimizations.Commands.Near.DefaultDistance` = 200

`Optimizations.Commands.Near.Invisibility.Hide` = false

`Optimizations.Commands.Near.Invisibility.Obfuscate` = false

`Optimizations.Commands.Near.PointTo` = true

`Optimizations.Commands.ShowMainHelpPage` = true

`Optimizations.Commands.lastonline.Timers.Time1` = 3600

`Optimizations.Commands.lastonline.Timers.Time2` = 86400

`Optimizations.Commands.lastonline.Timers.Time3` = 604800

`Optimizations.Commands.lastonline.Timers.Time4` = 2592000

`Optimizations.CustomCommandSender` = []

`Optimizations.DisableTeamManagement` = true

`Optimizations.DisableWorldChunkCheckInfo` = false

`Optimizations.ElevatorIndicator` = ['[CMIElevator]', '[Elevator]']

`Optimizations.ElevatorStaticIndicator` = "[*]"

`Optimizations.Hat.Allow.MobHeads` = true

`Optimizations.Hat.Block.NoneHatEnchanted` = true

`Optimizations.Hat.Block.NoneHatItems` = true

`Optimizations.Hat.Block.WithLore` = true

`Optimizations.Hat.WhiteList` = []

`Optimizations.IP.Record` = false

`Optimizations.IP.delay` = 30

`Optimizations.ImmortalityOnJoin` = 3

`Optimizations.InfiniteLoopDetection` = true

`Optimizations.ItemLore.MarkChanged` = false

`Optimizations.ItemLore.MaxLength` = 64

`Optimizations.ItemLore.TypeBlackList` = ['gold_nugget']

`Optimizations.ItemName.MarkChanged` = false

`Optimizations.LongDateFormat2` = "yyyy/MM/dd HH:mm:ss"

`Optimizations.Maintenance` = false

`Optimizations.MaintenanceAutoKick` = true

`Optimizations.MaintenanceBossBar` = true

`Optimizations.MaxHp` = 1000

`Optimizations.MonochromeConsole` = false

`Optimizations.Multicraft.DisableList` = false

`Optimizations.OnDurabilityLoss.Armor.Percentage` = 10

`Optimizations.OnDurabilityLoss.Armor.Use` = true

`Optimizations.OnDurabilityLoss.Tools.Percentage` = 10

`Optimizations.OnDurabilityLoss.Tools.Use` = true

`Optimizations.OnLimitedItemUse.Inform` = true

`Optimizations.PartialPlayerName` = true

`Optimizations.PermisionInConsole` = true

`Optimizations.PermisionOnError` = false

`Optimizations.PlayTimeAutoUpdater` = true

`Optimizations.PlayTimeFromStats` = true

`Optimizations.PlaytimeTopExclude` = ['Some', 'Names', 'Here']

`Optimizations.PlaytimeTopOffline` = 14

`Optimizations.PreloadTopPlaytime` = true

`Optimizations.PreventBedExplosion.Nether` = false

`Optimizations.PreventBedExplosion.TheEnd` = false

`Optimizations.PreventDifferentCapitalizationNames` = false

`Optimizations.PreventEntityBoatEnter.Animals` = false

`Optimizations.PreventEntityBoatEnter.Monsters` = false

`Optimizations.PreventEntityBoatEnter.Villagers` = false

`Optimizations.PreventHook` = false

`Optimizations.PreventIronGolem.Roses` = false

`Optimizations.PreventPlayersBelowBedrock` = false

`Optimizations.PreventPlayersOnNetherRoof` = false

`Optimizations.PrioritizeOnlinePlayers` = true

`Optimizations.RemoveLabel` = true

`Optimizations.SellLog` = true

`Optimizations.ShortDateFormat` = "yyyy/MM/dd"

`Optimizations.ShowBeeHiveInformation` = true

`Optimizations.ShowDecoratedPotInformation` = true

`Optimizations.ShowSkullOwner` = true

`Optimizations.SignEdit.BlackList` = ['[Private]', '[More Users]', '[Everyone]', '[AdminShop]', '[ChestShop]', '[CMIElevator]']

`Optimizations.SimilarCommandChecker` = 85

`Optimizations.SimilarCommandPrevention` = false

`Optimizations.Teleport.Back.BlackList` = ['TeztWorldz']

`Optimizations.Teleport.Back.Expiration` = 0

`Optimizations.Teleport.Back.MinDistance` = 5

`Optimizations.Teleport.Back.WithWE` = true

`Optimizations.Teleport.BlackListedItems.Enabled` = false

`Optimizations.Teleport.BlackListedItems.EnabledFor.home` = true

`Optimizations.Teleport.BlackListedItems.EnabledFor.spawn` = true

`Optimizations.Teleport.BlackListedItems.EnabledFor.tp` = true

`Optimizations.Teleport.BlackListedItems.EnabledFor.tpa` = true

`Optimizations.Teleport.BlackListedItems.EnabledFor.tpahere` = true

`Optimizations.Teleport.BlackListedItems.EnabledFor.warp` = true

`Optimizations.Teleport.BlackListedItems.List` = ['Diamond', 'DiamondBlock', 'DiamondOre', 'ironore:5']

`Optimizations.Teleport.CurrentLoc.tpa` = true

`Optimizations.Teleport.CurrentLoc.tpahere` = true

`Optimizations.Teleport.DBack.BlackList` = ['TeztWorldz']

`Optimizations.Teleport.DBack.Expiration` = 0

`Optimizations.Teleport.DenyConfirm` = true

`Optimizations.Teleport.DisableInvulnerability.OnBlockBreakPlace` = true

`Optimizations.Teleport.DisableInvulnerability.OnInteraction` = true

`Optimizations.Teleport.Invulnerability` = 5

`Optimizations.Teleport.InvulnerabilityPerWorld` = ['testWorld-5']

`Optimizations.Teleport.JumpDefault` = 50

`Optimizations.Teleport.SafeLocationDownThenUp` = false

`Optimizations.Teleport.SwitchPlaces` = true

`Optimizations.Teleport.Tp.Bypass` = 15

`Optimizations.Teleport.Tpa.Block` = 120

`Optimizations.Teleport.Tpa.MaxDistance` = 0

`Optimizations.Teleport.Tpa.Move` = false

`Optimizations.Teleport.Tpa.Time` = 60

`Optimizations.Teleport.Tpa.Warmup` = 3

`Optimizations.Teleport.TpaHere.MaxDistance` = 0

`Optimizations.UseFakeOperator` = false

`Optimizations.helpop.feedbackMessage` = true

`Optimizations.netherRoofHeight` = 0

## Player

`Player.Options.CloseButton.Commands` = ['closeinv!']

`Player.Options.CloseButton.Material` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNmNjYmY5ODgzZGQzNTlmZGYyMzg1YzkwYTQ1OWQ3Mzc3NjUzODJlYzQxMTdiMDQ4OTVhYzRkYzRiNjBmYyJ9fX0="

`Player.Options.CloseButton.Slot` = 9

`Player.Options.CloseButton.Use` = true

`Player.Options.Defaults.InformDurability` = true

`Player.Options.Defaults.acceptingMoney` = true

`Player.Options.Defaults.acceptingPM` = true

`Player.Options.Defaults.acceptingTPA` = true

`Player.Options.Defaults.bossBarCompass` = true

`Player.Options.Defaults.chatSpy` = false

`Player.Options.Defaults.chatbubble` = true

`Player.Options.Defaults.cmdSpy` = false

`Player.Options.Defaults.deathMessages` = true

`Player.Options.Defaults.pmSound` = true

`Player.Options.Defaults.pveDamageNumbers` = true

`Player.Options.Defaults.pvpDamageNumbers` = true

`Player.Options.Defaults.receivePets` = true

`Player.Options.Defaults.rideMe` = true

`Player.Options.Defaults.shiftSignEdit` = true

`Player.Options.Defaults.signSpy` = false

`Player.Options.Defaults.tagSound` = true

`Player.Options.Defaults.totemBossBar` = true

`Player.Options.Defaults.visibleHolograms` = true

`Player.Options.Icons.InformDurability` = "ANVIL"

`Player.Options.Icons.acceptingMoney` = "KNOWLEDGE_BOOK"

`Player.Options.Icons.acceptingPM` = "MAP"

`Player.Options.Icons.acceptingTPA` = "CLOCK"

`Player.Options.Icons.bossBarCompass` = "COMPASS"

`Player.Options.Icons.chatSpy` = "BUCKET"

`Player.Options.Icons.chatbubble` = "LANTERN"

`Player.Options.Icons.cmdSpy` = "WATER_BUCKET"

`Player.Options.Icons.deathMessages` = "DEAD_BUSH"

`Player.Options.Icons.pmSound` = "STONE_BUTTON"

`Player.Options.Icons.pveDamageNumbers` = "WOODEN_SWORD"

`Player.Options.Icons.pvpDamageNumbers` = "DIAMOND_SWORD"

`Player.Options.Icons.receivePets` = "LEAD"

`Player.Options.Icons.rideMe` = "SADDLE"

`Player.Options.Icons.shiftSignEdit` = "OAK_SIGN"

`Player.Options.Icons.signSpy` = "LAVA_BUCKET"

`Player.Options.Icons.tagSound` = "PAPER"

`Player.Options.Icons.totemBossBar` = "TOTEM_OF_UNDYING"

`Player.Options.Icons.visibleHolograms` = "BLACK_STAINED_GLASS"

`Player.Options.InfoButton.Commands` = ['closeinv!']

`Player.Options.InfoButton.Material` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDZiYTYzMzQ0ZjQ5ZGQxYzRmNTQ4OGU5MjZiZjNkOWUyYjI5OTE2YTZjNTBkNjEwYmI0MGE1MjczZGM4YzgyIn19fQ=="

`Player.Options.InfoButton.Slot` = 1

`Player.Options.InfoButton.Use` = false

## Playtimerewards

`PlaytimeRewards.Enabled` = false

`PlaytimeRewards.ExcludeAfk` = false

`PlaytimeRewards.OneTimeAmount` = 2

`PlaytimeRewards.RequiresPermission` = false

`PlaytimeRewards.RewardInform` = 15

## Point

`Point.DefaultParticle` = "DUST"

## Portals

`Portals.CheckInterval` = 300

`Portals.CheckParticleInterval` = 500

`Portals.Defaults.Commands` = ['cmi effect [playerName] blindness 2 1 -s']

`Portals.Defaults.PerformCommands` = true

## Potioneffects

`PotionEffects.DeductWhileOffline` = false

## Ranks

`Ranks.AutoRankUp.Async` = false

`Ranks.AutoRankUp.Delay` = 60

`Ranks.AutoRankUp.PlayerDelay` = 120

`Ranks.AutoRankUp.progressBar` = true

`Ranks.EffectUp` = "GColumn"

`Ranks.ListSamePathOnly` = false

`Ranks.OnlyHours` = false

`Ranks.PermissionCheck` = false

`Ranks.Recalculation` = 0

`Ranks.includeMinutes` = true

## Respawn

`ReSpawn.Global.PriorityOrder` = ['anchor', 'bedLocation', 'spawn', 'homeLocation', 'worldSpawn']

`ReSpawn.Immortality` = 3

`ReSpawn.Specific.world` = ['anchor', 'bedLocation', 'spawn', 'homeLocation', 'worldSpawn']

`ReSpawn.Specific.world_nether` = ['anchor', 'bedLocation', 'spawn', 'homeLocation', 'worldSpawn']

`ReSpawn.Specific.world_the_end` = ['anchor', 'bedLocation', 'spawn', 'homeLocation', 'worldSpawn']

## Recipes

`Recipes.Condense.4Sized` = true

`Recipes.Condense.RequireBackwards` = true

## Selection

`Selection.Tool` = "wooden_shovel"

## Shulkerboxes

`ShulkerBoxes.CostToOpen` = 0.0

`ShulkerBoxes.PreventInCombat` = true

## Signs

`Signs.CheckInterval` = 3000

`Signs.DialogEditor` = true

`Signs.RequireSneaking` = false

`Signs.editBlackList` = ['[Shop]']

## Skins

`Skins.AutoApply` = false

`Skins.RequireSpecificPerm` = false

`Skins.SkinUpdateTimer` = 1320

`Skins.SteveOnOff` = true

## Sleeping

`Sleeping.Speedup.BaseSpeed` = 100

`Sleeping.Speedup.Enabled` = false

`Sleeping.Speedup.ExcludeAfk` = true

`Sleeping.Speedup.InfoType` = "title"

`Sleeping.Speedup.Inform` = true

`Sleeping.Speedup.InformDelay` = 30

`Sleeping.Speedup.MinBeforeSpeeding` = "50%"

`Sleeping.Speedup.MinSpeed` = 5

`Sleeping.Speedup.NightStartsAt` = 12542

`Sleeping.Speedup.OnlyDurringNight` = true

`Sleeping.Speedup.Worlds` = []

## Sounds

`Sounds.Enabled` = true

`Sounds.MailNotification` = "entity_creeper_hurt:1:0.5"

`Sounds.PrivateMessage` = "entity_endermite_death:2:1"

`Sounds.TeleportDown` = "entity_enderman_teleport:0.2:1"

`Sounds.TeleportFail` = "entity_villager_no:2:1"

`Sounds.TeleportHome` = "block_beacon_activate:2:1"

`Sounds.TeleportSpawn` = "entity_enderman_teleport:0.5:1"

`Sounds.TeleportUp` = "entity_enderman_teleport:2:1"

`Sounds.TeleportWarp` = "entity_enderman_teleport:0.5:1"

`Sounds.TpaRequest` = "block_anvil_land:0.5:2"

`Sounds.WarpGuiOpen` = "entity_bat_takeoff:0.5:1"

## Spawn

`Spawn.FirstSpawn.Pitch` = 0.0

`Spawn.FirstSpawn.World` = "None"

`Spawn.FirstSpawn.X` = 0.0

`Spawn.FirstSpawn.Y` = 0.0

`Spawn.FirstSpawn.Yaw` = 0.0

`Spawn.FirstSpawn.Z` = 0.0

`Spawn.IgnoredWorlds` = []

`Spawn.Main.Location` = ""

`Spawn.Main.RespawnLocation` = false

`Spawn.Main.Rng` = 0

`Spawn.Main.TeleportFrom` = []

## Spawnmob

`SpawnMob.MaxPassengers` = 10

`SpawnMob.MaxQuantity` = 25

## Spawners

`Spawners.Break.BaseDropChance` = 100.0

`Spawners.Break.DropExp` = false

`Spawners.Break.Enabled` = false

`Spawners.Break.IntoInventory` = false

`Spawners.Break.RequiresExactPermission` = false

`Spawners.Break.SilkTouchLevel` = 1

`Spawners.Break.StopDropping.After` = 0

`Spawners.Break.StopDropping.Enabled` = false

`Spawners.Break.StopDropping.Linear` = false

`Spawners.Charges.BreakWithoutCharge` = false

`Spawners.Charges.List.Advanced.Bonus` = 10

`Spawners.Charges.List.Advanced.Cooldown` = 3000

`Spawners.Charges.List.Advanced.MaxCharge` = 6

`Spawners.Charges.List.Advanced.StartingCharge` = 3

`Spawners.Charges.List.Advanced.Use` = false

`Spawners.Charges.List.Noob.Bonus` = 10

`Spawners.Charges.List.Noob.Cooldown` = 3600

`Spawners.Charges.List.Noob.MaxCharge` = 5

`Spawners.Charges.List.Noob.StartingCharge` = 2

`Spawners.Charges.List.Noob.Use` = false

`Spawners.Charges.Use` = false

`Spawners.CreeperExplosionDrop.Chance` = 30

`Spawners.CreeperExplosionDrop.use` = false

`Spawners.FullDisable` = true

`Spawners.Interact.Spawner.RequiresPermission` = false

`Spawners.Interact.TrialSpawner.RequiresPermission` = false

`Spawners.Place.Enabled` = true

`Spawners.Place.RequiresExactPermission` = false

`Spawners.Place.RequiresPermission` = false

`Spawners.Proximity.Range` = 3

`Spawners.Proximity.Use` = false

`Spawners.TnTExplosionDrop.Chance` = 30

`Spawners.TnTExplosionDrop.use` = false

## Time

`Time.AutoTime.Interval` = 60

`Time.AutoTime.Smooth` = true

`Time.AutoTime.SmoothSpeed` = 100

`Time.AutoTime.Worlds` = ['']

`Time.Day` = "12:00"

`Time.Dusk` = "18:00"

`Time.Morning` = "06:00"

`Time.Night` = "24:00"

`Time.TimeSpeed.world.Enabled` = false

`Time.TimeSpeed.world.day` = 600

`Time.TimeSpeed.world.night` = 420

`Time.TimeSpeed.world.sunrise` = 90

`Time.TimeSpeed.world.sunset` = 90

## Totem

`Totem.BlackListedWorlds` = ['TestWorld', 'DeathWorld']

`Totem.Cooldown.Time` = 600

`Totem.Cooldown.Use` = false

`Totem.Effects.Absorbtion` = 5

`Totem.Effects.FireResistance` = 40

`Totem.Effects.Regeneration` = 45

`Totem.FullDisableInWorlds` = ['YouDied']

`Totem.ProtectFromVoid` = true

`Totem.RemoveFromInventory` = true

`Totem.RequirePermission` = false

`Totem.Warmup.Time` = 10

`Totem.Warmup.Use` = false

## Vanish

`Vanish.Defaults.PrivateMessages` = false

`Vanish.Defaults.afkcommands` = false

`Vanish.Defaults.bossbar` = true

`Vanish.Defaults.damageToEntity` = false

`Vanish.Defaults.deathMessages` = false

`Vanish.Defaults.fakeJoinLeave` = false

`Vanish.Defaults.hookPlayers` = false

`Vanish.Defaults.informOnJoin` = false

`Vanish.Defaults.informOnLeave` = false

`Vanish.Defaults.interaction` = false

`Vanish.Defaults.itemPickup` = false

`Vanish.Defaults.joinVanished` = false

`Vanish.Defaults.mobAggro` = false

`Vanish.Defaults.mobSpawning` = false

`Vanish.Defaults.nightVision` = true

`Vanish.Defaults.noMessages` = false

`Vanish.Defaults.noisyChest` = false

`Vanish.Defaults.playerDamage` = false

`Vanish.Defaults.relogDisable` = false

`Vanish.Defaults.sleepIgnore` = true

`Vanish.Defaults.stopPlaytime` = true

## Vault

`Vault.Group` = true

`Vault.Money` = true

## Votifier

`Votifier.CommandsOnVote` = ['cmi broadcast !&6[playerDisplayName] &evoted!', 'cmi give [playerName] diamond']

`Votifier.CountVotes` = false

`Votifier.ExcludeList` = ['None']

`Votifier.ExtraRewards.10` = ['cmi heal [playerName]', 'cmi money give [playerName] 100']

`Votifier.ExtraRewards.100` = ['cmi heal [playerName]', 'cmi money give [playerName] 1000', 'cmi give [playerName] diamond 32']

`Votifier.ExtraRewardsEnabled` = false

`Votifier.GeneralCooldown` = 0

`Votifier.MaxVotesInADay` = 0

`Votifier.PerformCommands` = false

## Warmups

`WarmUps.BossBarInfo.Color` = "blue"

`WarmUps.BossBarInfo.Enabled` = false

`WarmUps.BossBarInfo.Segments` = "1"

`WarmUps.Enabled` = false

`WarmUps.InformOnNoMove` = true

`WarmUps.List` = ['cmi tp :5:false', 'cmi back:3:true', 'cmi warp :3:false', 'cmi home :3:false']

`WarmUps.showCounterBarInfo` = false

## Warnings

`Warnings.Categories.Bug.DefaultReason` = "&7Using bugs"

`Warnings.Categories.Bug.LifeTime` = 86400

`Warnings.Categories.Bug.Points` = 30

`Warnings.Categories.Cheat.DefaultReason` = "&7Using cheats"

`Warnings.Categories.Cheat.LifeTime` = 86400

`Warnings.Categories.Cheat.Points` = 50

`Warnings.Categories.Grief.DefaultReason` = "&7Griefing"

`Warnings.Categories.Grief.LifeTime` = 86400

`Warnings.Categories.Grief.Points` = 10

`Warnings.Categories.Swear.DefaultReason` = "&7Swearing"

`Warnings.Categories.Swear.LifeTime` = 86400

`Warnings.Categories.Swear.Points` = 3

`Warnings.Default.DefaultReason` = "&7Violated server rules"

`Warnings.Default.LifeTime` = 86400

`Warnings.Default.Points` = 1

`Warnings.Perform.10` = ['cmi tempban [playerName] 5m &cTemporary banned for getting 10 warnings!']

`Warnings.Perform.3` = ['cmi mute [playerName] 10m', 'cmi msg [playerName] !&cMuted for &710 &cminutes for getting &73 &cwarnings!']

`Warnings.Perform.5` = ['cmi kick [playerName] &cKicked for getting 5 warnings!']

## Warps

`Warps.Complex.CloseButton.Commands` = ['closeinv!']

`Warps.Complex.CloseButton.Material` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNmNjYmY5ODgzZGQzNTlmZGYyMzg1YzkwYTQ1OWQ3Mzc3NjUzODJlYzQxMTdiMDQ4OTVhYzRkYzRiNjBmYyJ9fX0="

`Warps.Complex.CloseButton.Slot` = 9

`Warps.Complex.CloseButton.Use` = true

`Warps.Complex.InfoButton.Commands` = ['closeinv!']

`Warps.Complex.InfoButton.Material` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNDZiYTYzMzQ0ZjQ5ZGQxYzRmNTQ4OGU5MjZiZjNkOWUyYjI5OTE2YTZjNTBkNjEwYmI0MGE1MjczZGM4YzgyIn19fQ=="

`Warps.Complex.InfoButton.Slot` = 1

`Warps.Complex.InfoButton.Use` = false

`Warps.GUI` = true

`Warps.GUIOnCreation` = true

`Warps.MaxLength` = 16

`Warps.MinLength` = 4

`Warps.perPage` = 50

`Warps.requirePerm` = false

`Warps.showCreator` = false

## Worldlimits

`WorldLimits.ElytraFlight` = ['worldName:False']

`WorldLimits.Enabled` = false

`WorldLimits.Fly` = ['testWorld:False']

`WorldLimits.FlyAboveRoof` = true

`WorldLimits.FlyAboveRoofLimitations` = ['world-320', 'world_nether-128', 'world_the_end-256']

`WorldLimits.Gamemode` = ['testWorld:Survival']

`WorldLimits.GodMode` = ['testWorld:False']

`WorldLimits.ReenabledFlyAfterDeath` = false

`WorldLimits.SpawnReasons.world` = ['None']

`WorldLimits.SpawnReasons.world_nether` = ['None']

`WorldLimits.SpawnReasons.world_the_end` = ['None']

## Worth

`Worth.AutoGenerate.PriceIncrease` = 0.2

`Worth.BadLore` = ['Creative item by Gasha']

`Worth.CustomNameBlocking` = false

`Worth.DevalueByDurability` = false

`Worth.LoreBlocking` = false

`Worth.RequireFullDurability` = false

## Heal

`heal.RemoveNegative.List` = ['blindness', 'confusion', 'harm', 'hunger', 'poison', 'slow', 'slow_digging', 'weakness', 'wither']

`heal.RemoveNegative.use` = true

## Hunger

`hunger.overide` = false

## Inv

`inv.IgnoreEmpty` = true

`inv.RequiresPermission` = false

`inv.SaveOnDeath` = true

`inv.restore.BlackListedItems` = ['']

`inv.restore.Food` = false

`inv.restore.HP` = false

`inv.restore.Items` = false

`inv.restore.Potions` = false

`inv.restore.Saturation` = false

`inv.restore.XP` = false

## Purge

`purge.CleanOnStart` = false

`purge.Essentials.DeleteFiles` = false

`purge.Essentials.DestinationFolder` = "plugins/Essentials/userdata_backup"

`purge.Essentials.Enabled` = false

`purge.Essentials.SourceFolder` = "plugins/Essentials/userdata"

`purge.LWC.Enabled` = false

`purge.OfflineDays` = 90

`purge.PlayerAdvancements.DeleteFiles` = false

`purge.PlayerAdvancements.DestinationFolder` = "world/Advancements_backup"

`purge.PlayerAdvancements.Enabled` = false

`purge.PlayerAdvancements.SourceFolder` = "world/Advancements"

`purge.PlayerData.DeleteFiles` = false

`purge.PlayerData.DestinationFolder` = "world/playerdata_backup"

`purge.PlayerData.Enabled` = false

`purge.PlayerData.SourceFolder` = "world/playerdata"

`purge.PlayerStats.DeleteFiles` = false

`purge.PlayerStats.DestinationFolder` = "world/stats_backup"

`purge.PlayerStats.Enabled` = false

`purge.PlayerStats.SourceFolder` = "world/stats"

## Scan

`scan.DefaultRange` = 2

`scan.DefaultSpeed` = 15

`scan.LogIntoFile` = false

`scan.SoftCap` = 19.0

## Search

`search.EnablePurge` = false

`search.LogIntoFile` = false

