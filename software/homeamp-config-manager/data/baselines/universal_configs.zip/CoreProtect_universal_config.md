# CoreProtect - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`api-enabled` = true

`block-break` = true

`block-burn` = true

`block-ignite` = true

`block-movement` = true

`block-place` = true

`buckets` = true

`check-updates` = true

`default-radius` = 32

`donation-key` = null

`entity-change` = true

`entity-kills` = true

`explosions` = true

`hopper-transactions` = true

`item-drops` = true

`item-pickups` = true

`item-transactions` = true

`language` = "en"

`lava-flow` = true

`leaf-decay` = true

`liquid-tracking` = true

`max-radius` = 321

`mushroom-growth` = true

`mysql-database` = "asmp_SQL"

`mysql-host` = "135.181.212.169"

`mysql-password` = "SQLdb2024!"

`mysql-port` = 3369

`mysql-username` = "sqlworkerSMP"

`natural-break` = true

`pistons` = true

`player-commands` = true

`player-interactions` = true

`player-messages` = true

`player-sessions` = true

`portals` = true

`rollback-entities` = true

`rollback-items` = true

`sculk-spread` = true

`sign-text` = true

`skip-generic-data` = true

`tree-growth` = true

`use-mysql` = true

`username-changes` = true

`verbose` = true

`vine-growth` = true

`water-flow` = true

`worldedit` = true

