# JobListings - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Essentials

`Essentials.UseEssentialsMail` = false

`Essentials.UseIgnoreList` = false

## Mail

`Mail.Enabled` = true

## Orders

`Orders.BlacklistedCreateMaterials` = ['SPAWNER', 'ENCHANTMENT_BOOK']

`Orders.BlacklistedMaterials` = ['FIRE', 'LAVA', 'WATER', 'END_PORTAL', 'END_GATEWAY', 'NETHER_PORTAL', 'AIR', 'BEDROCK', 'BARRIER', 'LIGHT', 'END_PORTAL_FRAME', 'STRUCTURE_BLOCK', 'COMMAND_BLOCK', 'STRUCTURE_VOID', 'JIGSAW']

`Orders.CreateHand` = true

`Orders.CreateMaterial` = true

`Orders.MaxOrders` = 3

`Orders.MaxOrdersAccepted` = 3

`Orders.MaxOrdersTime` = 192

