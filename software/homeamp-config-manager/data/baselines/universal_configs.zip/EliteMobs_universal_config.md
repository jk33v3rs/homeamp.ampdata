# EliteMobs - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`alwaysShowEliteMobNameTags` = false

`bossAlreadyGoneMessage` = "&c[EliteMobs] Sorry, this boss is already gone!"

`characterLimitForBookMenuPagesV2` = 170

`chestCooldownMessage` = "&7[EM] &cYou've already opened this chest recently! Wait $time!"

`chestLowRankMessage` = "&7[EM] &cYour guild rank needs to be at least $rank &cin order to open this chest!"

`defaultSpawnLocation` = "world,-32.0,64.0,0.0,0.0,0.0"

`defaultTransitiveBlockLimiter` = 500

`dismissEMMessage` = "&8[EliteMobs] &2/elitemobs &fmenu not working for you? Try &2/elitemobs alt &fto see an alternative version of the menu! &cDon't want to see this message again? &4/em dismiss"

`doExplosionRegen` = true

`doRegenerateContainers` = true

`emLeadsToStatusMenu` = false

`enableHighCompatibilityMode` = false

`enchantmentChallengeConsequencesMessage` = "&cThere's a 10% chance of losing your item if you lose the fight! Leaving the arena counts as losing."

`enchantmentChallengeCriticalFailureMessage` = "&8[EliteMobs] &4Critical failure! You lost the item!"

`enchantmentChallengeFailureMessage` = "&8[EliteMobs] &cFailed enchantment! The enchantment did not bind to the item."

`enchantmentChallengeInventoryFullMessage` = "&8[EliteMobs] &cYour inventory was full so the item you were trying to upgrade has been deleted! It will be restored if your item is not full by the time you leave the instanced dungeon."

`enchantmentChallengeStartMessage` = "&8[EliteMobs] &6Challenge! Defeat the boss to get your upgraded item!"

`enchantmentChallengeSuccessMessage` = "&8[EliteMobs] &2Successful enchantment!"

`language` = "english"

`nightmareWorldSpawnBonus` = 0.5

`noPendingCommands` = "&cYou don't currently have any pending commands!"

`onlyUseBedrockMenus` = false

`otherCommandsLeadToEMStatusMenu` = false

`preventEliteCreeperDamageToPassiveMobs` = true

`preventEliteMobConversionOfNamedMobs` = true

`preventVanillaReinforcementsForEliteEntities` = true

`resetPlayerScale` = true

`setupDoneV4` = true

`superMobStackAmount` = 500

`switchEMStyleMessage` = "&8[EliteMobs] &2/elitemobs &fmenu style changed! Check it out!"

`trackMessage` = "Track the $name"

`treasureChestNoDropMessage` = "&8[EliteMobs] &cYou didn't get anything! Better luck next time!"

`useGlassToFillMenuEmptySpace` = false

`useRandomizedScalingForElites` = false

`useResourcePackEvenIfResourcePackManagerIsNotInstalled` = false

`useTitlesForMissingPermissionMessages` = true

