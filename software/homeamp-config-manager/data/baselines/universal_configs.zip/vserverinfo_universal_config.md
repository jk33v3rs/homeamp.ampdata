# vserverinfo Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
config: {'format': '"<gray>Online Server: <gradient:#4ecdc4:#55670><server></gradient>"', 'hover': '[', 'none-found': '"<gray>NONE"', 'server-not-found': '"<gradient:#DBE6F6:#C5796D>This server does not exists</gradient>"'}
```
