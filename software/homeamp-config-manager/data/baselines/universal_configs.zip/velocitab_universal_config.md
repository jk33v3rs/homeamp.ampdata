# velocitab Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
config: {'check_for_updates': True, 'disable_header_footer_if_empty': True, 'enable_mini_placeholders_hook': True, 'enable_papi_hook': True, 'enable_plugin_message_api': True, 'enable_relational_placeholders': True, 'fallback_enabled': True, 'fallback_group': 'default', 'fallback_to_papi_if_placeholder_blank': True, 'force_sending_tab_list_packets': True, 'formatter': 'MINIMESSAGE', 'papi_cache_time': 30000, 'remove_nametags': False, 'remove_spectator_effect': True, 'send_scoreboard_packets': True, 'server_links': [{'groups': ['default'], 'label': '<#00fb9a>Gameplay and Server Stats, Resources, and Good Times </#00fb9a>', 'url': 'https://discord.archivesmp.com'}], 'show_all_players_from_all_groups': True, 'sort_players': True}
tab_groups: {'groups': [{'collisions': True, 'footers': ['<gray>There are currently %players_online%/%max_players_online% players online</gray>'], 'format': '<gray>[%server%] %prefix%%username%</gray>', 'format_update_rate': 1000, 'header_footer_update_rate': 1000, 'headers': ['<rainbow:!2> Online Players </rainbow>'], 'name': 'default', 'nametag': {'prefix': '', 'suffix': ''}, 'nametag_update_rate': 1000, 'only_list_players_in_same_server': False, 'placeholder_replacements': {}, 'placeholder_update_rate': 1000, 'servers': ['template', 'privateworlds', 'royale', 'neocreate', 'hardcore', 'csmc', 'emadventure', 'biggergames', 'clippycore', 'creative', 'hub', 'dev', 'minetorio', 'smp', 'carpet', 'skyblock', 'minigames', 'evo', 'tower'], 'sorting_placeholders': ['%role_weight%', '%username_lower%']}]}
```
