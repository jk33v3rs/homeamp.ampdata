# mcMMO - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Abilities

`Abilities.Activation.Only_Activate_When_Sneaking` = true

`Abilities.Cooldowns.Berserk` = 240

`Abilities.Cooldowns.Blast_Mining` = 60

`Abilities.Cooldowns.Giga_Drill_Breaker` = 240

`Abilities.Cooldowns.Green_Terra` = 240

`Abilities.Cooldowns.Serrated_Strikes` = 240

`Abilities.Cooldowns.Skull_Splitter` = 240

`Abilities.Cooldowns.Super_Breaker` = 240

`Abilities.Cooldowns.Tree_Feller` = 240

`Abilities.Enabled` = true

`Abilities.Limits.Tree_Feller_Threshold` = 1000

`Abilities.Max_Seconds.Berserk` = 0

`Abilities.Max_Seconds.Blast_Mining` = 0

`Abilities.Max_Seconds.Giga_Drill_Breaker` = 0

`Abilities.Max_Seconds.Green_Terra` = 0

`Abilities.Max_Seconds.Serrated_Strikes` = 0

`Abilities.Max_Seconds.Skull_Splitter` = 0

`Abilities.Max_Seconds.Super_Breaker` = 0

`Abilities.Max_Seconds.Tree_Feller` = 0

`Abilities.Messages` = true

`Abilities.Tools.Durability_Loss` = 1.2

## Backups

`Backups.Enabled` = true

`Backups.Keep.Daily_Last_Week` = true

`Backups.Keep.Last_24_Hours` = true

`Backups.Keep.Weekly_Past_Months` = true

## Bonus_Drops

`Bonus_Drops.Herbalism.Allium` = true

`Bonus_Drops.Herbalism.Azure_Bluet` = true

`Bonus_Drops.Herbalism.Bamboo_Sapling` = true

`Bonus_Drops.Herbalism.Beetroot` = true

`Bonus_Drops.Herbalism.Beetroots` = true

`Bonus_Drops.Herbalism.Blue_Orchid` = true

`Bonus_Drops.Herbalism.Brown_Mushroom` = true

`Bonus_Drops.Herbalism.Bush` = true

`Bonus_Drops.Herbalism.Cactus` = true

`Bonus_Drops.Herbalism.Cactus_Flower` = true

`Bonus_Drops.Herbalism.Carrot` = true

`Bonus_Drops.Herbalism.Carrots` = true

`Bonus_Drops.Herbalism.Cave_Vines` = true

`Bonus_Drops.Herbalism.Cave_Vines_Plant` = true

`Bonus_Drops.Herbalism.Chorus_Fruit` = true

`Bonus_Drops.Herbalism.Chorus_Plant` = true

`Bonus_Drops.Herbalism.Closed_Eyeblossom` = true

`Bonus_Drops.Herbalism.Cocoa` = true

`Bonus_Drops.Herbalism.Cocoa_Beans` = true

`Bonus_Drops.Herbalism.Crimson_Fungus` = true

`Bonus_Drops.Herbalism.Crimson_Roots` = true

`Bonus_Drops.Herbalism.Crimson_Stem` = true

`Bonus_Drops.Herbalism.Dandelion` = true

`Bonus_Drops.Herbalism.Eyeblossom` = true

`Bonus_Drops.Herbalism.Firefly_Bush` = true

`Bonus_Drops.Herbalism.Glow_Berries` = true

`Bonus_Drops.Herbalism.Leaf_Litter` = true

`Bonus_Drops.Herbalism.Lilac` = true

`Bonus_Drops.Herbalism.Lily_Of_The_Valley` = true

`Bonus_Drops.Herbalism.Lily_Pad` = true

`Bonus_Drops.Herbalism.Melon` = true

`Bonus_Drops.Herbalism.Melon_Slice` = true

`Bonus_Drops.Herbalism.Moss_Block` = true

`Bonus_Drops.Herbalism.Nether_Wart` = true

`Bonus_Drops.Herbalism.Nether_Wart_Block` = true

`Bonus_Drops.Herbalism.Open_Eyeblossom` = true

`Bonus_Drops.Herbalism.Orange_Tulip` = true

`Bonus_Drops.Herbalism.Oxeye_Daisy` = true

`Bonus_Drops.Herbalism.Peony` = true

`Bonus_Drops.Herbalism.Pink_Petals` = true

`Bonus_Drops.Herbalism.Pink_Tulip` = true

`Bonus_Drops.Herbalism.Pitcher_Plant` = true

`Bonus_Drops.Herbalism.Poppy` = true

`Bonus_Drops.Herbalism.Potato` = true

`Bonus_Drops.Herbalism.Potatoes` = true

`Bonus_Drops.Herbalism.Pumpkin` = true

`Bonus_Drops.Herbalism.Red_Mushroom` = true

`Bonus_Drops.Herbalism.Red_Tulip` = true

`Bonus_Drops.Herbalism.Rose_Bush` = true

`Bonus_Drops.Herbalism.Short_Dry_Grass` = true

`Bonus_Drops.Herbalism.Shroomlight` = true

`Bonus_Drops.Herbalism.Sugar_Cane` = true

`Bonus_Drops.Herbalism.Sunflower` = true

`Bonus_Drops.Herbalism.Sweet_Berry_Bush` = true

`Bonus_Drops.Herbalism.Tall_Dry_Grass` = true

`Bonus_Drops.Herbalism.Torchflower` = true

`Bonus_Drops.Herbalism.Twisting_Vines` = true

`Bonus_Drops.Herbalism.Vine` = true

`Bonus_Drops.Herbalism.Warped_Fungus` = true

`Bonus_Drops.Herbalism.Warped_Roots` = true

`Bonus_Drops.Herbalism.Warped_Stem` = true

`Bonus_Drops.Herbalism.Warped_Wart_Block` = true

`Bonus_Drops.Herbalism.Weeping_Vines` = true

`Bonus_Drops.Herbalism.Wheat` = true

`Bonus_Drops.Herbalism.White_Tulip` = true

`Bonus_Drops.Herbalism.Wildflowers` = true

`Bonus_Drops.Mining.Amethyst_Cluster` = true

`Bonus_Drops.Mining.Amethyst_Shard` = true

`Bonus_Drops.Mining.Ancient_Debris` = true

`Bonus_Drops.Mining.Andesite` = true

`Bonus_Drops.Mining.Basalt` = true

`Bonus_Drops.Mining.Blackstone` = true

`Bonus_Drops.Mining.Block_Of_Amethyst` = true

`Bonus_Drops.Mining.Budding_Amethyst` = true

`Bonus_Drops.Mining.Calcite` = true

`Bonus_Drops.Mining.Chain` = true

`Bonus_Drops.Mining.Chiseled_Nether_Bricks` = true

`Bonus_Drops.Mining.Coal` = true

`Bonus_Drops.Mining.Coal_Ore` = true

`Bonus_Drops.Mining.Cobbled_Deepslate` = true

`Bonus_Drops.Mining.Cobblestone` = true

`Bonus_Drops.Mining.Copper_Ore` = true

`Bonus_Drops.Mining.Cracked_Nether_Bricks` = true

`Bonus_Drops.Mining.Crimson_Nylium` = true

`Bonus_Drops.Mining.Crying_Obsidian` = true

`Bonus_Drops.Mining.Deepslate` = true

`Bonus_Drops.Mining.Deepslate_Coal_Ore` = true

`Bonus_Drops.Mining.Deepslate_Copper_Ore` = true

`Bonus_Drops.Mining.Deepslate_Diamond_Ore` = true

`Bonus_Drops.Mining.Deepslate_Emerald_Ore` = true

`Bonus_Drops.Mining.Deepslate_Gold_Ore` = true

`Bonus_Drops.Mining.Deepslate_Iron_Ore` = true

`Bonus_Drops.Mining.Deepslate_Lapis_Ore` = true

`Bonus_Drops.Mining.Deepslate_Redstone_Ore` = true

`Bonus_Drops.Mining.Diamond` = true

`Bonus_Drops.Mining.Diamond_Ore` = true

`Bonus_Drops.Mining.Diorite` = true

`Bonus_Drops.Mining.Emerald` = true

`Bonus_Drops.Mining.Emerald_Ore` = true

`Bonus_Drops.Mining.End_Stone` = true

`Bonus_Drops.Mining.Gilded_Blackstone` = true

`Bonus_Drops.Mining.Glowstone` = true

`Bonus_Drops.Mining.Glowstone_Dust` = true

`Bonus_Drops.Mining.Gold_Nugget` = true

`Bonus_Drops.Mining.Gold_Ore` = true

`Bonus_Drops.Mining.Granite` = true

`Bonus_Drops.Mining.Iron_Ingot` = true

`Bonus_Drops.Mining.Iron_Ore` = true

`Bonus_Drops.Mining.Lapis_Lazuli` = true

`Bonus_Drops.Mining.Lapis_Lazuli_Ore` = true

`Bonus_Drops.Mining.Lapis_Ore` = true

`Bonus_Drops.Mining.Large_Amethyst_Bud` = true

`Bonus_Drops.Mining.Medium_Amethyst_Bud` = true

`Bonus_Drops.Mining.Mossy_Cobblestone` = true

`Bonus_Drops.Mining.Nether_Bricks` = true

`Bonus_Drops.Mining.Nether_Gold_Ore` = true

`Bonus_Drops.Mining.Nether_Quartz_Ore` = true

`Bonus_Drops.Mining.Netherite_Scrap` = true

`Bonus_Drops.Mining.Netherrack` = true

`Bonus_Drops.Mining.Obsidian` = true

`Bonus_Drops.Mining.Polished_Basalt` = true

`Bonus_Drops.Mining.Quartz` = true

`Bonus_Drops.Mining.Raw_Copper` = true

`Bonus_Drops.Mining.Raw_Gold` = true

`Bonus_Drops.Mining.Raw_Iron` = true

`Bonus_Drops.Mining.Red_Nether_Bricks` = true

`Bonus_Drops.Mining.Redstone` = true

`Bonus_Drops.Mining.Redstone_Dust` = true

`Bonus_Drops.Mining.Redstone_Ore` = true

`Bonus_Drops.Mining.Sandstone` = true

`Bonus_Drops.Mining.Small_Amethyst_Bud` = true

`Bonus_Drops.Mining.Smooth_Basalt` = true

`Bonus_Drops.Mining.Stone` = true

`Bonus_Drops.Mining.Tuff` = true

`Bonus_Drops.Mining.Warped_Nylium` = true

`Bonus_Drops.Smelting.Coal` = true

`Bonus_Drops.Smelting.Copper_Ingot` = true

`Bonus_Drops.Smelting.Deepslate` = true

`Bonus_Drops.Smelting.Diamond` = true

`Bonus_Drops.Smelting.Emerald` = true

`Bonus_Drops.Smelting.Gold_Ingot` = true

`Bonus_Drops.Smelting.Iron_Ingot` = true

`Bonus_Drops.Smelting.Lapis_Lazuli` = true

`Bonus_Drops.Smelting.Nether_Quartz` = true

`Bonus_Drops.Smelting.Netherite_Scrap` = true

`Bonus_Drops.Smelting.Quartz` = true

`Bonus_Drops.Smelting.Redstone` = true

`Bonus_Drops.Woodcutting.Acacia_Log` = true

`Bonus_Drops.Woodcutting.Acacia_Wood` = true

`Bonus_Drops.Woodcutting.Birch_Log` = true

`Bonus_Drops.Woodcutting.Birch_Wood` = true

`Bonus_Drops.Woodcutting.Cherry_Log` = true

`Bonus_Drops.Woodcutting.Cherry_Wood` = true

`Bonus_Drops.Woodcutting.Crimson_Hyphae` = true

`Bonus_Drops.Woodcutting.Crimson_Roots` = true

`Bonus_Drops.Woodcutting.Crimson_Stem` = true

`Bonus_Drops.Woodcutting.Dark_Oak_Log` = true

`Bonus_Drops.Woodcutting.Dark_Oak_Wood` = true

`Bonus_Drops.Woodcutting.Jungle_Log` = true

`Bonus_Drops.Woodcutting.Jungle_Wood` = true

`Bonus_Drops.Woodcutting.Mangrove_Log` = true

`Bonus_Drops.Woodcutting.Mangrove_Wood` = true

`Bonus_Drops.Woodcutting.Oak_Log` = true

`Bonus_Drops.Woodcutting.Oak_Wood` = true

`Bonus_Drops.Woodcutting.Pale_Oak_Log` = true

`Bonus_Drops.Woodcutting.Pale_Oak_Wood` = true

`Bonus_Drops.Woodcutting.Shroomlight` = true

`Bonus_Drops.Woodcutting.Spruce_Log` = true

`Bonus_Drops.Woodcutting.Spruce_Wood` = true

`Bonus_Drops.Woodcutting.Stripped_Crimson_Hyphae` = true

`Bonus_Drops.Woodcutting.Stripped_Warped_Hyphae` = true

`Bonus_Drops.Woodcutting.Warped_Hyphae` = true

`Bonus_Drops.Woodcutting.Warped_Roots` = true

`Bonus_Drops.Woodcutting.Warped_Stem` = true

## Commands

`Commands.Database.Player_Cooldown` = 1750

`Commands.Generic.Match_OfflinePlayers` = true

`Commands.Skills.URL_Links` = false

`Commands.inspect.Max_Distance` = 96

`Commands.mcmmo.Donate_Message` = false

`Commands.ptp.Accept_Required` = true

`Commands.ptp.Cooldown` = 128

`Commands.ptp.RecentlyHurt_Cooldown` = 60

`Commands.ptp.Request_Timeout` = 300

`Commands.ptp.Warmup` = 5

`Commands.ptp.World_Based_Permissions` = false

## Database_Purging

`Database_Purging.Old_User_Cutoff` = 25

`Database_Purging.Purge_Interval` = -1

## General

`General.AdminNotifications` = true

`General.AprilFoolsEvent` = true

`General.Config_Update_Overwrite` = false

`General.EventBroadcasts` = true

`General.EventInfoOnPlayerJoin` = true

`General.LevelUp_Sounds` = true

`General.Level_Up_Chat_Broadcasts.Broadcast_Powerlevels.Broadcast_Targets.Distance_Restrictions.Restrict_Distance` = false

`General.Level_Up_Chat_Broadcasts.Broadcast_Powerlevels.Broadcast_Targets.Distance_Restrictions.Restricted_Radius` = 100

`General.Level_Up_Chat_Broadcasts.Broadcast_Powerlevels.Broadcast_Targets.Only_Party_Members` = false

`General.Level_Up_Chat_Broadcasts.Broadcast_Powerlevels.Broadcast_Targets.Only_Same_World` = false

`General.Level_Up_Chat_Broadcasts.Broadcast_Powerlevels.Broadcast_Targets.Send_To_Console` = true

`General.Level_Up_Chat_Broadcasts.Broadcast_Powerlevels.Enabled` = true

`General.Level_Up_Chat_Broadcasts.Broadcast_Powerlevels.Milestone_Interval` = 100

`General.Level_Up_Chat_Broadcasts.Broadcast_Targets.Distance_Restrictions.Restrict_Distance` = false

`General.Level_Up_Chat_Broadcasts.Broadcast_Targets.Distance_Restrictions.Restricted_Radius` = 100

`General.Level_Up_Chat_Broadcasts.Broadcast_Targets.Only_Party_Members` = false

`General.Level_Up_Chat_Broadcasts.Broadcast_Targets.Only_Same_World` = false

`General.Level_Up_Chat_Broadcasts.Broadcast_Targets.Send_To_Console` = true

`General.Level_Up_Chat_Broadcasts.Enabled` = true

`General.Level_Up_Chat_Broadcasts.Milestone_Interval` = 100

`General.Locale` = "en_US"

`General.MOTD_Enabled` = true

`General.PowerLevel.Skill_Mastery.Enabled` = true

`General.Power_Level_Cap` = 0

`General.Refresh_Chunks` = true

`General.RetroMode.Enabled` = false

`General.Save_Interval` = 10

`General.Show_Profile_Loaded` = true

`General.Stats_Tracking` = true

`General.TruncateSkills` = true

`General.Verbose_Logging` = false

## Green_Thumb_Replanting_Crops

`Green_Thumb_Replanting_Crops.Beetroots` = true

`Green_Thumb_Replanting_Crops.Carrots` = true

`Green_Thumb_Replanting_Crops.Cocoa` = true

`Green_Thumb_Replanting_Crops.Nether_Wart` = true

`Green_Thumb_Replanting_Crops.Potatoes` = true

`Green_Thumb_Replanting_Crops.Wheat` = true

## Hardcore

`Hardcore.Death_Stat_Loss.Enabled.Acrobatics` = false

`Hardcore.Death_Stat_Loss.Enabled.Alchemy` = false

`Hardcore.Death_Stat_Loss.Enabled.Archery` = false

`Hardcore.Death_Stat_Loss.Enabled.Axes` = false

`Hardcore.Death_Stat_Loss.Enabled.Crossbows` = false

`Hardcore.Death_Stat_Loss.Enabled.Excavation` = false

`Hardcore.Death_Stat_Loss.Enabled.Fishing` = false

`Hardcore.Death_Stat_Loss.Enabled.Herbalism` = false

`Hardcore.Death_Stat_Loss.Enabled.Maces` = false

`Hardcore.Death_Stat_Loss.Enabled.Mining` = false

`Hardcore.Death_Stat_Loss.Enabled.Repair` = false

`Hardcore.Death_Stat_Loss.Enabled.Swords` = false

`Hardcore.Death_Stat_Loss.Enabled.Taming` = false

`Hardcore.Death_Stat_Loss.Enabled.Tridents` = false

`Hardcore.Death_Stat_Loss.Enabled.Unarmed` = false

`Hardcore.Death_Stat_Loss.Enabled.Woodcutting` = false

`Hardcore.Death_Stat_Loss.Level_Threshold` = 100

`Hardcore.Death_Stat_Loss.Penalty_Percentage` = 75.0

`Hardcore.Vampirism.Enabled.Acrobatics` = false

`Hardcore.Vampirism.Enabled.Alchemy` = false

`Hardcore.Vampirism.Enabled.Archery` = false

`Hardcore.Vampirism.Enabled.Axes` = false

`Hardcore.Vampirism.Enabled.Crossbows` = false

`Hardcore.Vampirism.Enabled.Excavation` = false

`Hardcore.Vampirism.Enabled.Fishing` = false

`Hardcore.Vampirism.Enabled.Herbalism` = false

`Hardcore.Vampirism.Enabled.Maces` = false

`Hardcore.Vampirism.Enabled.Mining` = false

`Hardcore.Vampirism.Enabled.Repair` = false

`Hardcore.Vampirism.Enabled.Swords` = false

`Hardcore.Vampirism.Enabled.Taming` = false

`Hardcore.Vampirism.Enabled.Tridents` = false

`Hardcore.Vampirism.Enabled.Unarmed` = false

`Hardcore.Vampirism.Enabled.Woodcutting` = false

`Hardcore.Vampirism.Leech_Percentage` = 0.1

`Hardcore.Vampirism.Level_Threshold` = 100

## Items

`Items.Chimaera_Wing.Cooldown` = 240

`Items.Chimaera_Wing.Enabled` = true

`Items.Chimaera_Wing.Item_Name` = "FEATHER"

`Items.Chimaera_Wing.Prevent_Use_Underground` = true

`Items.Chimaera_Wing.RecentlyHurt_Cooldown` = 60

`Items.Chimaera_Wing.Recipe_Cost` = 5

`Items.Chimaera_Wing.Sound_Enabled` = true

`Items.Chimaera_Wing.Use_Bed_Spawn` = true

`Items.Chimaera_Wing.Use_Cost` = 1

`Items.Chimaera_Wing.Warmup` = 5

`Items.Flux_Pickaxe.Sound_Enabled` = true

## Mob_Healthbar

`Mob_Healthbar.Display_Time` = 3

`Mob_Healthbar.Display_Type` = "HEARTS"

`Mob_Healthbar.Enabled` = true

## Mods

`Mods.Armor_Mods_Enabled` = true

`Mods.Block_Mods_Enabled` = true

`Mods.Entity_Mods_Enabled` = true

`Mods.Tool_Mods_Enabled` = true

## Mysql

`MySQL.Database.MaxConnections.Load` = 30

`MySQL.Database.MaxConnections.Misc` = 30

`MySQL.Database.MaxConnections.Save` = 30

`MySQL.Database.MaxPoolSize.Load` = 20

`MySQL.Database.MaxPoolSize.Misc` = 10

`MySQL.Database.MaxPoolSize.Save` = 20

`MySQL.Database.Name` = "asmp_SQL"

`MySQL.Database.User_Name` = "sqlworkerSMP"

`MySQL.Database.User_Password` = "SQLdb2024!"

`MySQL.Debug` = false

`MySQL.Enabled` = true

`MySQL.Server.Address` = "135.181.212.169"

`MySQL.Server.Port` = 3369

`MySQL.Server.SSL` = false

`MySQL.Server.allowPublicKeyRetrieval` = true

## Particles

`Particles.Ability_Activation` = false

`Particles.Ability_Deactivation` = false

`Particles.Bleed` = true

`Particles.Call_of_the_Wild` = true

`Particles.Cripple` = true

`Particles.Dodge` = true

`Particles.Flux` = true

`Particles.Greater_Impact` = true

`Particles.LargeFireworks` = true

`Particles.LevelUp_Enabled` = true

`Particles.LevelUp_Tier` = 100

## Party

`Party.AutoKick_Interval` = -1

`Party.FriendlyFire` = false

`Party.Leveling.Alliance_UnlockLevel` = 5

`Party.Leveling.Chat_UnlockLevel` = 1

`Party.Leveling.Inform_All_Party_Members_On_LevelUp` = true

`Party.Leveling.ItemShare_UnlockLevel` = 8

`Party.Leveling.Level_Cap` = 50

`Party.Leveling.Near_Members_Needed` = false

`Party.Leveling.Teleport_UnlockLevel` = 2

`Party.Leveling.XpShare_UnlockLevel` = 10

`Party.Leveling.Xp_Curve_Modifier` = 2

`Party.MaxSize` = -1

`Party.Old_Party_Member_Cutoff` = 367

`Party.Sharing.ExpShare_bonus_base` = 1.1

`Party.Sharing.ExpShare_bonus_cap` = 1.5

`Party.Sharing.ExpShare_bonus_increase` = 1.05

`Party.Sharing.Range` = 96.0

## Scoreboard

`Scoreboard.Ability_Names` = true

`Scoreboard.Allow_Keep` = true

`Scoreboard.Power_Level_Tags` = true

`Scoreboard.Rainbows` = true

`Scoreboard.Show_Stats_After_Login` = true

`Scoreboard.Tips_Amount` = 5

`Scoreboard.Types.Cooldown.Board` = true

`Scoreboard.Types.Cooldown.Display_Time` = 41

`Scoreboard.Types.Cooldown.Print` = true

`Scoreboard.Types.Inspect.Board` = true

`Scoreboard.Types.Inspect.Display_Time` = 20

`Scoreboard.Types.Inspect.Print` = true

`Scoreboard.Types.Rank.Board` = true

`Scoreboard.Types.Rank.Display_Time` = 15

`Scoreboard.Types.Rank.Print` = true

`Scoreboard.Types.Skill.Board` = true

`Scoreboard.Types.Skill.Display_Time` = 30

`Scoreboard.Types.Skill.LevelUp_Board` = true

`Scoreboard.Types.Skill.LevelUp_Time` = 5

`Scoreboard.Types.Stats.Board` = true

`Scoreboard.Types.Stats.Display_Time` = 15

`Scoreboard.Types.Stats.Print` = true

`Scoreboard.Types.Top.Board` = true

`Scoreboard.Types.Top.Display_Time` = 15

`Scoreboard.Types.Top.Print` = true

`Scoreboard.UseScoreboards` = true

## Skills

`Skills.Acrobatics.Enabled_For_PVE` = true

`Skills.Acrobatics.Enabled_For_PVP` = true

`Skills.Acrobatics.Level_Cap` = 0

`Skills.Acrobatics.Prevent_Dodge_Lightning` = false

`Skills.Acrobatics.XP_After_Teleport_Cooldown` = 5

`Skills.Alchemy.Enabled_for_Hoppers` = true

`Skills.Alchemy.Level_Cap` = 0

`Skills.Alchemy.Prevent_Hopper_Transfer_Bottles` = false

`Skills.Alchemy.Prevent_Hopper_Transfer_Ingredients` = false

`Skills.Archery.Enabled_For_PVE` = true

`Skills.Archery.Enabled_For_PVP` = true

`Skills.Archery.Level_Cap` = 0

`Skills.Axes.Enabled_For_PVE` = true

`Skills.Axes.Enabled_For_PVP` = true

`Skills.Axes.Level_Cap` = 0

`Skills.Crossbows.Enabled_For_PVE` = true

`Skills.Crossbows.Enabled_For_PVP` = true

`Skills.Crossbows.Level_Cap` = 0

`Skills.Excavation.Level_Cap` = 0

`Skills.Fishing.Drops_Enabled` = true

`Skills.Fishing.Extra_Fish` = false

`Skills.Fishing.Level_Cap` = 0

`Skills.Fishing.Lure_Modifier` = 3.0

`Skills.Fishing.Override_Vanilla_Treasures` = true

`Skills.Herbalism.Level_Cap` = 0

`Skills.Herbalism.Prevent_AFK_Leveling` = true

`Skills.Maces.Enabled_For_PVE` = true

`Skills.Maces.Enabled_For_PVP` = true

`Skills.Maces.Level_Cap` = 0

`Skills.Mining.Detonator_Name` = "FLINT_AND_STEEL"

`Skills.Mining.Level_Cap` = 0

`Skills.Repair.Anvil_Material` = "IRON_BLOCK"

`Skills.Repair.Anvil_Messages` = true

`Skills.Repair.Anvil_Placed_Sounds` = true

`Skills.Repair.Anvil_Use_Sounds` = true

`Skills.Repair.Confirm_Required` = true

`Skills.Repair.Level_Cap` = 0

`Skills.Repair.Use_Enchanted_Materials` = false

`Skills.Salvage.Anvil_Material` = "GOLD_BLOCK"

`Skills.Salvage.Anvil_Messages` = true

`Skills.Salvage.Anvil_Placed_Sounds` = true

`Skills.Salvage.Anvil_Use_Sounds` = true

`Skills.Salvage.Confirm_Required` = true

`Skills.Salvage.Level_Cap` = 0

`Skills.Smelting.Level_Cap` = 0

`Skills.Swords.Enabled_For_PVE` = true

`Skills.Swords.Enabled_For_PVP` = true

`Skills.Swords.Level_Cap` = 0

`Skills.Taming.Call_Of_The_Wild.Horse.Item_Amount` = 10

`Skills.Taming.Call_Of_The_Wild.Horse.Item_Material` = "APPLE"

`Skills.Taming.Call_Of_The_Wild.Horse.Per_Player_Limit` = 1

`Skills.Taming.Call_Of_The_Wild.Horse.Summon_Amount` = 1

`Skills.Taming.Call_Of_The_Wild.Horse.Summon_Length` = 240

`Skills.Taming.Call_Of_The_Wild.Ocelot.Item_Amount` = 10

`Skills.Taming.Call_Of_The_Wild.Ocelot.Item_Material` = "COD"

`Skills.Taming.Call_Of_The_Wild.Ocelot.Per_Player_Limit` = 1

`Skills.Taming.Call_Of_The_Wild.Ocelot.Summon_Amount` = 1

`Skills.Taming.Call_Of_The_Wild.Ocelot.Summon_Length` = 240

`Skills.Taming.Call_Of_The_Wild.Wolf.Item_Amount` = 10

`Skills.Taming.Call_Of_The_Wild.Wolf.Item_Material` = "BONE"

`Skills.Taming.Call_Of_The_Wild.Wolf.Per_Player_Limit` = 2

`Skills.Taming.Call_Of_The_Wild.Wolf.Summon_Amount` = 1

`Skills.Taming.Call_Of_The_Wild.Wolf.Summon_Length` = 240

`Skills.Taming.Enabled_For_PVE` = true

`Skills.Taming.Enabled_For_PVP` = true

`Skills.Taming.Level_Cap` = 0

`Skills.Tridents.Enabled_For_PVE` = true

`Skills.Tridents.Enabled_For_PVP` = true

`Skills.Tridents.Level_Cap` = 0

`Skills.Unarmed.Block_Cracker.SmoothBrick_To_CrackedBrick` = true

`Skills.Unarmed.Enabled_For_PVE` = true

`Skills.Unarmed.Enabled_For_PVP` = true

`Skills.Unarmed.Item_Pickup_Disabled_Full_Inventory` = false

`Skills.Unarmed.Items_As_Unarmed` = true

`Skills.Unarmed.Level_Cap` = 0

`Skills.Woodcutting.Level_Cap` = 0

`Skills.Woodcutting.Tree_Feller_Sounds` = true

## Sounds

`Sounds.MasterVolume` = 0.4

