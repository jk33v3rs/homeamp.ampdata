# Pl3xMap - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Settings

`settings.debug-mode` = false

`settings.internal-webserver.bind` = "0.0.0.0"

`settings.internal-webserver.enabled` = true

`settings.internal-webserver.follow-symlinks` = false

`settings.language-file` = "lang-en.yml"

`settings.map.zoom.delta` = 0.25

`settings.map.zoom.snap` = 0.25

`settings.map.zoom.wheel` = 120

`settings.performance.gc.when-finished` = true

`settings.performance.gc.when-running` = false

`settings.performance.live-update.enabled` = true

`settings.performance.live-update.threads` = -1

`settings.performance.render-threads` = -1

`settings.web-directory.path` = "web/"

`settings.web-directory.read-only` = false

`settings.web-directory.tile-format` = "png"

`settings.web-directory.tile-quality` = 0.0

## World-Settings

`world-settings.default.center.x` = -1

`world-settings.default.center.z` = -1

`world-settings.default.enabled` = true

`world-settings.default.render.biome-blend` = 3

`world-settings.default.render.heightmap-type` = "MODERN"

`world-settings.default.render.renderers.vintage_story` = "overworld_basic"

`world-settings.default.render.skylight` = 15

`world-settings.default.render.translucent-fluids` = true

`world-settings.default.render.translucent-glass` = true

`world-settings.default.render.visible-areas` = [{'type': 'world-border'}]

`world-settings.default.ui.attribution` = true

`world-settings.default.ui.blockinfo` = "bottomleft"

`world-settings.default.ui.coords` = "bottomcenter"

`world-settings.default.ui.link` = "bottomright"

`world-settings.default.ui.order` = 0

`world-settings.default.zoom.default` = 0

`world-settings.default.zoom.max-in` = 2

`world-settings.default.zoom.max-out` = 3

`world-settings.world.enabled` = true

`world-settings.world.render.renderers.vintage_story` = "overworld_basic"

`world-settings.world.ui.order` = 0

`world-settings.world_nether.render.renderers.basic` = "nether_basic"

`world-settings.world_nether.render.skylight` = 0

`world-settings.world_nether.ui.order` = 1

`world-settings.world_the_end.render.renderers.basic` = "the_end_basic"

`world-settings.world_the_end.render.skylight` = 0

`world-settings.world_the_end.ui.order` = 2

