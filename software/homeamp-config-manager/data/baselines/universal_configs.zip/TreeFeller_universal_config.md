# TreeFeller - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`allow-partial` = true

`allow-partial-tool` = false

`anim-delay` = 1

`auraskills-apply-modifiers` = true

`auraskills-leaves-xp` = [{'auraskills/foraging': 0}]

`auraskills-trunk-xp` = [{'auraskills/foraging': 1}]

`aureliumskills-apply-modifiers` = true

`aureliumskills-leaves-xp` = [{'foraging': 0}]

`aureliumskills-trunk-xp` = [{'foraging': 1}]

`banned-enchantments` = null

`banned-leaves` = null

`banned-logs` = null

`block-conversions` = null

`cascade` = true

`cascade-check-limit` = 64

`chat-command-usage` = "Usage: {0}"

`chat-debug-disable` = "Debug mode disabled"

`chat-debug-enable` = "Debug mode enabled"

`chat-no-permission` = "§cUnknown Command"

`chat-reload` = "Tree Feller reloaded!"

`chat-toggle-off` = "Tree Feller disabled"

`chat-toggle-on` = "Tree Feller enabled"

`chat-unknown-command` = "§cUnknown Command"

`compatibility-auraskills` = false

`compatibility-aureliumskills` = false

`compatibility-blockregen` = false

`compatibility-coreprotect` = true

`compatibility-drop2inventory` = true

`compatibility-ecojobs` = false

`compatibility-ecoskills` = false

`compatibility-griefprevention` = false

`compatibility-jobs` = true

`compatibility-lands` = false

`compatibility-logblock` = false

`compatibility-logblock-legacy` = false

`compatibility-mcmmo` = true

`compatibility-mcmmo-classic` = true

`compatibility-mmocore` = true

`compatibility-oreregenerator` = false

`compatibility-placeholderapi` = true

`compatibility-prism` = false

`compatibility-saberfactions` = false

`compatibility-towny` = false

`compatibility-worldguard` = true

`consumed-food-base` = 0.0

`consumed-food-leaves` = 0.0

`consumed-food-logs` = 0.0

`consumed-health-base` = 0.0

`consumed-health-leaves` = 0.0

`consumed-health-logs` = 0.0

`cooldown` = null

`custom-model-data` = null

`cutting-animation` = false

`damage-mult` = 1.0

`debug-allowed-trees-success` = "Tree is allowed for tool"

`debug-allowed-trees-tool` = "Tree is not allowed for tool: {0}"

`debug-banned-enchantments` = "Tool contains banned enchantment: {0} ({1}>{2})"

`debug-banned-enchantments-success` = "No banned enchantments found"

`debug-banned-enchantments-tool` = "Tool contains banned enchantment for tool: {0} ({1}>{2})"

`debug-banned-enchantments-tree` = "Tool contains banned enchantment for tree: {0} ({1}>{2})"

`debug-banned-leaves` = "Tree contains banned leaf: {0}"

`debug-banned-leaves-success` = "Tree does not contain any banned leaves"

`debug-banned-leaves-tool` = "Tree contains banned leaf for tool: {0}"

`debug-banned-leaves-tree` = "Tree contains banned leaf for tree: {0}"

`debug-banned-logs` = "Tree contains banned log: {0}"

`debug-banned-logs-success` = "Tree does not contain any banned logs"

`debug-banned-logs-tool` = "Tree contains banned log for tool: {0}"

`debug-banned-logs-tree` = "Tree contains banned log for tree: {0}"

`debug-checking` = "Checking tree #{0} with tool #{1}"

`debug-cooldown` = "Cooldown remaining: {0}ms"

`debug-cooldown-success` = "Cooldown ready"

`debug-cooldown-tool` = "Tool cooldown remaining: {0}ms"

`debug-cooldown-tree` = "Tree cooldown remaining: {0}ms"

`debug-custom-model-data` = "Custom model data does not match: {0} != {1}"

`debug-custom-model-data-success` = "Custom model data matches!"

`debug-custom-model-data-tool` = "Custom model data does not match for tool: {0} != {1}"

`debug-custom-model-data-tree` = "Custom model data does not match for tree: {0} != {1}"

`debug-durability-low` = "Tool durability is too low: {0}<{1}"

`debug-enable-adventure` = "TreeFeller is disabled in adventure mode"

`debug-enable-adventure-success` = "All components OK for adventure mode"

`debug-enable-adventure-tool` = "Tool is disabled in adventure mode"

`debug-enable-adventure-tree` = "Tree is disabled in adventure mode"

`debug-enable-creative` = "TreeFeller is disabled in creative mode"

`debug-enable-creative-success` = "All components OK for creative mode"

`debug-enable-creative-tool` = "Tool is disabled in creative mode"

`debug-enable-creative-tree` = "Tree is disabled in creative mode"

`debug-enable-survival` = "TreeFeller is disabled in survival mode"

`debug-enable-survival-success` = "All components OK for survival mode"

`debug-enable-survival-tool` = "Tool is disabled in survival mode"

`debug-enable-survival-tree` = "Tree is disabled in survival mode"

`debug-max-durability` = "Tool durability is greater than maximum allowed: {0}>{1}"

`debug-max-durability-percent` = "Tool durability is greater than maximum allowed: {0}%>{1}%"

`debug-max-durability-percent-success` = "Tool meets maximum durability percentage requirement"

`debug-max-durability-percent-tool` = "Tool durability is greater than maximum allowed: {0}%>{1}%"

`debug-max-durability-percent-tree` = "Tool durability is greater than maximum allowed: {0}%>{1}%"

`debug-max-durability-success` = "Tool meets maximum durability requirement"

`debug-max-durability-tool` = "Tool durability is greater than maximum allowed: {0}>{1}"

`debug-max-durability-tree` = "Tool durability is greater than maximum allowed: {0}>{1}"

`debug-max-food` = "Too much food: {0}>{1}"

`debug-max-food-success` = "Food meets maximum requirement"

`debug-max-food-tool` = "Too much food for tool: {0}>{1}"

`debug-max-food-tree` = "Too much food for tree: {0}>{1}"

`debug-max-health` = "Too much health: {0}>{1}"

`debug-max-health-success` = "Health meets maximum requirement"

`debug-max-health-tool` = "Too much health for tool: {0}>{1}"

`debug-max-health-tree` = "Too much health for tree: {0}>{1}"

`debug-max-height` = "Tree was cut {0} blocks too high"

`debug-max-height-ratio` = "Tree height ratio is too high! {0}>{1}"

`debug-max-height-ratio-success` = "Tree height ratio is below maximum"

`debug-max-height-ratio-tool` = "Tree height ratio is too high for tool! {0}>{1}"

`debug-max-height-ratio-tree` = "Tree height ratio is too high for tree! {0}>{1}"

`debug-max-height-success` = "Tree was cut low enough"

`debug-max-height-tool` = "Tree was cut {0} blocks too high for tool"

`debug-max-height-tree` = "Tree was cut {0} blocks too high for tree"

`debug-max-horizontal-trunk-pillar-length` = "Found a horizontal trunk pillar that was too long! {0}>{1}"

`debug-max-horizontal-trunk-pillar-length-success` = "No excessive horizontal trunk pillars found"

`debug-max-horizontal-trunk-pillar-length-tool` = "Found a horizontal trunk pillar that was too long for tool! {0}>{1}"

`debug-max-horizontal-trunk-pillar-length-tree` = "Found a horizontal trunk pillar that was too long for tree! {0}>{1}"

`debug-max-logs` = "Tree has too many logs: {0}>{1}"

`debug-max-logs-success` = "Tree has few enough logs"

`debug-max-logs-tool` = "Tree has too many logs for tool: {0}>{1}"

`debug-max-logs-tree` = "Tree has too many logs for tree: {0}>{1}"

`debug-max-phase` = "Phase is greater than maximum allowed: {0}>{1}"

`debug-max-phase-success` = "Phase meets maximum requirement"

`debug-max-phase-tool` = "Phase is greater than maximum allowed for tool: {0}>{1}"

`debug-max-phase-tree` = "Phase is greater than maximum allowed for tree: {0}>{1}"

`debug-max-time` = "Time is greater than maximum allowed: {0}>{1}"

`debug-max-time-success` = "Time meets maximum requirement"

`debug-max-time-tool` = "Time is greater than maximum allowed for tool: {0}>{1}"

`debug-max-time-tree` = "Time is greater than maximum allowed for tree: {0}>{1}"

`debug-max-trunks` = "Tree has too many trunks! {0}>{1}"

`debug-max-trunks-success` = "Trunk count is valid"

`debug-max-trunks-tool` = "Tree has too many trunks for tool! {0}>{1}"

`debug-max-trunks-tree` = "Tree has too many trunks for tree! {0}>{1}"

`debug-max-vertical-log-ratio` = "Tree vertical log ratio is too high! {0}>{1}"

`debug-max-vertical-log-ratio-success` = "Tree vertical log ratio is below maximum"

`debug-max-vertical-log-ratio-tool` = "Tree vertical log ratio is too high for tool! {0}>{1}"

`debug-max-vertical-log-ratio-tree` = "Tree vertical log ratio is too high for tree! {0}>{1}"

`debug-min-durability` = "Tool durability is less than minimum allowed: {0}<{1}"

`debug-min-durability-percent` = "Tool durability is less than minimum allowed: {0}%<{1}%"

`debug-min-durability-percent-success` = "Tool meets minimum durability percentage requirement"

`debug-min-durability-percent-tool` = "Tool durability is less than minimum allowed for tool: {0}%<{1}%"

`debug-min-durability-percent-tree` = "Tool durability is less than minimum allowed for tree: {0}%<{1}%"

`debug-min-durability-success` = "Tool meets minimum durability requirement"

`debug-min-durability-tool` = "Tool durability is less than minimum allowed for tool: {0}<{1}"

`debug-min-durability-tree` = "Tool durability is less than minimum allowed for tree: {0}<{1}"

`debug-min-food` = "Not enough food: {0}<{1}"

`debug-min-food-success` = "Food meets minimum requirement"

`debug-min-food-tool` = "Not enough food for tool: {0}<{1}"

`debug-min-food-tree` = "Not enough food for tree: {0}<{1}"

`debug-min-health` = "Not enough health: {0}<{1}"

`debug-min-health-success` = "Health meets minimum requirement"

`debug-min-health-tool` = "Not enough health for tool: {0}<{1}"

`debug-min-health-tree` = "Not enough health for tree: {0}<{1}"

`debug-min-height-ratio` = "Tree height ratio is too low! {0}<{1}"

`debug-min-height-ratio-success` = "Tree height ratio is above minimum"

`debug-min-height-ratio-tool` = "Tree height ratio is too low for tool! {0}<{1}"

`debug-min-height-ratio-tree` = "Tree height ratio is too low for tree! {0}<{1}"

`debug-min-phase` = "Phase is less than minimum allowed: {0}<{1}"

`debug-min-phase-success` = "Phase meets minimum requirement"

`debug-min-phase-tool` = "Phase is less than minimum allowed for tool: {0}<{1}"

`debug-min-phase-tree` = "Phase is less than minimum allowed for tree: {0}<{1}"

`debug-min-time` = "Time is less than minimum allowed: {0}<{1}"

`debug-min-time-success` = "Time meets minimum requirement"

`debug-min-time-tool` = "Time is less than minimum allowed for tool: {0}<{1}"

`debug-min-time-tree` = "Time is less than minimum allowed for tree: {0}<{1}"

`debug-min-vertical-log-ratio` = "Tree vertical log ratio is too low! {0}<{1}"

`debug-min-vertical-log-ratio-success` = "Tree vertical log ratio is above minimum"

`debug-min-vertical-log-ratio-tool` = "Tree vertical log ratio is too low for tool! {0}<{1}"

`debug-min-vertical-log-ratio-tree` = "Tree vertical log ratio is too low for tree! {0}<{1}"

`debug-mmocore-required-profession-level` = "Insufficient MMOCore profession level: {2} - {0}<{1}"

`debug-mmocore-required-profession-level-success` = "All MMOCore profession requirements met"

`debug-mmocore-required-profession-level-tool` = "Insufficient MMOCore profession level for tool: {2} - {0}<{1}"

`debug-mmocore-required-profession-level-tree` = "Insufficient MMOCore profession level for tree: {2} - {0}<{1}"

`debug-partial` = "Tool is cutting partial tree"

`debug-partial-tool` = "Tool has partial durability"

`debug-prevent-breakage` = "Felling this tree would break the tool"

`debug-prevent-breakage-success` = "Felling this tree won't break the tool"

`debug-protected` = "This tree is protected by {0} at {1} {2} {3}"

`debug-require-cross-section` = "A full cross-section has not been cut at ({0}, {1}, {2})"

`debug-require-cross-section-success` = "A full cross-section has been cut"

`debug-require-cross-section-tool` = "A full cross-section has not been cut for tool at ({0}, {1}, {2})"

`debug-require-cross-section-tree` = "A full cross-section has not been cut for tree at ({0}, {1}, {2})"

`debug-required-enchantments` = "Enchantment missing: {0} ({1}<{2})"

`debug-required-enchantments-success` = "All required enchantments met"

`debug-required-enchantments-tool` = "Enchantment missing for tool: {0} ({1}<{2})"

`debug-required-enchantments-tree` = "Enchantment missing for tree: {0} ({1}<{2})"

`debug-required-leaves` = "Tree has too few leaves: {0}<{1}"

`debug-required-leaves-success` = "Tree has enough leaves"

`debug-required-leaves-tool` = "Tree has too few leaves for tool: {0}<{1}"

`debug-required-leaves-tree` = "Tree has too few leaves for tree: {0}<{1}"

`debug-required-logs` = "Tree has too few logs: {0}<{1}"

`debug-required-logs-success` = "Tree has enough logs"

`debug-required-logs-tool` = "Tree has too few logs for tool: {0}<{1}"

`debug-required-logs-tree` = "Tree has too few logs for tree: {0}<{1}"

`debug-required-lore` = "Tool is missing required lore: {0}"

`debug-required-lore-success` = "Tool has all required lore"

`debug-required-lore-tool` = "Tool is missing required lore for tool: {0}"

`debug-required-lore-tree` = "Tool is missing required lore for tree: {0}"

`debug-required-name` = "Tool name {0} §rdoes not match required name: {1}"

`debug-required-name-success` = "Tool name matches"

`debug-required-name-tool` = "Tool name {0} §rdoes not match required name for tool: {1}"

`debug-required-name-tree` = "Tool name {0} §rdoes not match required name for tree: {1}"

`debug-required-permissions` = "Player is missing required permission: {0}"

`debug-required-permissions-success` = "Player has all required permissions"

`debug-required-permissions-tool` = "Player is missing required permission for tool: {0}"

`debug-required-permissions-tree` = "Player is missing required permission for tree: {0}"

`debug-success` = "Success! Felling tree..."

`debug-toggle` = "Tree feller is currently toggled off"

`debug-with-sneak` = "TreeFeller is disabled when sneaking"

`debug-with-sneak-success` = "Felling allowed when sneaking"

`debug-with-sneak-tool` = "Tool is disabled when sneaking"

`debug-with-sneak-tree` = "Tree is disabled when sneaking"

`debug-without-sneak` = "TreeFeller is disabled when not sneaking"

`debug-without-sneak-success` = "Felling allowed when not sneaking"

`debug-without-sneak-tool` = "Tool is disabled when not sneaking"

`debug-without-sneak-tree` = "Tree is disabled when not sneaking"

`debug-worlds` = "World {0} is invalid"

`debug-worlds-success` = "World {0} is valid"

`debug-worlds-tool` = "World {0} is invalid for tool"

`debug-worlds-tree` = "World {0} is invalid for tree"

`decorations` = ['snow', 'vines', 'cocoa', 'weeping vines', 'moss', 'pale moss carpet', 'pale hanging moss']

`default-enabled` = true

`diagonal-leaves` = false

`directional-fall-behavior` = "RANDOM"

`directional-fall-velocity` = 0.35

`ecojobs-apply-multipliers` = true

`ecojobs-leaf-xp` = null

`ecojobs-trunk-xp` = null

`ecoskills-leaves-xp` = [{'woodcutting': 0}]

`ecoskills-tree-xp` = [{'woodcutting': 0}]

`ecoskills-trunk-xp` = [{'Woodcutting': 10}]

`effects` = null

`enable-adventure` = false

`enable-creative` = true

`enable-survival` = true

`explosive-fall-velocity` = 0.0

`fall-delay` = 0

`fall-hurt-amount` = 1.0

`fall-hurt-max` = 20

`force-distance-check` = false

`global-effects` = ['ALL']

`grass` = ['DIRT', 'GRASS_BLOCK', 'PODZOL']

`ignore-leaf-data` = false

`leaf-behavior` = "BREAK"

`leaf-break-range` = 6

`leaf-detect-range` = 6

`leaf-drop-chance` = 1.0

`leaf-fortune` = true

`leaf-silk-touch` = true

`leave-stump` = false

`lock-fall-cardinal` = false

`log-behavior` = "BREAK"

`log-drop-chance` = 1.0

`log-fortune` = true

`log-silk-touch` = true

`max-durability` = null

`max-durability-percent` = null

`max-food` = null

`max-health` = null

`max-height` = 3

`max-height-ratio` = null

`max-horizontal-trunk-pillar-length` = 6

`max-logs` = 4096

`max-phase` = null

`max-time` = null

`max-trunks` = null

`max-vertical-log-ratio` = null

`mcmmo-double-drops` = true

`min-durability` = null

`min-durability-percent` = null

`min-food` = null

`min-health` = null

`min-height-ratio` = null

`min-phase` = null

`min-time` = null

`min-vertical-log-ratio` = 0.5

`mmocore-emulate-regen` = false

`mmocore-leaves-xp` = [{'woodcutting': 1}]

`mmocore-required-profession-level` = null

`mmocore-tree-xp` = [{'woodcutting': 0}]

`mmocore-trunk-xp` = [{'woodcutting': 10}]

`oreregenerator-regen-delay` = 1200

`overridables` = ['AIR', 'CAVE_AIR', 'FERN', 'GRASS', 'LARGE_FERN', 'SEAGRASS', 'TALL_GRASS', 'TALL_SEAGRASS', 'WATER']

`parallel-cascade-limit` = 1

`player-leaves` = false

`prevent-breakage` = true

`random-fall-velocity` = 0.0

`replant-saplings` = true

`require-cross-section` = false

`required-enchantments` = null

`required-leaves` = 8

`required-logs` = 4

`required-lore` = null

`required-name` = null

`required-permissions` = null

`respect-unbreakable` = true

`respect-unbreaking` = true

`root-distance` = 6

`rotate-logs` = true

`sapling-timeout` = 50

`scan-distance` = 512

`spawn-saplings` = 0

`stacked-tools` = false

`startup-logs` = true

`tools` = ['DIAMOND_AXE', 'NETHERITE_AXE']

`trees` = [[['OAK_LOG', 'OAK_WOOD'], 'OAK_LEAVES', {'sapling': 'OAK_SAPLING', 'max-saplings': 1}], [['BIRCH_LOG', 'BIRCH_WOOD'], 'BIRCH_LEAVES', {'sapling': 'BIRCH_SAPLING', 'max-saplings': 1}], [['SPRUCE_LOG', 'SPRUCE_WOOD'], 'SPRUCE_LEAVES', {'sapling': 'SPRUCE_SAPLING', 'max-saplings': 4}], [['JUNGLE_LOG', 'JUNGLE_WOOD'], 'JUNGLE_LEAVES', {'sapling': 'JUNGLE_SAPLING', 'max-saplings': 4}], [['DARK_OAK_LOG', 'DARK_OAK_WOOD'], 'DARK_OAK_LEAVES', {'sapling': 'DARK_OAK_SAPLING', 'max-saplings': 4}], [['ACACIA_LOG', 'ACACIA_WOOD'], 'ACACIA_LEAVES', {'sapling': 'ACACIA_SAPLING', 'max-saplings': 1}], [['OAK_LOG', 'OAK_WOOD'], ['AZALEA_LEAVES', 'FLOWERING_AZALEA_LEAVES'], {'sapling': ['AZALEA', 'FLOWERING_AZALEA'], 'max-saplings': 1, 'diagonal-leaves': True}], [['MANGROVE_LOG', 'MANGROVE_WOOD'], ['MANGROVE_ROOTS', 'MANGROVE_LEAVES'], {'roots': ['MANGROVE_ROOTS'], 'sapling': ['MANGROVE_PROPAGULE'], 'max-saplings': 1, 'max-trunks': 16, 'max-horizontal-trunk-pillar-length': 16, 'leaf-detect-range': 16, 'leaf-break-range': 16, 'required-logs': 3, 'root-distance': 16, 'diagonal-leaves': True}], [['CHERRY_LOG', 'CHERRY_WOOD'], 'CHERRY_LEAVES', {'sapling': 'CHERRY_SAPLING', 'max-saplings': 1}], [['PALE_OAK_LOG', 'PALE_OAK_WOOD'], 'PALE_OAK_LEAVES', {'sapling': 'PALE_OAK_SAPLING', 'max-saplings': 4}], [['CRIMSON_STEM', 'CRIMSON_HYPHAE'], ['NETHER_WART_BLOCK', 'SHROOMLIGHT'], {'sapling': 'CRIMSON_FUNGUS', 'max-saplings': 1, 'grass': ['CRIMSON_NYLIUM'], 'diagonal-leaves': True, 'leaf-detect-range': 8, 'leaf-break-range': 8}], [['WARPED_STEM', 'WARPED_HYPHAE'], ['WARPED_WART_BLOCK', 'SHROOMLIGHT'], {'sapling': 'WARPED_FUNGUS', 'max-saplings': 1, 'grass': ['WARPED_NYLIUM'], 'diagonal-leaves': True, 'leaf-detect-range': 8, 'leaf-break-range': 8}]]

`use-inventory-saplings` = false

`use-tree-saplings` = true

`vertical-fall-velocity` = 0.05

`with-sneak` = true

`without-sneak` = false

`world-blacklist` = false

`worlds` = null

## Drop-Conversions

`drop-conversions.ACACIA_WOOD` = "ACACIA_LOG"

`drop-conversions.BIRCH_WOOD` = "BIRCH_LOG"

`drop-conversions.CHERRY_WOOD` = "CHERRY_LOG"

`drop-conversions.CRIMSON_HYPHAE` = "CRIMSON_STEM"

`drop-conversions.DARK_OAK_WOOD` = "DARK_OAK_LOG"

`drop-conversions.JUNGLE_WOOD` = "JUNGLE_LOG"

`drop-conversions.MANGROVE_WOOD` = "MANGROVE_LOG"

`drop-conversions.OAK_WOOD` = "OAK_LOG"

`drop-conversions.PALE_OAK_WOOD` = "PALE_OAK_LOG"

`drop-conversions.SPRUCE_WOOD` = "SPRUCE_LOG"

`drop-conversions.WARPED_HYPHAE` = "WARPED_STEM"

