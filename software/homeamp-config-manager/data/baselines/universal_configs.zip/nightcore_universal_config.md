# nightcore - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Datafixer

`DataFixer.MissingVersion` = 4189

`DataFixer.UnknownVersion` = 10000

## Engine

`Engine.Legacy_Color_Support` = true

## Menu

`Menu.Click_Cooldown` = 150

## Number

`Number.Format.Format` = "#,###.###"

`Number.Format.Locale` = "en-US"

`Number.Format.Rounding` = "HALF_EVEN"

`Number.Shortcut_List.billion.Magnitude` = 3

`Number.Shortcut_List.billion.Name` = "b"

`Number.Shortcut_List.million.Magnitude` = 2

`Number.Shortcut_List.million.Name` = "m"

`Number.Shortcut_List.quadrillion.Magnitude` = 5

`Number.Shortcut_List.quadrillion.Name` = "q"

`Number.Shortcut_List.thousand.Magnitude` = 1

`Number.Shortcut_List.thousand.Name` = "k"

`Number.Shortcut_List.trillion.Magnitude` = 4

`Number.Shortcut_List.trillion.Name` = "t"

`Number.Shortcut_Step` = 1000

## Time

`Time.TimeZone` = "Etc/UTC"

## Userdata

`UserData.Cache.LifeTime` = 300

