# CraftBook5 - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`debug-flags` = []

`debug-mode` = false

`debug-mode-file-logging` = false

`indirect-redstone` = false

`no-op-permissions` = false

`obey-plugin-protections` = true

`obey-worldguard-flags` = true

`safe-destruction` = true

`show-permission-messages` = true

`sign-click-timeout` = 500

`st-think-ticks` = 2

## Mechanics

`mechanics.boat.boat_empty_decay` = false

`mechanics.boat.boat_exit_remover` = false

`mechanics.boat.boat_impact_damage` = false

`mechanics.circuit.jack_o_lantern` = false

`mechanics.circuit.redstone_fire` = false

`mechanics.circuit.redstone_glowstone` = false

`mechanics.circuit.redstone_jukebox` = false

`mechanics.general.better_ai` = false

`mechanics.general.better_leads` = false

`mechanics.general.better_physics` = false

`mechanics.general.better_pistons` = false

`mechanics.general.better_plants` = false

`mechanics.general.better_sponge` = false

`mechanics.general.bridge` = false

`mechanics.general.chairs` = false

`mechanics.general.chunk_anchor` = false

`mechanics.general.cooking_pot` = false

`mechanics.general.dispenser_recipes` = false

`mechanics.general.door` = false

`mechanics.general.elevator` = false

`mechanics.general.gate` = false

`mechanics.general.head_drops` = false

`mechanics.general.hidden_switch` = false

`mechanics.general.light_switch` = false

`mechanics.general.marquee` = false

`mechanics.general.readable_bookshelf` = false

`mechanics.general.snow` = false

`mechanics.general.teleporter` = false

`mechanics.general.toggle_area` = false

`mechanics.general.tree_lopper` = false

`mechanics.general.variables` = true

`mechanics.general.xp_storer` = false

`mechanics.minecart.minecart_booster` = false

`mechanics.minecart.minecart_collision_entry` = false

`mechanics.minecart.minecart_dispenser` = false

`mechanics.minecart.minecart_ejector` = false

`mechanics.minecart.minecart_elevator` = false

`mechanics.minecart.minecart_empty_decay` = false

`mechanics.minecart.minecart_exit_remover` = false

`mechanics.minecart.minecart_impact_damage` = false

`mechanics.minecart.minecart_item_pickup` = false

`mechanics.minecart.minecart_light_braker` = false

`mechanics.minecart.minecart_max_booster` = false

`mechanics.minecart.minecart_no_collide` = false

`mechanics.minecart.minecart_physics_control` = false

`mechanics.minecart.minecart_rail_placer` = false

`mechanics.minecart.minecart_reverser` = false

`mechanics.minecart.minecart_station` = false

`mechanics.minecart.minecart_strong_braker` = false

`mechanics.minecart.minecart_teleporter` = false

`mechanics.minecart.more_rails` = false

`mechanics.minecart.temporary_cart` = false

`mechanics.tool.ammeter` = false

`mechanics.tool.lightstone` = false

`mechanics.tool.sign_copier` = false

