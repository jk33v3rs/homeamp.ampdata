# Chunky - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`continue-on-restart` = false

`force-load-existing-chunks` = false

`language` = "en"

`silent` = false

`update-interval` = 1

`version` = 2

