# TheNewEconomy - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Core

`Core.Commands.Balance.Currency` = "money"

`Core.Commands.Balance.Restrict` = false

`Core.Commands.Exclusions` = ['^town-.*', '^nation-.*', '^faction-.*', '^towny-.*']

`Core.Commands.GUIAlternatives` = true

`Core.Commands.LimitCurrency` = false

`Core.Commands.Pay.Offline` = true

`Core.Commands.Pay.Radius` = 0

`Core.Commands.Top.Exclusions` = ['^town-.*', '^nation-.*', '^faction-.*', '^towny-.*']

`Core.Commands.Top.Format` = true

`Core.Commands.Top.Refresh` = 1200

`Core.Debugging.Mode` = false

`Core.Offline` = false

`Core.PlaceholderTransactions` = true

`Core.Region.DefaultRegion` = "SMP"

`Core.Region.DisabledRegions` = ['ExampleWorld']

`Core.Region.GroupRealms` = true

`Core.Region.Mode` = "world"

`Core.Region.MultiRegion` = false

`Core.Region.SharedRegions.ExampleRegion` = "test"

`Core.Server.Account.Balance` = 50000

`Core.Server.Account.Enabled` = true

`Core.Server.ExperienceGain` = false

`Core.Server.Geyser` = "."

`Core.Server.ImportItems` = true

`Core.Server.MobDrop` = false

`Core.Server.RandomUUID` = false

`Core.Transactions.Conversion.Tax.Enabled` = false

`Core.Transactions.Conversion.Tax.Rate` = 0.0

`Core.Transactions.Deposit.Tax.Enabled` = false

`Core.Transactions.Deposit.Tax.Rate` = 0.0

`Core.Transactions.Format` = "YYYY/MM/dd HH:mm"

`Core.Transactions.History.Refresh` = 1200

`Core.Transactions.Pay.Tax.Enabled` = false

`Core.Transactions.Pay.Tax.Receiver` = 0.0

`Core.Transactions.Pay.Tax.Sender` = 0.0

`Core.Transactions.Record` = true

`Core.Transactions.Timezone` = "UTC"

`Core.Transactions.Tracking.Amount` = "400"

`Core.Transactions.Tracking.Enabled` = true

`Core.Transactions.Withdraw.Tax.Enabled` = false

`Core.Transactions.Withdraw.Tax.Rate` = 0.0

`Core.Update.Check` = true

`Core.Update.Notify` = true

`Core.config-version` = 7

