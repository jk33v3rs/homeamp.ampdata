# LightAPI - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`colored-log` = true

`debug` = false

`max-iterations-per-tick` = 400

`message-prefix` = ""

`update-delay-ticks` = 2

`version` = 3

## Updater

`updater.enable` = true

`updater.repo` = "Qveshn/LightAPI"

`updater.update-delay-ticks` = 40

`updater.view-changelog` = false

