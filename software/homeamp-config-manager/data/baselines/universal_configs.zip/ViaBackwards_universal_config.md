# ViaBackwards - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`add-custom-enchants-into-lore` = true

`add-teamcolor-to-prefix` = true

`always-show-original-mob-name` = true

`bedrock-at-y-0` = false

`fix-1_13-face-player` = false

`fix-formatted-inventory-titles` = true

`handle-pings-as-inv-acknowledgements` = false

`map-custom-model-data` = true

`map-darkness-effect` = true

`map-display-entities` = true

`scaffolding-to-water` = false

`sculk-shriekers-to-crying-obsidian` = true

`suppress-emulation-warnings` = false

