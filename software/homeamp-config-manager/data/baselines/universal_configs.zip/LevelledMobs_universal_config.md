# LevelledMobs Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
customdrops.ALLAY: [None]
customdrops.ARMADILLO: [None]
customdrops.AXOLOTL: [None]
customdrops.BAT: [None]
customdrops.BEE: [None]
customdrops.BLAZE: [None]
customdrops.CAMEL: [None]
customdrops.CAT: [None]
customdrops.CAVE_SPIDER: [None]
customdrops.CHICKEN: [None]
customdrops.COD: [None]
customdrops.COW: [None]
customdrops.CREEPER: [None]
customdrops.DOLPHIN: [None]
customdrops.DONKEY: [None]
customdrops.DROWNED: [None]
customdrops.ELDER_GUARDIAN: [None]
customdrops.ENDERMAN: [None]
customdrops.ENDERMITE: [None]
customdrops.ENDER_DRAGON: [None]
customdrops.EVOKER: [None]
customdrops.FOX: [None]
customdrops.FROG: [None]
customdrops.GHAST: [None]
customdrops.GLOW_SQUID: [None]
customdrops.GOAT: [None]
customdrops.GUARDIAN: [None]
customdrops.HOGLIN: [None]
customdrops.HORSE: [None]
customdrops.HUSK: [None]
customdrops.ILLUSIONER: [None]
customdrops.IRON_GOLEM: [None]
customdrops.LLAMA: [None]
customdrops.MAGMA_CUBE: [None]
customdrops.MULE: [None]
customdrops.MUSHROOM_COW: [None]
customdrops.OCELOT: [None]
customdrops.PANDA: [None]
customdrops.PARROT: [None]
customdrops.PHANTOM: [None]
customdrops.PIG: [None]
customdrops.PIGLIN: [None]
customdrops.PIGLIN_BRUTE: [None]
customdrops.PILLAGER: [None]
customdrops.POLAR_BEAR: [None]
customdrops.PUFFERFISH: [None]
customdrops.RABBIT: [None]
customdrops.RAVAGER: [None]
customdrops.SALMON: [None]
customdrops.SHEEP: [None]
customdrops.SHULKER: [None]
customdrops.SILVERFISH: [None]
customdrops.SKELETON: [None]
customdrops.SKELETON_HORSE: [None]
customdrops.SLIME: [None]
customdrops.SNIFFER: [None]
customdrops.SNOWMAN: [None]
customdrops.SPIDER: [None]
customdrops.SQUID: [None]
customdrops.STRAY: [None]
customdrops.STRIDER: [None]
customdrops.TADPOLE: [None]
customdrops.TRADER_LLAMA: [None]
customdrops.TROPICAL_FISH: [None]
customdrops.TURTLE: [None]
customdrops.VEX: [None]
customdrops.VILLAGER: [None]
customdrops.VINDICATOR: [None]
customdrops.WANDERING_TRADER: [None]
customdrops.WARDEN: [None]
customdrops.WITCH: [None]
customdrops.WITHER: [None]
customdrops.WITHER_SKELETON: [None]
customdrops.WOLF: [None]
customdrops.ZOGLIN: [None]
customdrops.ZOMBIE: [None]
customdrops.ZOMBIE_HORSE: [None]
customdrops.ZOMBIE_VILLAGER: [None]
customdrops.ZOMBIFIED_PIGLIN: [None]
customdrops.all_aquatic_mobs: [None]
customdrops.all_flying_mobs: [None]
customdrops.all_ground_mobs: [None]
customdrops.all_hostile_mobs: [None]
customdrops.all_levellable_mobs: [None]
customdrops.all_mobs: [None]
customdrops.all_nether_mobs: [None]
customdrops.all_overworld_mobs: [None]
customdrops.all_passive_mobs: [None]
customdrops.defaults.amount: 1
customdrops.defaults.chance: 0.2
customdrops.defaults.delay: 0
customdrops.defaults.equip-offhand: True
customdrops.defaults.equip-on-helmet: False
customdrops.defaults.equipped: 1.0
customdrops.defaults.group-limits.cap-equipped: -1
customdrops.defaults.group-limits.cap-per-item: -1
customdrops.defaults.group-limits.cap-select: 1
customdrops.defaults.group-limits.cap-total: -1
customdrops.defaults.group-limits.retries: 0
customdrops.defaults.groupid: 
customdrops.defaults.item-flags: 
customdrops.defaults.maxLevel: -1
customdrops.defaults.minLevel: -1
customdrops.defaults.nomultiplier: True
customdrops.defaults.nospawner: False
customdrops.defaults.only-drop-if-equipped: False
customdrops.defaults.overall-chance: 1.0
customdrops.defaults.overall-permission: 
customdrops.defaults.override: False
customdrops.defaults.player-caused: True
customdrops.defaults.run-on-death: True
customdrops.defaults.run-on-spawn: False
customdrops.defaults.use-chunk-kill-max: True
customdrops.drop-table.armor_and_weapons: [{'IRON_HELMET': {'chance': 0.005, 'equipped': 0.05, 'group-limits': {'cap-equipped': 2, 'cap-per-item': -1, 'cap-total': 2}, 'groupid': 'iron_armor'}}, {'IRON_CHESTPLATE': {'chance': 0.005, 'equipped': 0.05, 'groupid': 'iron_armor'}}, {'IRON_LEGGINGS': {'chance': 0.005, 'equipped': 0.05, 'groupid': 'iron_armor'}}, {'IRON_BOOTS': {'chance': 0.005, 'equipped': 0.05, 'groupid': 'iron_armor'}}, {'IRON_SWORD': {'chance': 0.005, 'equipped': 0.05, 'group-limits': {'cap-equipped': 1, 'cap-per-item': -1, 'cap-total': 1}, 'groupid': 'iron_weapons'}}, {'IRON_AXE': {'chance': 0.005, 'equipped': 0.05, 'groupid': 'iron_weapons'}}]
customdrops.file-version: 12
externalplugins.Deadly-Disasters.friendly-name: deadly-disasters
externalplugins.Deadly-Disasters.key-name: customentity
externalplugins.Deadly-Disasters.key-type: PDC
externalplugins.Deadly-Disasters.plugin-name: DeadlyDisasters
externalplugins.Deadly-Disasters.requirement: exists
externalplugins.blood-night.friendly-name: blood-night
externalplugins.blood-night.key-name: mobtype
externalplugins.blood-night.key-type: PDC
externalplugins.blood-night.plugin-name: BloodNight
externalplugins.blood-night.requirement: exists
externalplugins.combat-pets.friendly-name: combat-pets
externalplugins.combat-pets.key-name: attribute.health_regeneration_speed
externalplugins.combat-pets.key-type: PDC
externalplugins.combat-pets.key-valuetype: double
externalplugins.combat-pets.plugin-name: CombatPets
externalplugins.combat-pets.requirement: exists
externalplugins.eco-bosses.friendly-name: eco-bosses
externalplugins.eco-bosses.key-name: boss
externalplugins.eco-bosses.key-type: PDC
externalplugins.eco-bosses.plugin-name: EcoBosses
externalplugins.eco-bosses.requirement: exists
externalplugins.file-version: 1
externalplugins.gadgets-menu.friendly-name: gadgets-menu
externalplugins.gadgets-menu.key-name: GadgetsMenu-Pet
externalplugins.gadgets-menu.key-type: metadata
externalplugins.gadgets-menu.plugin-name: GadgetsMenu
externalplugins.gadgets-menu.requirement: exists
externalplugins.infernal-mobs.friendly-name: infernal-mobs
externalplugins.infernal-mobs.key-name: infernalMetadata
externalplugins.infernal-mobs.key-type: metadata
externalplugins.infernal-mobs.plugin-name: InfernalMobs
externalplugins.infernal-mobs.requirement: exists
externalplugins.my-pet.friendly-name: my-pet
externalplugins.my-pet.key-name: MyPet
externalplugins.my-pet.key-type: metadata
externalplugins.my-pet.plugin-name: MyPet
externalplugins.my-pet.requirement: exists
externalplugins.shop-keepers.friendly-name: shop-keepers
externalplugins.shop-keepers.key-name: shopkeeper
externalplugins.shop-keepers.key-type: metadata
externalplugins.shop-keepers.plugin-name: ShopKeepers
externalplugins.shop-keepers.requirement: exists
rules.biome-groups.cave_biomes: ['LUSH_CAVES', 'DRIPSTONE_CAVES', 'DEEP_DARK']
rules.default-rule.conditions.entities: ['*']
rules.default-rule.conditions.mob-customname-status: EITHER
rules.default-rule.conditions.mob-tamed-status: EITHER
rules.default-rule.conditions.worlds: ['*']
rules.default-rule.settings.baby-mobs-inherit-adult-setting: True
rules.default-rule.settings.construct-level: %distance-from-origin% + %weighted-random% + %player-variable-mod% + %custom_special% + %rand_-5_5%
rules.default-rule.settings.creeper-max-damage-radius: 3
rules.default-rule.settings.health-indicator.colored-tiers.default: &#B447FF
rules.default-rule.settings.health-indicator.colored-tiers.tier-1: &#22E76B
rules.default-rule.settings.health-indicator.colored-tiers.tier-2: &#528CFF
rules.default-rule.settings.health-indicator.colored-tiers.tier-3: &#FFCD56
rules.default-rule.settings.health-indicator.colored-tiers.tier-4: &#FE803C
rules.default-rule.settings.health-indicator.colored-tiers.tier-5: &#F2003D
rules.default-rule.settings.health-indicator.colored-tiers.tier-6: &#B447FF
rules.default-rule.settings.health-indicator.max: 5
rules.default-rule.settings.health-indicator.scale: 5
rules.default-rule.settings.minLevel: 1
rules.default-rule.settings.multipliers.vanilla-bonus.excluded-list: ['LEADER_ZOMBIE_BONUS', 'RANDOM_SPAWN_BONUS']
rules.default-rule.settings.nametag-placeholder-levelled: 
rules.default-rule.settings.nametag-placeholder-unlevelled: 
rules.default-rule.settings.nametag-visibility-method: ['TARGETED', 'ATTACKED', 'TRACKING']
rules.default-rule.settings.nametag-visible-time: 5s
rules.default-rule.settings.spawner-particles: SOUL
rules.default-rule.settings.spawner-particles-count: 10
rules.default-rule.settings.sunlight-intensity: 5
rules.default-rule.settings.tiered-coloring.1-09: &#22E76B
rules.default-rule.settings.tiered-coloring.10-19: &#528CFF
rules.default-rule.settings.tiered-coloring.20-29: &#FFCD56
rules.default-rule.settings.tiered-coloring.30-39: &#F2003D
rules.default-rule.settings.tiered-coloring.40-49: &#B447FF
rules.default-rule.settings.tiered-coloring.50-50: &#FFD700
rules.default-rule.settings.tiered-coloring.default: &#FFFFFF
rules.default-rule.settings.use-custom-item-drops-for-mobs: True
rules.file-version: 5
rules.mob-groups.undead_mobs: ['ZOMBIE', 'HUSK', 'DROWNED']
rules.presets.challenge-bronze.name: Bronze Challenge
rules.presets.challenge-bronze.settings.attribute-modifier.attack-damage: 1.0
rules.presets.challenge-bronze.settings.attribute-modifier.item-drop: 3.0
rules.presets.challenge-bronze.settings.attribute-modifier.max-health: 2.5
rules.presets.challenge-bronze.settings.attribute-modifier.merge: False
rules.presets.challenge-bronze.settings.attribute-modifier.ranged-attack-damage: 0.7
rules.presets.challenge-bronze.settings.attribute-modifier.xp-drop: 5.0
rules.presets.challenge-formula.name: Custom Formula Challenge
rules.presets.challenge-formula.settings.attribute-modifier.armor-bonus: (%level-ratio% * (7.5 - %armor-bonus%))
rules.presets.challenge-formula.settings.attribute-modifier.armor-toughness: (%level-ratio% * (3.5 - %armor-toughness%))
rules.presets.challenge-formula.settings.attribute-modifier.attack-damage: (%level-ratio% * %attack-damage% * 2)
rules.presets.challenge-formula.settings.attribute-modifier.attack-knockback: (%level-ratio% * (2 - %attack-knockback%))
rules.presets.challenge-formula.settings.attribute-modifier.creeper-blast-damage: (%level-ratio% * %creeper-blast-damage% * 2.5)
rules.presets.challenge-formula.settings.attribute-modifier.follow-range: (%level-ratio% * %follow-range% * 0.5)
rules.presets.challenge-formula.settings.attribute-modifier.item-drop: (%level-ratio% * %item-drop% * 2)
rules.presets.challenge-formula.settings.attribute-modifier.knockback-resistance: (%level-ratio% * (0.25 - %knockback-resistance%))
rules.presets.challenge-formula.settings.attribute-modifier.max-health: (%level-ratio% * %max-health% * 5)
rules.presets.challenge-formula.settings.attribute-modifier.merge: False
rules.presets.challenge-formula.settings.attribute-modifier.movement-speed: (%level-ratio% * %movement-speed% * 0.25)
rules.presets.challenge-formula.settings.attribute-modifier.ranged-attack-damage: (%level-ratio% * %ranged-attack-damage% * 1.50)
rules.presets.challenge-formula.settings.attribute-modifier.xp-drop: (%level-ratio% * %xp-drop% * 5)
rules.presets.challenge-formula.settings.attribute-modifier.zombie-spawn-reinforcements: (%level-ratio% * (0.25 - %zombie-spawn-reinforcements%))
rules.presets.challenge-gold.name: Gold Challenge
rules.presets.challenge-gold.settings.attribute-modifier.armor-bonus: 0.3
rules.presets.challenge-gold.settings.attribute-modifier.armor-toughness: 0.3
rules.presets.challenge-gold.settings.attribute-modifier.attack-damage: 3.5
rules.presets.challenge-gold.settings.attribute-modifier.attack-knockback: 0.5
rules.presets.challenge-gold.settings.attribute-modifier.creeper-blast-damage: 1.75
rules.presets.challenge-gold.settings.attribute-modifier.follow-range: 0.25
rules.presets.challenge-gold.settings.attribute-modifier.item-drop: 3.0
rules.presets.challenge-gold.settings.attribute-modifier.knockback-resistance: 0.5
rules.presets.challenge-gold.settings.attribute-modifier.max-health: 8.0
rules.presets.challenge-gold.settings.attribute-modifier.merge: False
rules.presets.challenge-gold.settings.attribute-modifier.movement-speed: 0.35
rules.presets.challenge-gold.settings.attribute-modifier.ranged-attack-damage: 2.0
rules.presets.challenge-gold.settings.attribute-modifier.xp-drop: 5.0
rules.presets.challenge-platinum.name: Platinum Challenge
rules.presets.challenge-platinum.settings.attribute-modifier.armor-bonus: 0.5
rules.presets.challenge-platinum.settings.attribute-modifier.armor-toughness: 0.5
rules.presets.challenge-platinum.settings.attribute-modifier.attack-damage: 5.0
rules.presets.challenge-platinum.settings.attribute-modifier.attack-knockback: 0.5
rules.presets.challenge-platinum.settings.attribute-modifier.creeper-blast-damage: 2.5
rules.presets.challenge-platinum.settings.attribute-modifier.follow-range: 0.5
rules.presets.challenge-platinum.settings.attribute-modifier.item-drop: 3.0
rules.presets.challenge-platinum.settings.attribute-modifier.knockback-resistance: 0.5
rules.presets.challenge-platinum.settings.attribute-modifier.max-health: 15.0
rules.presets.challenge-platinum.settings.attribute-modifier.merge: False
rules.presets.challenge-platinum.settings.attribute-modifier.movement-speed: 1.0
rules.presets.challenge-platinum.settings.attribute-modifier.ranged-attack-damage: 3.2
rules.presets.challenge-platinum.settings.attribute-modifier.xp-drop: 5.0
rules.presets.challenge-platinum.settings.attribute-modifier.zombie-spawn-reinforcements: 0.15
rules.presets.challenge-silver.name: Silver Challenge
rules.presets.challenge-silver.settings.attribute-modifier.armor-bonus: 0.2
rules.presets.challenge-silver.settings.attribute-modifier.armor-toughness: 0.15
rules.presets.challenge-silver.settings.attribute-modifier.attack-damage: 2.25
rules.presets.challenge-silver.settings.attribute-modifier.creeper-blast-damage: 0.75
rules.presets.challenge-silver.settings.attribute-modifier.item-drop: 3.0
rules.presets.challenge-silver.settings.attribute-modifier.max-health: 5.0
rules.presets.challenge-silver.settings.attribute-modifier.merge: False
rules.presets.challenge-silver.settings.attribute-modifier.movement-speed: 0.15
rules.presets.challenge-silver.settings.attribute-modifier.ranged-attack-damage: 1.5
rules.presets.challenge-silver.settings.attribute-modifier.xp-drop: 5.0
rules.presets.challenge-vanilla.name: Vanilla Stat Challenge
rules.presets.challenge-vanilla.settings.attribute-modifier.attack-damage: 0.0
rules.presets.challenge-vanilla.settings.attribute-modifier.item-drop: 0.0
rules.presets.challenge-vanilla.settings.attribute-modifier.max-health: 0.0
rules.presets.challenge-vanilla.settings.attribute-modifier.merge: False
rules.presets.challenge-vanilla.settings.attribute-modifier.ranged-attack-damage: 0.0
rules.presets.challenge-vanilla.settings.attribute-modifier.xp-drop: 0.0
rules.presets.lvlmodifier-custom-formula.modifiers.custom.formula: 1 * %mob-lvl%
rules.presets.lvlmodifier-custom-formula.modifiers.custom_end.formula: %rand_-3_3% + %player-variable-mod%
rules.presets.lvlmodifier-custom-formula.modifiers.custom_nether.formula: %rand_-3_3% + %player-variable-mod%
rules.presets.lvlmodifier-custom-formula.modifiers.custom_special.formula: %attack-damage% * 0.2
rules.presets.lvlmodifier-custom-formula.name: LVL Modifier - Custom Formula
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.match-variable: False
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.output-cap: 25
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.player-variable: %level%
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.player-variable-scale: 1.0
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.player-variable-tiers.0-15: 1-3
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.player-variable-tiers.16-30: 2-5
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.player-variable-tiers.31-45: 3-7
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.player-variable-tiers.default: 1
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.preserve-entity: 5s
rules.presets.lvlmodifier-player-variable.modifiers.player-variable-mod.use-variable-as-max: False
rules.presets.lvlmodifier-player-variable.name: LVL Modifier - Player Variable
rules.presets.lvlstrategy-distance-from-origin.name: LVL Strategy - Distance-from-Origin
rules.presets.lvlstrategy-distance-from-origin.strategies.distance-from-origin.buffer-distance: 250
rules.presets.lvlstrategy-distance-from-origin.strategies.distance-from-origin.level-multiplier: 0.05
rules.presets.lvlstrategy-distance-from-origin.strategies.distance-from-origin.origin-coordinates.x: spawn
rules.presets.lvlstrategy-distance-from-origin.strategies.distance-from-origin.origin-coordinates.z: spawn
rules.presets.lvlstrategy-distance-from-origin.strategies.distance-from-origin.ringed-tiers: 750
rules.presets.lvlstrategy-distance-from-origin.strategies.distance-from-origin.transition-y-height: 62
rules.presets.lvlstrategy-distance-from-origin.strategies.distance-from-origin.y-height-period: 15
rules.presets.lvlstrategy-random.name: LVL Strategy - Random
rules.presets.lvlstrategy-weighted-random.name: LVL Strategy - Weighted Random
rules.presets.lvlstrategy-weighted-random.strategies.weighted-random.1-2: 100
rules.presets.lvlstrategy-weighted-random.strategies.weighted-random.11-50: 0
rules.presets.lvlstrategy-weighted-random.strategies.weighted-random.2-4: 50
rules.presets.lvlstrategy-weighted-random.strategies.weighted-random.3-6: 25
rules.presets.lvlstrategy-weighted-random.strategies.weighted-random.4-8: 10
rules.presets.lvlstrategy-weighted-random.strategies.weighted-random.5-10: 1
rules.presets.lvlstrategy-y-coordinate.name: LVL Strategy - Y-Coordinate
rules.presets.lvlstrategy-y-coordinate.strategies.y-coordinate.end-height: 20
rules.presets.lvlstrategy-y-coordinate.strategies.y-coordinate.period: 0
rules.presets.lvlstrategy-y-coordinate.strategies.y-coordinate.start-height: 100
rules.presets.nametag-disabled.name: Nametag - Disabled
rules.presets.nametag-disabled.settings.creature-death-nametag: &f%displayname% %tiered%%heart-symbol%
rules.presets.nametag-disabled.settings.nametag: disabled
rules.presets.nametag-disabled.settings.nametag-visibility-method: ['DISABLED']
rules.presets.nametag-minimized.name: Nametag - Minimized
rules.presets.nametag-minimized.settings.creature-death-nametag: &f%displayname% %tiered%%heart-symbol%
rules.presets.nametag-minimized.settings.nametag:  &f%displayname%&8 &8&l༻ %health-indicator-color%%entity-health-rounded%&fꓧꓑ 
rules.presets.nametag-using-indicator.name: Nametag - Health Displayed with Indicators
rules.presets.nametag-using-indicator.settings.creature-death-nametag: %tiered%Lvl %mob-lvl%&8 | &f%displayname%
rules.presets.nametag-using-indicator.settings.health-indicator.indicator: █
rules.presets.nametag-using-indicator.settings.health-indicator.indicator-half: ▌
rules.presets.nametag-using-indicator.settings.health-indicator.maintain-space: False
rules.presets.nametag-using-indicator.settings.health-indicator.merge: True
rules.presets.nametag-using-indicator.settings.nametag:  &fꓡꓦꓡ%tiered%%mob-lvl% &8&l༺ &r%displayname% &8&l༻ %health-indicator% 
rules.presets.nametag-using-numbers.name: Nametag - Health Displayed with Numbers
rules.presets.nametag-using-numbers.settings.creature-death-nametag: %tiered%Lvl %mob-lvl%&8 | &f%displayname%
rules.presets.nametag-using-numbers.settings.nametag:  &fꓡꓦꓡ%tiered%%mob-lvl% &8&l༺&r %displayname% &8&l༻ %health-indicator-color%%entity-health-rounded%&fꓧꓑ 
settings.assert-entity-validity-with-nametag-packets: True
settings.async-task-max-blocks-from-player: 320
settings.async-task-update-period: 3
settings.check-mob-hash: True
settings.customcommand-amount-limit: 100
settings.customize-summon-command-limit: 10
settings.debug-misc: []
settings.disable-nametag-bedrock: False
settings.disable-nametag-java: False
settings.ensure-mobs-are-levelled-on-chunk-load: True
settings.event-priorities.entity-damage-event: monitor
settings.event-priorities.entity-death-event: normal
settings.event-priorities.entity-spawn-event: monitor
settings.event-priorities.entity-transform-event: monitor
settings.event-priorities.player-death-event: normal
settings.exclude-players-in-creative: False
settings.file-version: 39
settings.ignore-mobs-with-no-player-context: False
settings.kill-skip-conditions.entitytype.included-groups: ['all_passive_mobs']
settings.kill-skip-conditions.entitytype.included-list: ['']
settings.kill-skip-conditions.is-leashed: True
settings.kill-skip-conditions.is-nametagged: True
settings.kill-skip-conditions.is-tamed: True
settings.kill-skip-conditions.is-transforming: True
settings.kill-skip-conditions.is-villager: True
settings.level-mobs-upon-spawn-max-players: 10
settings.lew-cache-clear-period: 3m
settings.mob-process-delay: 0
settings.mobs-multiply-head-drops: False
settings.nametag-placeholder-maxblocks: 30
settings.player-levelling-relevel-min-time: 5s
settings.print-lm-summon-results: True
settings.summon-command-spawn-max-distance-from-player: 5
settings.summon-command-spawn-min-distance-from-player: 3
settings.update-mobs-upon-nonplayer-damage-max-players: 5
settings.use-adventure: True
settings.use-legacy-serializer: True
settings.use-update-checker: True
```
