# ProtocolLib - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Global

`global.auto updater.delay` = 43200

`global.auto updater.download` = false

`global.auto updater.notify` = true

`global.background compiler` = true

`global.chat warnings` = true

`global.debug` = false

`global.detailed error` = false

`global.ignore version check` = null

`global.metrics` = true

`global.script engine` = "JavaScript"

`global.suppressed reports` = null

