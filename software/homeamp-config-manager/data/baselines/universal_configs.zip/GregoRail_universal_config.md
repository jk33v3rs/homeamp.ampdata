# GregoRail Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
config: {'butcher.disable-item-drops': True, 'butcher.enabled': True, 'butcher.ignore-entities-of-type': ['ALLAY', 'VILLAGER'], 'butcher.ignore-named-entities': True, 'butcher.lightning-bolt-effect': True, 'butcher.radius': 5, 'cart-prompt.item-material': 'MINECART', 'cart-prompt.player-search-radius': 5, 'cart-prompt.title': 'Select a code', 'general.block-search-radius': 10, 'general.cart-search-distance': 10, 'general.webhooks-enabled': False, 'webhooks.cart-moved.type': ['CART_MOVED'], 'webhooks.cart-moved.url': 'https://www.example.com/webhook/cart_moved', 'webhooks.player-entered-cart.type': ['CART_ENTERED'], 'webhooks.player-entered-cart.url': 'https://www.example.com/webhook/cart_entered'}
```
