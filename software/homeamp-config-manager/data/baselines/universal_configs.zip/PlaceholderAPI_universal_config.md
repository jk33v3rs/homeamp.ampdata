# PlaceholderAPI - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`check_updates` = true

`cloud_enabled` = true

`cloud_sorting` = "name"

`date_format` = "MM/dd/yy HH:mm:ss"

`debug` = false

## Boolean

`boolean.false` = "no"

`boolean.true` = "yes"

