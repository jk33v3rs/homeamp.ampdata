# ExcellentEnchants - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Arrow_Effects

`Arrow_Effects.Tick_Interval` = 1

## Charges

`Charges.Enabled` = false

`Charges.Format.high.Format` = "<lgreen>(%amount%⚡)</lgreen>"

`Charges.Format.high.Threshold` = 75

`Charges.Format.low.Format` = "<lorange>(%amount%⚡)</lorange>"

`Charges.Format.low.Threshold` = 25

`Charges.Format.medium.Format` = "<lyellow>(%amount%⚡)</lyellow>"

`Charges.Format.medium.Threshold` = 50

`Charges.Format.zero.Format` = "<lred>(%amount%⚡)</lred>"

`Charges.Format.zero.Threshold` = 0

`Charges.Fuel.Ignore_Meta` = false

`Charges.Fuel.Item.Lore` = []

`Charges.Fuel.Item.Material` = "minecraft:lapis_lazuli"

## Description

`Description.Books_Only` = false

`Description.Enabled` = true

`Description.Format.Default` = "<lgray>• %description%</lgray>"

`Description.Format.WithCharges` = "<lgray>• %description% (%charges%)</lgray>"

## Passive_Enchants

`Passive_Enchants.AllowForMobs` = true

`Passive_Enchants.Interval` = 1

