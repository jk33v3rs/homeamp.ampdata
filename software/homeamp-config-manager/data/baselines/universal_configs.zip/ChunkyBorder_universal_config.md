# ChunkyBorder - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`version` = 1

## Border-Options

`border-options.check-interval` = 20

`border-options.effect` = "ender_signal"

`border-options.message` = "&cYou have reached the edge of this world."

`border-options.prevent-chorus-fruit` = true

`border-options.prevent-enderpearl` = true

`border-options.prevent-mob-spawns` = true

`border-options.sound` = "entity_enderman_teleport"

`border-options.use-action-bar` = true

`border-options.visualizer-color` = "20A0FF"

`border-options.visualizer-enabled` = true

`border-options.visualizer-range` = 8

## Map-Options

`map-options.color` = "FF0000"

`map-options.enable.bluemap` = false

`map-options.enable.dynmap` = false

`map-options.enable.pl3xmap` = true

`map-options.enable.squaremap` = false

`map-options.hide-by-default` = false

`map-options.label` = "World Border"

`map-options.priority` = 0

`map-options.weight` = 3

