# BetterStructures - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`distanceDeep` = 22

`distanceDungeon` = 1000

`distanceLiquid` = 65

`distanceShallow` = 22

`distanceSky` = 95

`distanceSurface` = 31

`endAirBuildMaxAltitude` = 120

`endAirBuildMinAltitude` = 80

`highestYEnd` = 320

`highestYNether` = 120

`highestYNormalCustom` = 320

`lowestYEnd` = 0

`lowestYNether` = 4

`lowestYNormalCustom` = -60

`maxOffsetDeep` = 5

`maxOffsetDungeon` = 300

`maxOffsetLiquid` = 5

`maxOffsetShallow` = 5

`maxOffsetSky` = 5

`maxOffsetSurface` = 5

`modularChunkPastingSpeed` = 10

`normalCustomAirBuildingMaxAltitude` = 120

`normalCustomAirBuildingMinAltitude` = 80

`percentageOfTickUsedForPasting` = 0.2

`protectEliteMobsRegions` = true

`regionProtectedMessage` = "&8[BetterStructures] &cDefeat the zone's bosses to edit blocks!"

`setupDone` = true

`warnAdminsAboutNewBuildings` = true

