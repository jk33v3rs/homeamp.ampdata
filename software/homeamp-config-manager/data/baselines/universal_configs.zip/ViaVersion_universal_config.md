# ViaVersion - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`1_13-tab-complete-delay` = 0

`armor-toggle-fix` = true

`auto-team` = true

`block-disconnect-msg` = "You are using an unsupported Minecraft version!"

`block-protocols` = []

`block-versions` = []

`blockconnection-method` = "packet"

`bossbar-anti-flicker` = false

`bossbar-patch` = true

`cache-1_17-light` = true

`cancel-block-sounds` = true

`cancel-swing-in-inventory` = true

`change-1_14-hitbox` = false

`change-1_9-hitbox` = false

`check-for-updates` = true

`chunk-border-fix` = false

`disable-1_13-auto-complete` = false

`enforce-secure-chat` = false

`fix-1_14-health-nan` = true

`fix-1_21-placement-rotation` = true

`fix-infested-block-breaking` = true

`fix-low-snow-collision` = false

`fix-non-full-blocklight` = true

`flowerstem-when-block-above` = false

`forced-use-1_17-resource-pack` = false

`handle-invalid-item-count` = false

`hide-scoreboard-numbers` = false

`hologram-patch` = false

`hologram-y` = -0.96

`ignore-long-1_16-channel-names` = true

`item-cache` = true

`left-handed-handling` = true

`max-pps` = 800

`max-pps-kick-msg` = "You are sending too many packets!"

`nms-player-ticking` = true

`no-delay-shield-blocking` = false

`piston-animation-patch` = false

`prevent-collision` = true

`quick-move-action-fix` = false

`reduce-blockstorage-memory` = false

`register-userconnections-on-join` = true

`reload-disconnect-msg` = "Server reload, please rejoin!"

`replace-pistons` = false

`replacement-piston-id` = 0

`resource-pack-1_17-prompt` = ""

`send-supported-versions` = false

`serverside-blockconnections` = true

`shield-blocking` = true

`show-shield-when-sword-in-hand` = false

`simulate-pt` = true

`suppress-conversion-warnings` = false

`suppress-metadata-errors` = false

`suppress-text-component-conversion-warnings` = true

`team-colour-fix` = true

`tracking-max-kick-msg` = "You are sending too many packets, :("

`tracking-max-warnings` = 4

`tracking-period` = 6

`tracking-warning-pps` = 120

`translate-ocelot-to-cat` = false

`truncate-1_14-books` = false

`use-1_15-instant-respawn` = false

`use-new-deathmessages` = true

`use-new-effect-indicator` = true

`vine-climb-fix` = false

## Map-1_16-World-Names

`map-1_16-world-names.end` = "minecraft:the_end"

`map-1_16-world-names.nether` = "minecraft:the_nether"

`map-1_16-world-names.overworld` = "minecraft:overworld"

