# PAPIProxyBridge Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
settings.messenger: PLUGIN_MESSAGE
settings.redis.credentials.port: 6379
settings.redis.credentials.useSsl: False
settings.redis.sentinel.master: 
settings.redis.sentinel.nodes: []
settings.redis.sentinel.password: 
```
