# Lootin - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`black-list-customstructures` = []

`black-list-otd-structures` = []

`black-list-worlds` = []

`bypass-grief-plugins` = true

`debug-mode` = false

`default-worldguard-flag-value` = true

`delete-items-on-break` = true

`keep-in-memory` = 6000

`metrics` = true

`per-player-elytra-item-frame` = true

`prevent-explosions` = true

## Gui-Titles

`gui-titles.barrel` = "&6Barrel"

`gui-titles.chest` = "&6Chest"

`gui-titles.double-chest` = "&6Large Chest"

`gui-titles.minecart` = "&6Minecart with Chest"

## Messages

`messages.cant-place-double-chest` = "&cCan't place normal chest near loot containers."

`messages.cant-put-items-in-loot-container` = "&cCan't put items in loot containers!!"

`messages.chest-edited` = "&cAnother player is viewing this loot container. You can't open it!"

`messages.chestbreak-with-permission` = "&aBreaking the chest will delete your unique loot and items! In order to break, &2you must sneak while doing so..&a As loot is &2per player per chest&a, only break if really needed."

`messages.chestbreak-without-permission` = "&cYou don't have permission to break loot containers."

`messages.elytra-item-frame-removed` = "&aElytra ItemFrame removed."

`messages.elytra-itemframe-break-with-permission` = "&cLeft click with stick in main hand to break the special elytra item frame."

`messages.elytra-itemframe-break-without-permission` = "&cCan't break elytra item frame!"

`messages.look-at-container` = "&cLook at a container while executing command!"

`messages.no-permission` = "&cYou dont have permission to the execute command."

`messages.prefix` = "&e[&6Lootin&e] "

`messages.reloaded` = "&aConfig file reloaded."

## Prevent-Filling-Containers

`prevent-filling-containers.enabled` = true

`prevent-filling-containers.send-warning-message` = true

