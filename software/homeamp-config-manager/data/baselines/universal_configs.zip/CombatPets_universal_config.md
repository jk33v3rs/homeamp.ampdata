# CombatPets - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## Aspects

`Aspects.defense.Attached_Attributes` = ['armor']

`Aspects.defense.Icon.Material` = "PLAYER_HEAD"

`Aspects.defense.Icon.SkinURL` = "2328f378f28a9872226f5ce04d6e1dfa111618587f48dfa1fe82d043216a5cf"

`Aspects.defense.Name` = "Defense"

`Aspects.dexterity.Attached_Attributes` = ['flying_speed', 'attack_speed', 'movement_speed']

`Aspects.dexterity.Icon.Material` = "PLAYER_HEAD"

`Aspects.dexterity.Icon.SkinURL` = "a4efb34417d95faa94f25769a21676a022d263346c8553eb5525658b34269"

`Aspects.dexterity.Name` = "Dexterity"

`Aspects.strength.Attached_Attributes` = ['health_regeneration_force', 'attack_damage']

`Aspects.strength.Icon.Material` = "PLAYER_HEAD"

`Aspects.strength.Icon.SkinURL` = "41a2c088637fee9ae3a36dd496e876e657f509de55972dd17c18767eae1f3e9"

`Aspects.strength.Name` = "Strength"

`Aspects.vitality.Attached_Attributes` = ['health_regeneration_speed', 'max_health', 'max_saturation']

`Aspects.vitality.Icon.Material` = "PLAYER_HEAD"

`Aspects.vitality.Icon.SkinURL` = "1c3cec68769fe9c971291edb7ef96a4e3b60462cfd5fb5baa1cbb3a71513e7b"

`Aspects.vitality.Name` = "Vitality"

## Attributes

`Attributes.armor.Name` = "Armor"

`Attributes.attack_damage.Name` = "Attack Damage"

`Attributes.attack_knockback.Name` = "Attack Knockback"

`Attributes.attack_speed.Name` = "Attack Speed"

`Attributes.burning_time.Name` = "Burning Time"

`Attributes.explosion_knockback_resistance.Name` = "Explosion Knockback Resistance"

`Attributes.fall_damage_multiplier.Name` = "Fall Damage Multiplier"

`Attributes.flying_speed.Name` = "Flying Speed"

`Attributes.gravity.Name` = "Gravity"

`Attributes.health_regeneration_force.Name` = "Health Regeneration Force"

`Attributes.health_regeneration_speed.Name` = "Health Regeneration Speed"

`Attributes.horse_jump_strength.Name` = "Horse Jump Strength"

`Attributes.knockback_resistance.Name` = "Knockback Resistance"

`Attributes.max_health.Name` = "Max Health"

`Attributes.max_saturation.Name` = "Max Saturation"

`Attributes.movement_efficiency.Name` = "Movement Efficiency"

`Attributes.movement_speed.Name` = "Movement Speed"

`Attributes.safe_fall_distance.Name` = "Safe Fall Distance"

`Attributes.scale.Name` = "Scale"

`Attributes.step_height.Name` = "Step Height"

`Attributes.water_movement_efficiency.Name` = "Water Movement Efficiency"

## Features

`Features.Accessories` = true

`Features.Capture` = true

`Features.Leveling` = true

`Features.Shop` = true

## Food

`Food.apples.Items.apple.Item.Material` = "APPLE"

`Food.apples.Items.apple.Saturation` = 3.0

`Food.apples.Name` = "Apples"

`Food.bamboo.Items.bamboo.Item.Material` = "BAMBOO"

`Food.bamboo.Items.bamboo.Saturation` = 3.0

`Food.bamboo.Name` = "Bamboo"

`Food.beetroot.Items.beetroot.Item.Material` = "BEETROOT"

`Food.beetroot.Items.beetroot.Saturation` = 2.25

`Food.beetroot.Name` = "Beetroot"

`Food.bone_meal.Items.bone_meal.Item.Material` = "BONE_MEAL"

`Food.bone_meal.Items.bone_meal.Saturation` = 4.0

`Food.bone_meal.Name` = "Bone Meal"

`Food.bread.Items.bread.Item.Material` = "BREAD"

`Food.bread.Items.bread.Saturation` = 2.25

`Food.bread.Name` = "Bread"

`Food.carrots.Items.carrot.Item.Material` = "CARROT"

`Food.carrots.Items.carrot.Saturation` = 3.0

`Food.carrots.Name` = "Carrots"

`Food.chorus_fruits.Items.popped_chorus_fruit.Item.Material` = "POPPED_CHORUS_FRUIT"

`Food.chorus_fruits.Items.popped_chorus_fruit.Saturation` = 5.0

`Food.chorus_fruits.Name` = "Chorus Fruits"

`Food.cooked_fish.Items.cooked_cod.Item.Material` = "COOKED_COD"

`Food.cooked_fish.Items.cooked_cod.Saturation` = 3.0

`Food.cooked_fish.Items.cooked_salmon.Item.Material` = "COOKED_SALMON"

`Food.cooked_fish.Items.cooked_salmon.Saturation` = 3.0

`Food.cooked_fish.Name` = "Cooked Fish"

`Food.cooked_meat.Items.cooked_beef.Item.Material` = "COOKED_BEEF"

`Food.cooked_meat.Items.cooked_beef.Saturation` = 5.0

`Food.cooked_meat.Items.cooked_chicken.Item.Material` = "COOKED_CHICKEN"

`Food.cooked_meat.Items.cooked_chicken.Saturation` = 3.0

`Food.cooked_meat.Items.cooked_mutton.Item.Material` = "COOKED_MUTTON"

`Food.cooked_meat.Items.cooked_mutton.Saturation` = 3.0

`Food.cooked_meat.Items.cooked_porkchop.Item.Material` = "COOKED_PORKCHOP"

`Food.cooked_meat.Items.cooked_porkchop.Saturation` = 3.0

`Food.cooked_meat.Items.cooked_rabbit.Item.Material` = "COOKED_RABBIT"

`Food.cooked_meat.Items.cooked_rabbit.Saturation` = 4.0

`Food.cooked_meat.Name` = "Cooked Meat"

`Food.eggs.Items.egg.Item.Material` = "EGG"

`Food.eggs.Items.egg.Saturation` = 3.0

`Food.eggs.Name` = "Eggs"

`Food.flowers.Items.oxeye_daisy.Item.Material` = "OXEYE_DAISY"

`Food.flowers.Items.oxeye_daisy.Saturation` = 2.0

`Food.flowers.Name` = "Flowers"

`Food.gunpowder.Items.gunpowder.Item.Material` = "GUNPOWDER"

`Food.gunpowder.Items.gunpowder.Saturation` = 5.0

`Food.gunpowder.Name` = "Gunpowder"

`Food.mushrooms.Items.brown_mushroom.Item.Material` = "BROWN_MUSHROOM"

`Food.mushrooms.Items.brown_mushroom.Saturation` = 2.5

`Food.mushrooms.Items.red_mushroom.Item.Material` = "RED_MUSHROOM"

`Food.mushrooms.Items.red_mushroom.Saturation` = 2.5

`Food.mushrooms.Name` = "Mushrooms"

`Food.raw_fish.Items.cod.Item.Material` = "COD"

`Food.raw_fish.Items.cod.Saturation` = 2.0

`Food.raw_fish.Items.salmon.Item.Material` = "SALMON"

`Food.raw_fish.Items.salmon.Saturation` = 2.5

`Food.raw_fish.Items.tropical_fish.Item.Material` = "TROPICAL_FISH"

`Food.raw_fish.Items.tropical_fish.Saturation` = 2.5

`Food.raw_fish.Name` = "Raw Fish"

`Food.raw_meat.Items.beef.Item.Material` = "BEEF"

`Food.raw_meat.Items.beef.Saturation` = 3.5

`Food.raw_meat.Items.chicken.Item.Material` = "CHICKEN"

`Food.raw_meat.Items.chicken.Saturation` = 2.5

`Food.raw_meat.Items.mutton.Item.Material` = "MUTTON"

`Food.raw_meat.Items.mutton.Saturation` = 3.5

`Food.raw_meat.Items.porkchop.Item.Material` = "PORKCHOP"

`Food.raw_meat.Items.porkchop.Saturation` = 3.5

`Food.raw_meat.Items.rabbit.Item.Material` = "RABBIT"

`Food.raw_meat.Items.rabbit.Saturation` = 3.0

`Food.raw_meat.Name` = "Raw Meat"

`Food.rotten_flesh.Items.rotten_flesh.Item.Material` = "ROTTEN_FLESH"

`Food.rotten_flesh.Items.rotten_flesh.Saturation` = 5.0

`Food.rotten_flesh.Name` = "Rotten Flesh"

`Food.spider_eyes.Items.spider_eye.Item.Material` = "SPIDER_EYE"

`Food.spider_eyes.Items.spider_eye.Saturation` = 3.0

`Food.spider_eyes.Name` = "Spider Eyes"

`Food.sticks.Items.stick.Item.Material` = "STICK"

`Food.sticks.Items.stick.Saturation` = 2.0

`Food.sticks.Name` = "Sticks"

`Food.wheat.Items.wheat.Item.Material` = "WHEAT"

`Food.wheat.Items.wheat.Saturation` = 3.0

`Food.wheat.Name` = "Wheat"

`Food.wheat_seeds.Items.wheat_seeds.Item.Material` = "WHEAT_SEEDS"

`Food.wheat_seeds.Items.wheat_seeds.Saturation` = 2.0

`Food.wheat_seeds.Name` = "Wheat Seeds"

`Food.wither_roses.Items.wither_rose.Item.Material` = "WITHER_ROSE"

`Food.wither_roses.Items.wither_rose.Saturation` = 3.0

`Food.wither_roses.Name` = "Wither Roses"

## Items

`Items.Mystery_Egg.Lore` = ['<dgray>Hatches into egg with random tier.</dgray>', '', '<lgray><lpurple>[▶]</lpurple> Right-Click to <lpurple>hatch</lpurple>.</lgray>']

`Items.Mystery_Egg.Material` = "PLAYER_HEAD"

`Items.Mystery_Egg.Name` = "<lpurple><b>Mystery Pet Egg</b></lpurple> <gray>(<white>%pet_config_default_name%</white>)</gray>"

`Items.Mystery_Egg.SkinURL` = "e6ba9987f738e6d75d3b02c30d1480a360593ddb464bd1c81abb9d71d9e656c0"

## Pets

`Pets.Allow_Reallocate_Aspect_Points` = false

`Pets.Amount_Per_Rank.Default_Value` = -1

`Pets.Amount_Per_Rank.Mode` = "RANK"

`Pets.Amount_Per_Rank.Permission_Prefix` = "pets.amount."

`Pets.Amount_Per_Rank.Values.admin` = -1

`Pets.Amount_Per_Rank.Values.default` = 10

`Pets.Amount_Per_Rank.Values.vip` = 20

`Pets.Attack_Damage_For_Projectiles` = true

`Pets.AutoFoodUsage.At_Saturation` = 75.0

`Pets.Damage_Regen_Cooldown` = 5.0

`Pets.Disabled_Worlds` = ['custom_world']

`Pets.Drop_Equipment` = true

`Pets.Drop_Inventory` = true

`Pets.Egg_Item.Lore` = ['<dgray>Tier: <gray>%pet_tier_name%</gray></dgray>', '', '<lgray><lyellow>[▶]</lyellow> Right-Click to <lyellow>claim</lyellow>.</lgray>']

`Pets.Egg_Item.Material` = "PLAYER_HEAD"

`Pets.Egg_Item.Name` = "<lyellow><b>Pet Egg</b></lyellow> <gray>(<white>%pet_config_default_name%</white>)</gray>"

`Pets.Healthbar.Color` = "GREEN"

`Pets.Healthbar.Enabled` = true

`Pets.Healthbar.Style` = "SOLID"

`Pets.Healthbar.Title` = "<lyellow>%pet_name%</lyellow>   <gray>Lv. </gray><white>%pet_level%</white>   <lred>%pet_health%</lred><gray>/</gray><lred>%pet_max_health% ❤</lred>"

`Pets.Name.ForbiddenWords` = ['ass', 'dick', 'bitch', 'penis', 'asshole']

`Pets.Name.Max_Length` = 16

`Pets.Name.Min_Length` = 3

`Pets.Name.Rename.Allow_NameTags` = true

`Pets.Name.Rename.Menu_Requires_NameTag` = true

`Pets.Original_Damage_From_Projectiles` = 0.25

`Pets.PVP_Allowed` = true

`Pets.Permanent_Deaths` = false

`Pets.Populate_Default_Equipment` = true

`Pets.Release.Allowed` = true

`Pets.Release.BadWorlds` = ['spawn', 'other_world']

`Pets.Release.Natural` = true

`Pets.Saturation_Percent_To_Regen` = 70

