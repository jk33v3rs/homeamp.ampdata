# WorldEdit - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`command-block-support` = false

`debug` = false

`no-op-permissions` = false

`server-side-cui` = true

`shell-save-type` = null

`show-help-on-first-use` = true

`wand-item` = "minecraft:wooden_axe"

## Calculation

`calculation.timeout` = 100

## Debugging

`debugging.trace-unflushed-sessions` = false

## Files

`files.allow-symbolic-links` = false

## History

`history.expiration` = 10

`history.size` = 15

## Limits

`limits.butcher-radius.default` = -1

`limits.butcher-radius.maximum` = -1

`limits.disallowed-blocks` = []

`limits.max-blocks-changed.default` = -1

`limits.max-blocks-changed.maximum` = -1

`limits.max-brush-radius` = 5

`limits.max-polygonal-points.default` = -1

`limits.max-polygonal-points.maximum` = 20

`limits.max-radius` = -1

`limits.max-super-pickaxe-size` = 5

`limits.vertical-height.default` = 256

## Logging

`logging.file` = "worldedit.log"

`logging.format` = "[%1$tY-%1$tm-%1$td %1$tH:%1$tM:%1$tS %4$s]: %5$s%6$s%n"

`logging.log-commands` = false

## Navigation-Wand

`navigation-wand.item` = "minecraft:compass"

`navigation-wand.max-distance` = 100

## Saving

`saving.dir` = "schematics"

## Scripting

`scripting.dir` = "craftscripts"

`scripting.timeout` = 3000

## Snapshots

`snapshots.directory` = null

## Super-Pickaxe

`super-pickaxe.drop-items` = true

`super-pickaxe.many-drop-items` = false

## Use-Inventory

`use-inventory.allow-override` = true

`use-inventory.creative-mode-overrides` = false

`use-inventory.enable` = false

