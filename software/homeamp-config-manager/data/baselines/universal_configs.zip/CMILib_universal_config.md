# CMILib - Universal Configuration

These settings are **identical across all 17 Paper 1.21.8 servers** that use this plugin.

## Colors

`Colors.OfficialHex` = true

`Colors.QuirkyHex` = true

## Exploitpatcher

`ExploitPatcher.Placeholders.blocked.checkItem` = true

## General

`AutoUpdate` = false

`Language` = "EN"

`LanguageDownload` = true

## Globalgui

`GlobalGui.Close` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvYzM4YWIxNDU3NDdiNGJkMDljZTAzNTQzNTQ5NDhjZTY5ZmY2ZjQxZDllMDk4YzY4NDhiODBlMTg3ZTkxOSJ9fX0="

`GlobalGui.EmptyField` = "BLACK_STAINED_GLASS_PANE"

`GlobalGui.Info` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMjcwNWZkOTRhMGM0MzE5MjdmYjRlNjM5YjBmY2ZiNDk3MTdlNDEyMjg1YTAyYjQzOWUwMTEyZGEyMmIyZTJlYyJ9fX0="

`GlobalGui.Pages.Middle` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvZmEyYWZhN2JiMDYzYWMxZmYzYmJlMDhkMmM1NThhN2RmMmUyYmFjZGYxNWRhYzJhNjQ2NjJkYzQwZjhmZGJhZCJ9fX0="

`GlobalGui.Pages.Next` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvNjgyYWQxYjljYjRkZDIxMjU5YzBkNzVhYTMxNWZmMzg5YzNjZWY3NTJiZTM5NDkzMzgxNjRiYWM4NGE5NmUifX19"

`GlobalGui.Pages.Previous` = "head:eyJ0ZXh0dXJlcyI6eyJTS0lOIjp7InVybCI6Imh0dHA6Ly90ZXh0dXJlcy5taW5lY3JhZnQubmV0L3RleHR1cmUvMzdhZWU5YTc1YmYwZGY3ODk3MTgzMDE1Y2NhMGIyYTdkNzU1YzYzMzg4ZmYwMTc1MmQ1ZjQ0MTlmYzY0NSJ9fX0="

## Images

`Images.EmptyFiller` = "&7_|"

`Images.Filler` = "⬛"

## Rmccommands

`RMCCommands.ConsoleLog` = true

## Skins

`Skins.SkinRequestFrequency` = 10

`Skins.SkinUpdateTimer` = 1320

## Spawners

`Spawners.mysterySpawners` = ['skeleton', 'zombie', 'silverfish', 'panda', 'fox']

