# BoxedEyes Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
config: {'EyeLocation.X-Offset': 100.0, 'EyeLocation.Y-Location': 30.0, 'EyeLocation.Z-Offset': 100.0}
```
