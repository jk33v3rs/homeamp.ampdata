# QuickShop-Hikari - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`auto-report-errors` = true

`blacklist` = ['Bedrock']

`bungee-cross-server-msg` = true

`config-damaged` = false

`config-version` = 1033

`currency` = "money"

`custom-commands` = ['qs', 'shop', 'chestshop', 'cshop']

`custom-item-stacksize` = []

`custom-translation-key` = []

`database-loading-blacklist-worlds` = ["the world that shop won't to be loaded"]

`decimal-format` = "#,###.##"

`dev-mode` = false

`donation-key` = ""

`economy-type` = 0

`enabled-languages` = ['*']

`force-bukkit-chat-handler` = true

`game-language` = "default"

`include-offlineplayer-list` = true

`mojangapi-mirror` = 0

`respect-item-flag` = true

`send-display-item-protection-alert` = true

`send-shop-protection-alert` = true

`shop-blocks` = ['CHEST', 'TRAPPED_CHEST', 'BARREL']

`show-tax` = true

`tax` = 0.0

`tax-free-for-unlimited-shop` = true

`unlimited-shop-owner-change` = false

`updater` = true

`use-decimal-format` = true

## Backup-Policy

`backup-policy.database-upgrade` = true

`backup-policy.recovery` = true

`backup-policy.shops-auto-purge` = false

`backup-policy.startup` = true

## Custom-Subcommands

`custom-subcommands.help` = "help"

## Database

`database.database` = "asmp_SQL"

`database.host` = "135.181.212.169"

`database.mysql` = true

`database.password` = "SQLdb2024!"

`database.port` = 3369

`database.properties.allowPublicKeyRetrieval` = true

`database.properties.cachePrepStmts` = true

`database.properties.characterEncoding` = "utf8"

`database.properties.connectionTimeout` = 60000

`database.properties.idleTimeout` = 10000

`database.properties.keepaliveTime` = 60000

`database.properties.maxLifetime` = 1800000

`database.properties.maximumPoolSize` = 10

`database.properties.minimumIdle` = 10

`database.properties.prepStmtCacheSize` = 250

`database.properties.prepStmtCacheSqlLimit` = 2048

`database.properties.useUnicode` = true

`database.user` = "sqlworkerSMP"

`database.usessl` = false

## Debug

`debug.delete-corrupt-shops` = true

`debug.disable-debuglogger` = false

`debug.shop-deletion` = true

## Effect

`effect.sound.onclick` = true

`effect.sound.oncommand` = true

`effect.sound.ontabcomplete` = true

## Legacy-Updater

`legacy-updater.shop-sign` = true

## Limits

`limits.default` = 10

`limits.old-algorithm` = false

`limits.ranks.quickshop.example` = 20

`limits.use` = false

## Logging

`logging.enable` = true

`logging.file-size` = 10.0

`logging.location` = 1

`logging.log-actions` = true

`logging.log-balance` = true

## Matcher

`matcher.item.attributes` = true

`matcher.item.banner` = true

`matcher.item.books` = true

`matcher.item.bundle` = true

`matcher.item.custommodeldata` = true

`matcher.item.damage` = true

`matcher.item.displayname` = true

`matcher.item.enchs` = true

`matcher.item.firework` = true

`matcher.item.fishBucket` = true

`matcher.item.itemflags` = true

`matcher.item.leatherArmor` = true

`matcher.item.lores` = true

`matcher.item.map` = true

`matcher.item.potions` = true

`matcher.item.repaircost` = false

`matcher.item.shulkerBox` = true

`matcher.item.skull` = true

`matcher.item.suspiciousStew` = true

`matcher.work-type` = 1

## Plugin

`plugin.Multiverse-Core` = false

`plugin.PlaceHolderAPI.cache` = 900000

`plugin.PlaceHolderAPI.enable` = true

`plugin.WorldEdit` = true

## Privacy

`privacy.type.DIAGNOSTIC` = true

`privacy.type.RESEARCH` = true

`privacy.type.STATISTIC` = true

## Protect

`protect.entity` = true

`protect.explode` = true

`protect.hopper` = true

`protect.hopper-owner-exclude` = false

## Purge

`purge.at-server-startup` = false

`purge.banned` = false

`purge.days` = 60

`purge.enabled` = false

`purge.skip-op` = true

## Shop

`shop.allow-economy-loan` = false

`shop.allow-owner-break-shop-sign` = true

`shop.allow-shop-without-space-for-sign` = true

`shop.allow-stacks` = true

`shop.alternate-currency-symbol` = "$$"

`shop.alternate-currency-symbol-list` = ['$MPcoin;$$']

`shop.auto-fetch-shop-messages` = true

`shop.auto-sign` = true

`shop.blacklist-lores` = ['SoulBound']

`shop.blacklist-world` = ['disabled_world_name']

`shop.cancel-protection-fake-event-before-reach-monitor-listeners` = true

`shop.control-panel` = ['owner', 'unlimited', 'freeze', 'shop_mode', 'set_price', 'set_amount', 'refill', 'empty', 'display', 'history', 'remove']

`shop.cost` = 500

`shop.currency-symbol-on-right` = false

`shop.disable-creative-mode-trading` = false

`shop.disable-max-size-check-for-size-command` = false

`shop.disable-quick-create` = false

`shop.disable-super-tool` = false

`shop.disable-vault-format` = false

`shop.display-allow-stacks` = true

`shop.display-auto-despawn` = true

`shop.display-check-time` = 100

`shop.display-coords.x` = 0.5

`shop.display-coords.y` = 0.8

`shop.display-coords.z` = 0.5

`shop.display-despawn-range` = 16

`shop.display-item-use-name` = true

`shop.display-items` = true

`shop.display-items-check-ticks` = 6000

`shop.display-protocol` = "protocollib"

`shop.display-type` = 2

`shop.finding.all` = true

`shop.finding.distance` = 1000

`shop.finding.exclude-out-of-stock` = false

`shop.finding.global` = true

`shop.finding.limit` = 10

`shop.finding.oldLogic` = false

`shop.force-load-downgrade-items.enable` = false

`shop.force-load-downgrade-items.method` = 0

`shop.force-use-item-original-name` = false

`shop.ignore-cancel-chat-event` = true

`shop.ignore-unlimited-shop-messages` = true

`shop.info-panel.show-durability` = true

`shop.info-panel.show-effects` = true

`shop.info-panel.show-enchantments` = true

`shop.lock` = true

`shop.max-shops-checks-in-once` = 100

`shop.maximum-digits-in-price` = -1

`shop.name-fee` = 250

`shop.name-max-length` = 32

`shop.ongoing-fee.cost-per-shop` = 2

`shop.ongoing-fee.enable` = false

`shop.ongoing-fee.ignore-unlimited` = true

`shop.ongoing-fee.ticks` = 42000

`shop.pay-unlimited-shop-owners` = true

`shop.per-player-shop-sign` = true

`shop.price-change-requires-fee` = true

`shop.protection-checking` = true

`shop.protection-checking-blacklist` = ['disabled_world']

`shop.protection-checking-listener-blacklist` = ['ignored_listener']

`shop.refund` = false

`shop.refund-from-tax-account` = false

`shop.remove-protection-trigger` = true

`shop.sending-stock-message-to-staffs` = true

`shop.show-owner-uuid-in-controlpanel-if-op` = true

`shop.sign-dye-color` = "magenta"

`shop.sign-glowing` = true

`shop.sign-material` = "ACACIA_WALL_SIGN"

`shop.sign-wax` = true

`shop.update-sign-when-inventory-moving` = false

`shop.use-cache` = true

`shop.use-effect-for-potion-item` = true

`shop.use-enchantment-for-enchanted-book` = true

`shop.word-for-trade-all-items` = "alltrade"

## Transaction-Metric

`transaction-metric.enable` = true

