# vcustombrand Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
config: {'custom-brand': '"<rainbow>MyServer <green><player_name>"', 'time-unit': 'SECONDS', 'value': '2'}
```
