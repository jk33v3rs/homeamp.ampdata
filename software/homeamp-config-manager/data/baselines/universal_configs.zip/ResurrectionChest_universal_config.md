# ResurrectionChest - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`Amount of durability to lower on death` = 100

`Chest creation message` = "&8[ResurrectionChest] &aYou've created your Death Chest!"

`Chest destruction message` = "&8[ResurrectionChest] &cYour Death Chest has been destroyed!"

`Chest missing message` = "&8[ResurrectionChest] &4Your Death Chest is missing!"

`Death message` = "&8[ResurrectionChest] &aYour items have been moved to your Death Chest!"

`Enable high compatibility / low security mode for plugin conflicts` = false

`Enable particle effects for death chests` = true

`Input name for death chest` = "[DeathChest]"

`Lower worn armor's durability on death` = true

`Particle effect 1` = "ENCHANTMENT_TABLE"

`Particle effect 2` = "ENCHANTMENT_TABLE"

`Particle effect 3` = "PORTAL"

`blacklistedWorlds` = ['none']

`deathChestNameTag` = "$playerName's &fResurrection Chest"

`deathChestRemovedMessage` = "&8[ResurrectionChest] &cYour Death Chest has been removed!"

`freeDoubleDeathChestModelName` = "resurrectionchest_free_double"

`freeSingleDeathChestModelName` = "resurrectionchest_free_single"

`premiumDoubleDeathChestModelName` = "resurrectionchest_angelic_double"

`premiumSingleDeathChestModelName` = "resurrectionchest_angelic_single"

`storeXP` = true

`xpPercentageKept` = 0.75

