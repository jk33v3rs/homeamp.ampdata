# DamageIndicator - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`BurnIndicatorFormat` = "&7-0.#'&#f59e42'❤"

`CriticalIndicatorFormat` = "&c-0.#&4❤"

`FormatLocale` = "en-US"

`IndicatorFormat` = "&7-0.#&4❤"

`IndicatorTime` = 1.5

`InstantDamageIndicatorFormat` = "&7-0.#'&#610000'❤"

`PoisonIndicatorFormat` = "&7-0.#'&#5e8a24'❤"

`ShowToDamagerOnly` = true

