# AxiomPaper - Universal Configuration

These settings are **identical across all 17 Paper 1.21.8 servers** that use this plugin.

## General

`allow-annotations` = false

`allow-capabilities` = ['all']

`allow-large-chunk-data-request` = false

`allow-large-payload-for-all-packets` = false

`allow-teleport-between-worlds` = true

`blacklist-entities` = null

`blacklist-world-regex` = null

`block-buffer-rate-limit` = 0

`blueprint-sharing` = false

`disable-entity-sanitization` = false

`disallowed-blocks` = null

`incompatible-data-version` = "warn"

`infinite-reach-limit` = 256

`log-core-protect-changes` = true

`log-large-block-buffer-changes` = false

`max-block-buffer-packet-size` = 1048576

`max-chunk-load-distance` = 128

`max-chunk-relights-per-tick` = 0

`max-chunk-sends-per-tick` = 0

`send-markers` = false

`unsupported-axiom-version` = "warn"

`whitelist-entities` = null

`whitelist-world-regex` = null

## Packet-Handlers

`packet-handlers.annotation-update` = true

`packet-handlers.delete-entity` = true

`packet-handlers.hello` = true

`packet-handlers.manipulate-entity` = true

`packet-handlers.marker-nbt-request` = true

`packet-handlers.request-chunk-data` = true

`packet-handlers.request-entity-data` = true

`packet-handlers.set-buffer` = true

`packet-handlers.set-editor-views` = true

`packet-handlers.set-fly-speed` = true

`packet-handlers.set-gamemode` = true

`packet-handlers.set-hotbar-slot` = true

`packet-handlers.set-single-block` = true

`packet-handlers.set-world-property` = true

`packet-handlers.set-world-time` = true

`packet-handlers.spawn-entity` = true

`packet-handlers.switch-active-hotbar` = true

`packet-handlers.teleport` = true

`packet-handlers.upload-blueprint` = true

