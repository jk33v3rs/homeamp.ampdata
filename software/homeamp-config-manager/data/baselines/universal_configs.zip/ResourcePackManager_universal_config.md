# ResourcePackManager - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`autoHost` = true

`forceResourcePack` = true

`priorityOrder` = ['tool-trims-RP-v2.3.3a.zip', 'ResourcePackManager', 'EliteMobs', 'FreeMinecraftModels', 'ModelEngine', 'Nova', 'ItemsAdder', 'Oraxen', 'BetterHUD', 'ValhallaMMO', 'MMOInventory', 'vane-core', 'RealisticSurvival']

`resourcePackPrompt` = "Use recommended resource pack?"

`resourcePackRerouting` = ""

