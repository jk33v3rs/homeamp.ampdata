# autoviaupdater Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
versions: {'ViaBackwards': 650, 'ViaBackwards-Dev': -1, 'ViaBackwards-Java8': -1, 'ViaRewind': 176, 'ViaRewind-Dev': -1, 'ViaRewind-Java8': -1, 'ViaVersion': 1252, 'ViaVersion-Dev': -1, 'ViaVersion-Java8': -1}
```
