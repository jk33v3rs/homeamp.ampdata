# qsaddon-displaycontrol - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`config-version` = 1

