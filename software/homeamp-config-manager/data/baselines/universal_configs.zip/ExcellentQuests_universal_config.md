# ExcellentQuests Universal Configuration

Generated from universal_configs_analysis.json

## Configuration Settings

```yaml
battlepass.Leveling.Progression.InitialXP: 250
battlepass.Leveling.Progression.Max_Level: 105
battlepass.Leveling.Progression.XP_Factor: 1.00669
battlepass.Levels.10.Default_Rewards: 
battlepass.Levels.10.Premium_Rewards: bp_gold_ingots
battlepass.Levels.100.Default_Rewards: 
battlepass.Levels.100.Premium_Rewards: bp_gold_ingots
battlepass.Levels.102.Default_Rewards: bp_cash_low
battlepass.Levels.102.Premium_Rewards: 
battlepass.Levels.105.Default_Rewards: 
battlepass.Levels.105.Premium_Rewards: bp_diamonds
battlepass.Levels.12.Default_Rewards: bp_cash_low
battlepass.Levels.12.Premium_Rewards: 
battlepass.Levels.15.Default_Rewards: 
battlepass.Levels.15.Premium_Rewards: bp_diamonds
battlepass.Levels.18.Default_Rewards: bp_cash_low
battlepass.Levels.18.Premium_Rewards: 
battlepass.Levels.20.Default_Rewards: 
battlepass.Levels.20.Premium_Rewards: bp_gold_ingots
battlepass.Levels.21.Default_Rewards: bp_cash_low
battlepass.Levels.21.Premium_Rewards: 
battlepass.Levels.24.Default_Rewards: bp_cash_low
battlepass.Levels.24.Premium_Rewards: 
battlepass.Levels.25.Default_Rewards: 
battlepass.Levels.25.Premium_Rewards: bp_cash_medium
battlepass.Levels.27.Default_Rewards: bp_cash_low
battlepass.Levels.27.Premium_Rewards: 
battlepass.Levels.3.Default_Rewards: bp_cash_low
battlepass.Levels.3.Premium_Rewards: 
battlepass.Levels.30.Default_Rewards: 
battlepass.Levels.30.Premium_Rewards: bp_diamonds
battlepass.Levels.33.Default_Rewards: bp_cash_low
battlepass.Levels.33.Premium_Rewards: 
battlepass.Levels.35.Default_Rewards: 
battlepass.Levels.35.Premium_Rewards: bp_cash_medium
battlepass.Levels.36.Default_Rewards: bp_cash_low
battlepass.Levels.36.Premium_Rewards: 
battlepass.Levels.39.Default_Rewards: bp_cash_low
battlepass.Levels.39.Premium_Rewards: 
battlepass.Levels.40.Default_Rewards: 
battlepass.Levels.40.Premium_Rewards: bp_gold_ingots
battlepass.Levels.42.Default_Rewards: bp_cash_low
battlepass.Levels.42.Premium_Rewards: 
battlepass.Levels.45.Default_Rewards: 
battlepass.Levels.45.Premium_Rewards: bp_diamonds
battlepass.Levels.48.Default_Rewards: bp_cash_low
battlepass.Levels.48.Premium_Rewards: 
battlepass.Levels.5.Default_Rewards: 
battlepass.Levels.5.Premium_Rewards: bp_cash_medium
battlepass.Levels.50.Default_Rewards: 
battlepass.Levels.50.Premium_Rewards: bp_gold_ingots
battlepass.Levels.51.Default_Rewards: bp_cash_low
battlepass.Levels.51.Premium_Rewards: 
battlepass.Levels.54.Default_Rewards: bp_cash_low
battlepass.Levels.54.Premium_Rewards: 
battlepass.Levels.55.Default_Rewards: 
battlepass.Levels.55.Premium_Rewards: bp_cash_medium
battlepass.Levels.57.Default_Rewards: bp_cash_low
battlepass.Levels.57.Premium_Rewards: 
battlepass.Levels.6.Default_Rewards: bp_cash_low
battlepass.Levels.6.Premium_Rewards: 
battlepass.Levels.60.Default_Rewards: 
battlepass.Levels.60.Premium_Rewards: bp_diamonds
battlepass.Levels.63.Default_Rewards: bp_cash_low
battlepass.Levels.63.Premium_Rewards: 
battlepass.Levels.65.Default_Rewards: 
battlepass.Levels.65.Premium_Rewards: bp_cash_medium
battlepass.Levels.66.Default_Rewards: bp_cash_low
battlepass.Levels.66.Premium_Rewards: 
battlepass.Levels.69.Default_Rewards: bp_cash_low
battlepass.Levels.69.Premium_Rewards: 
battlepass.Levels.70.Default_Rewards: 
battlepass.Levels.70.Premium_Rewards: bp_gold_ingots
battlepass.Levels.72.Default_Rewards: bp_cash_low
battlepass.Levels.72.Premium_Rewards: 
battlepass.Levels.75.Default_Rewards: 
battlepass.Levels.75.Premium_Rewards: bp_diamonds
battlepass.Levels.78.Default_Rewards: bp_cash_low
battlepass.Levels.78.Premium_Rewards: 
battlepass.Levels.80.Default_Rewards: 
battlepass.Levels.80.Premium_Rewards: bp_gold_ingots
battlepass.Levels.81.Default_Rewards: bp_cash_low
battlepass.Levels.81.Premium_Rewards: 
battlepass.Levels.84.Default_Rewards: bp_cash_low
battlepass.Levels.84.Premium_Rewards: 
battlepass.Levels.85.Default_Rewards: 
battlepass.Levels.85.Premium_Rewards: bp_cash_medium
battlepass.Levels.87.Default_Rewards: bp_cash_low
battlepass.Levels.87.Premium_Rewards: 
battlepass.Levels.9.Default_Rewards: bp_cash_low
battlepass.Levels.9.Premium_Rewards: 
battlepass.Levels.90.Default_Rewards: 
battlepass.Levels.90.Premium_Rewards: bp_diamonds
battlepass.Levels.93.Default_Rewards: bp_cash_low
battlepass.Levels.93.Premium_Rewards: 
battlepass.Levels.95.Default_Rewards: 
battlepass.Levels.95.Premium_Rewards: bp_cash_medium
battlepass.Levels.96.Default_Rewards: bp_cash_low
battlepass.Levels.96.Premium_Rewards: 
battlepass.Levels.99.Default_Rewards: bp_cash_low
battlepass.Levels.99.Premium_Rewards: 
battlepass.Settings.GivePremiumByPermission: True
config.AntiAbuse.ArtificalMobSpawns: ['BUILD_SNOWMAN', 'EGG', 'BUILD_IRONGOLEM', 'TRIAL_SPAWNER', 'DISPENSE_EGG', 'SPAWNER', 'SPAWNER_EGG']
config.AntiAbuse.CountArtificallySpawnedMobs: False
config.AntiAbuse.CountAutoCooking: True
config.AntiAbuse.CountInVehicles: True
config.AntiAbuse.CountPlayerBlocks: False
config.Features.BattlePass.Aliases: battlepass,bp
config.Features.BattlePass.Enabled: True
config.Features.Milestones.Aliases: milestones
config.Features.Milestones.Enabled: True
config.Features.Quests.Aliases: quests
config.Features.Quests.Enabled: True
config.General.DateTimeFormat: dd/MM/yyyy HH:mm
config.Integrations.Disabled: ['PluginName', 'AnotherPlugin']
config.Milestones.Categories.farming.Description: ['<gray>Ever played Farmville?</gray>', '<gray>Complete milestones by farming crops.</gray>']
config.Milestones.Categories.farming.Icon.Lore: []
config.Milestones.Categories.farming.Icon.Material: minecraft:iron_hoe
config.Milestones.Categories.farming.Name: Farming
config.Milestones.Categories.fishing.Description: ['<gray>It takes some patience, we know...</gray>', '<gray>Complete milestones by fishing different fish.</gray>']
config.Milestones.Categories.fishing.Icon.Lore: []
config.Milestones.Categories.fishing.Icon.Material: minecraft:fishing_rod
config.Milestones.Categories.fishing.Name: Fishing
config.Milestones.Categories.mining.Description: ['<gray>%player_name%, Destroyer of Worlds.</gray>', '<gray>Complete milestones by breaking specific blocks.</gray>']
config.Milestones.Categories.mining.Icon.Lore: []
config.Milestones.Categories.mining.Icon.Material: minecraft:iron_pickaxe
config.Milestones.Categories.mining.Name: Mining
config.Milestones.ResetProgress: False
config.Quests.AmountPerRank.Default_Value: 3.0
config.Quests.AmountPerRank.Mode: RANK
config.Quests.AmountPerRank.Permission_Prefix: example.prefix.
config.Quests.AmountPerRank.Values.premium: 5.0
config.Quests.AmountPerRank.Values.vip: 4.0
config.Quests.BattlePassMode: False
config.UI.ProgressBar.Char: ■
config.UI.ProgressBar.EmptyColor: #464646
config.UI.ProgressBar.FillColor: #32E632
config.UI.ProgressBar.Length: 15
engine.Database.Max_Lifetime: 1800000
engine.Database.MySQL.Database: minecraft
engine.Database.MySQL.Host: localhost:3306
engine.Database.MySQL.Options: ?allowPublicKeyRetrieval=true&useSSL=false
engine.Database.MySQL.Password: 
engine.Database.MySQL.Username: root
engine.Database.Purge.Enabled: False
engine.Database.Purge.For_Period: 60
engine.Database.SQLite.FileName: data.db
engine.Database.Sync_Interval: -1
engine.Database.Table_Prefix: excellentquests
engine.Database.Type: SQLITE
engine.Plugin.Command_Aliases: equests,excellentquests
engine.Plugin.Name: Quests
engine.Plugin.Prefix: <lyellow><b>Quests</b></lyellow><dgray> » </dgray><gray>
engine.UserData.Cache.CleanUp_Interval: 300
engine.UserData.Cache.LifeTime: 300
engine.UserData.Scheduled_Save_Delay: 1.0
engine.UserData.Scheduled_Save_Interval: 20
engine.UserData.Scheduled_Save_Sync_Pause: 3
menu/battlepass_levels.Content.battle_pass.Item.Display_Name: <blue>Battle Pass</blue>
menu/battlepass_levels.Content.battle_pass.Item.Hide_Components: True
menu/battlepass_levels.Content.battle_pass.Item.Lore: ['<gray>Complete <blue>Daily Quests</blue> to progress</gray>', '<gray>in the <blue>Battle Pass</blue>!</gray>', ' ', '<dark_gray>[Stats]</dark_gray>', '<dark_gray>• <gray>Type: </gray><gold>%battle_pass_type%</gold></dark_gray>', '<dark_gray>• <gray>Level: </gray><gold>%battle_pass_level%</gold></dark_gray>', '<dark_gray>• <gray>Progress: </gray><gold>%battle_pass_xp%</gold>/<gold>%battle_pass_xp_max%</gold></dark_gray>']
menu/battlepass_levels.Content.battle_pass.Item.Material: minecraft:anvil
menu/battlepass_levels.Content.battle_pass.Priority: 10
menu/battlepass_levels.Content.battle_pass.Slots: 37
menu/battlepass_levels.Content.battle_pass.Type: null
menu/battlepass_levels.Content.black_stained_glass_pane.Item.Hide_Tooltip: True
menu/battlepass_levels.Content.black_stained_glass_pane.Item.Lore: []
menu/battlepass_levels.Content.black_stained_glass_pane.Item.Material: minecraft:black_stained_glass_pane
menu/battlepass_levels.Content.black_stained_glass_pane.Priority: -1
menu/battlepass_levels.Content.black_stained_glass_pane.Slots: 0,1,2,3,4,5,6,7,8,36,37,38,39,40,41,42,43,44
menu/battlepass_levels.Content.black_stained_glass_pane.Type: null
menu/battlepass_levels.Content.gray_stained_glass_pane.Item.Hide_Tooltip: True
menu/battlepass_levels.Content.gray_stained_glass_pane.Item.Lore: []
menu/battlepass_levels.Content.gray_stained_glass_pane.Item.Material: minecraft:gray_stained_glass_pane
menu/battlepass_levels.Content.gray_stained_glass_pane.Priority: -1
menu/battlepass_levels.Content.gray_stained_glass_pane.Slots: 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35
menu/battlepass_levels.Content.gray_stained_glass_pane.Type: null
menu/battlepass_levels.Content.page_next.Item.Display_Name: <white><b><u>Next Page</u> →</b></white>
menu/battlepass_levels.Content.page_next.Item.Lore: []
menu/battlepass_levels.Content.page_next.Item.Material: minecraft:arrow
menu/battlepass_levels.Content.page_next.Priority: 10
menu/battlepass_levels.Content.page_next.Slots: 26
menu/battlepass_levels.Content.page_next.Type: page_next
menu/battlepass_levels.Content.page_previous.Item.Display_Name: <white><b>← <u>Previous Page</u></b></white>
menu/battlepass_levels.Content.page_previous.Item.Lore: []
menu/battlepass_levels.Content.page_previous.Item.Material: minecraft:arrow
menu/battlepass_levels.Content.page_previous.Priority: 10
menu/battlepass_levels.Content.page_previous.Slots: 18
menu/battlepass_levels.Content.page_previous.Type: page_previous
menu/battlepass_levels.Content.quests.Item.Display_Name: <green>Daily Quests</green>
menu/battlepass_levels.Content.quests.Item.Lore: ['<green>→ <u>Click to open!</u></green>']
menu/battlepass_levels.Content.quests.Item.Material: minecraft:knowledge_book
menu/battlepass_levels.Content.quests.Priority: 10
menu/battlepass_levels.Content.quests.Slots: 40
menu/battlepass_levels.Content.quests.Type: quests
menu/battlepass_levels.Level.Claimed.Display_Name: <green><b>Level %level%</b></green><gray> • </gray><white>Completed</white>
menu/battlepass_levels.Level.Claimed.Lore: []
menu/battlepass_levels.Level.Claimed.Material: minecraft:lime_stained_glass_pane
menu/battlepass_levels.Level.Locked.Display_Name: <red><b>Level %level%</b></red><gray> • </gray><white>Locked</white>
menu/battlepass_levels.Level.Locked.Lore: []
menu/battlepass_levels.Level.Locked.Material: minecraft:red_stained_glass_pane
menu/battlepass_levels.Level.Upcoming.Display_Name: <yellow><b>Level %level%</b></yellow><gray> • </gray><white>In Progress</white>
menu/battlepass_levels.Level.Upcoming.Lore: ['', '<dark_gray>┃</dark_gray><gray> Level: <white>%battle_pass_level%</white>/<gold>%battle_pass_max_level%</gold></gray>', '<dark_gray>┃</dark_gray><gray> XP: <white>%battle_pass_xp%</white>/<gold>%battle_pass_xp_max%</gold></gray>']
menu/battlepass_levels.Level.Upcoming.Material: minecraft:yellow_stained_glass_pane
menu/battlepass_levels.Reward.Claimed.Display_Name: <gold><b>Claimed Reward</b></gold>
menu/battlepass_levels.Reward.Claimed.Lore: ['%rewards%', '', '<green>✔</green> <dark_gray>You have claimed this reward.</dark_gray>']
menu/battlepass_levels.Reward.Claimed.Material: minecraft:minecart
menu/battlepass_levels.Reward.Locked.Display_Name: <dark_aqua><b>Locked Reward</b></dark_aqua>
menu/battlepass_levels.Reward.Locked.Lore: ['%rewards%', '', '<gray><dark_aqua>➥</dark_aqua> Complete the <dark_aqua>%level%</dark_aqua> level to unlock!</gray>']
menu/battlepass_levels.Reward.Locked.Material: minecraft:structure_void
menu/battlepass_levels.Reward.Premium.Display_Name: <red><b>Premium Reward</b></red>
menu/battlepass_levels.Reward.Premium.Lore: ['%rewards%', '', '<red>➥ Upgrade to <u>Premium</u> to unlock!</red>']
menu/battlepass_levels.Reward.Premium.Material: minecraft:barrier
menu/battlepass_levels.Reward.Unlocked.Display_Name: <gold><b>Reward Available</b></gold>
menu/battlepass_levels.Reward.Unlocked.Lore: ['%rewards%', '', '<gold>→ <u>Click to claim!</u></gold>']
menu/battlepass_levels.Reward.Unlocked.Material: minecraft:chest_minecart
menu/battlepass_levels.Settings.Auto_Refresh: 1
menu/battlepass_levels.Settings.MenuType: minecraft:generic_9x5
menu/battlepass_levels.Settings.PlaceholderAPI.Enabled: False
menu/battlepass_levels.Settings.Title: <black>Season %season_name% • %battle_pass_type%</black>
menu/battlepass_levels.Slots.DefaultRewards: 10,11,12,13,14,15,16
menu/battlepass_levels.Slots.Levels: 19,20,21,22,23,24,25
menu/battlepass_levels.Slots.PremiumRewards: 28,29,30,31,32,33,34
menu/battlepass_levels.Timer.Active.Display_Name: <yellow><b>Season: </b></yellow><white>%season_name%</white> • <green>Active</green>
menu/battlepass_levels.Timer.Active.Lore: ['<gray>Season is running!</gray>', '', '<yellow>➥ Launched: </yellow> <white>%season_start_date%</white>', '<yellow>⏳ Timeleft:</yellow> <white>%season_timeleft%</white>']
menu/battlepass_levels.Timer.Active.Material: minecraft:clock
menu/battlepass_levels.Timer.Ended.Display_Name: <yellow><b>Season: </b></yellow><white>%season_name%</white> • <red>Ended</red>
menu/battlepass_levels.Timer.Ended.Lore: ['<gray>The season is over! Follow us on</gray>', '<gray>discord for further event news!</gray>', '', '<yellow>➥ Launched: </yellow> <white>%season_start_date%</white>', '<yellow>⏳ Finished:</yellow> <white>%season_end_date%</white>']
menu/battlepass_levels.Timer.Ended.Material: minecraft:clock
menu/battlepass_levels.Timer.Scheduled.Display_Name: <yellow><b>Season: </b></yellow><white>%season_name%</white> • <yellow>Scheduled</yellow>
menu/battlepass_levels.Timer.Scheduled.Lore: ['<gray>The new season is coming!</gray>', '', '<yellow>➥ Launch Date:</yellow> <white>%season_start_date%</white>']
menu/battlepass_levels.Timer.Scheduled.Material: minecraft:clock
menu/battlepass_levels.Timer.Slot: 43
menu/milestone_categories.Category.SlotsByCount.1: 22
menu/milestone_categories.Category.SlotsByCount.10: 20,21,22,23,24,29,30,31,32,33
menu/milestone_categories.Category.SlotsByCount.2: 21,23
menu/milestone_categories.Category.SlotsByCount.3: 21,22,23
menu/milestone_categories.Category.SlotsByCount.4: 21,22,24,25
menu/milestone_categories.Category.SlotsByCount.5: 20,21,22,23,24
menu/milestone_categories.Category.SlotsByCount.6: 20,21,22,23,24,31
menu/milestone_categories.Category.SlotsByCount.7: 20,21,22,23,24,30,32
menu/milestone_categories.Category.SlotsByCount.8: 20,21,22,23,24,30,31,32
menu/milestone_categories.Category.SlotsByCount.9: 20,21,22,23,24,29,30,32,33
menu/milestone_categories.Content.black_stained_glass_pane.Item.Hide_Tooltip: True
menu/milestone_categories.Content.black_stained_glass_pane.Item.Lore: []
menu/milestone_categories.Content.black_stained_glass_pane.Item.Material: minecraft:black_stained_glass_pane
menu/milestone_categories.Content.black_stained_glass_pane.Priority: -1
menu/milestone_categories.Content.black_stained_glass_pane.Slots: 0,1,2,3,4,5,6,7,8,36,37,38,39,40,41,42,43,44
menu/milestone_categories.Content.black_stained_glass_pane.Type: null
menu/milestone_categories.Content.gray_stained_glass_pane.Item.Hide_Tooltip: True
menu/milestone_categories.Content.gray_stained_glass_pane.Item.Lore: []
menu/milestone_categories.Content.gray_stained_glass_pane.Item.Material: minecraft:gray_stained_glass_pane
menu/milestone_categories.Content.gray_stained_glass_pane.Priority: -1
menu/milestone_categories.Content.gray_stained_glass_pane.Slots: 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35
menu/milestone_categories.Content.gray_stained_glass_pane.Type: null
menu/milestone_categories.Settings.Auto_Refresh: -1
menu/milestone_categories.Settings.MenuType: minecraft:generic_9x5
menu/milestone_categories.Settings.PlaceholderAPI.Enabled: True
menu/milestone_categories.Settings.Title: <black>Milestone • Categories</black>
menu/milestone_progression.Content.black_stained_glass_pane.Item.Hide_Tooltip: True
menu/milestone_progression.Content.black_stained_glass_pane.Item.Lore: []
menu/milestone_progression.Content.black_stained_glass_pane.Item.Material: minecraft:black_stained_glass_pane
menu/milestone_progression.Content.black_stained_glass_pane.Priority: -1
menu/milestone_progression.Content.black_stained_glass_pane.Slots: 0,1,2,3,4,5,6,7,8,18,19,20,21,22,23,24,25,26
menu/milestone_progression.Content.black_stained_glass_pane.Type: null
menu/milestone_progression.Content.return.Item.Display_Name: <soft_yellow><b>Back</b></soft_yellow>
menu/milestone_progression.Content.return.Item.Lore: []
menu/milestone_progression.Content.return.Item.Material: minecraft:iron_door
menu/milestone_progression.Content.return.Priority: 0
menu/milestone_progression.Content.return.Slots: 22
menu/milestone_progression.Content.return.Type: return
menu/milestone_progression.Level.Completed.Display_Name: <green><b>Level %level%</b></green><gray> • </gray><white>Completed</white>
menu/milestone_progression.Level.Completed.Hide_Components: True
menu/milestone_progression.Level.Completed.Lore: ['<gold>Objectives:</gold>', '%objectives%', '', '<gold>Rewards:</gold>', '%rewards%']
menu/milestone_progression.Level.Completed.Material: minecraft:lime_stained_glass_pane
menu/milestone_progression.Level.InProgress.Display_Name: <yellow><b>Level %level%</b></yellow><gray> • </gray><white>In Progress</white>
menu/milestone_progression.Level.InProgress.Hide_Components: True
menu/milestone_progression.Level.InProgress.Lore: ['<gold>Objectives:</gold>', '%objectives%', '', '<gold>Rewards:</gold>', '%rewards%']
menu/milestone_progression.Level.InProgress.Material: minecraft:yellow_stained_glass_pane
menu/milestone_progression.Level.Locked.Display_Name: <red><b>Level %level%</b></red><gray> • </gray><white>Locked</white>
menu/milestone_progression.Level.Locked.Hide_Components: True
menu/milestone_progression.Level.Locked.Lore: ['<gray>Complete the previous levels to unlock!</gray>']
menu/milestone_progression.Level.Locked.Material: minecraft:red_stained_glass_pane
menu/milestone_progression.Level.Slots: 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26
menu/milestone_progression.Settings.Auto_Refresh: -1
menu/milestone_progression.Settings.MenuType: minecraft:generic_9x3
menu/milestone_progression.Settings.PlaceholderAPI.Enabled: False
menu/milestone_progression.Settings.Title: <black>%milestone_name% • Progression</black>
menu/milestones.Content.black_stained_glass_pane.Item.Hide_Tooltip: True
menu/milestones.Content.black_stained_glass_pane.Item.Lore: []
menu/milestones.Content.black_stained_glass_pane.Item.Material: minecraft:black_stained_glass_pane
menu/milestones.Content.black_stained_glass_pane.Priority: -1
menu/milestones.Content.black_stained_glass_pane.Slots: 0,1,2,3,4,5,6,7,8,36,37,38,39,40,41,42,43,44
menu/milestones.Content.black_stained_glass_pane.Type: null
menu/milestones.Content.gray_stained_glass_pane.Item.Hide_Tooltip: True
menu/milestones.Content.gray_stained_glass_pane.Item.Lore: []
menu/milestones.Content.gray_stained_glass_pane.Item.Material: minecraft:gray_stained_glass_pane
menu/milestones.Content.gray_stained_glass_pane.Priority: -1
menu/milestones.Content.gray_stained_glass_pane.Slots: 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35
menu/milestones.Content.gray_stained_glass_pane.Type: null
menu/milestones.Content.page_next.Item.Display_Name: <white><b><u>Next Page</u> →</b></white>
menu/milestones.Content.page_next.Item.Lore: []
menu/milestones.Content.page_next.Item.Material: minecraft:arrow
menu/milestones.Content.page_next.Priority: 0
menu/milestones.Content.page_next.Slots: 44
menu/milestones.Content.page_next.Type: page_next
menu/milestones.Content.page_previous.Item.Display_Name: <white><b>← <u>Previous Page</u></b></white>
menu/milestones.Content.page_previous.Item.Lore: []
menu/milestones.Content.page_previous.Item.Material: minecraft:arrow
menu/milestones.Content.page_previous.Priority: 0
menu/milestones.Content.page_previous.Slots: 36
menu/milestones.Content.page_previous.Type: page_previous
menu/milestones.Content.return.Item.Display_Name: <soft_yellow><b>Back</b></soft_yellow>
menu/milestones.Content.return.Item.Lore: []
menu/milestones.Content.return.Item.Material: minecraft:iron_door
menu/milestones.Content.return.Priority: 0
menu/milestones.Content.return.Slots: 40
menu/milestones.Content.return.Type: return
menu/milestones.Milestone.Slots: 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35
menu/milestones.Settings.Auto_Refresh: -1
menu/milestones.Settings.MenuType: minecraft:generic_9x5
menu/milestones.Settings.PlaceholderAPI.Enabled: False
menu/milestones.Settings.Title: <black>Milestone • %milestone_category_name%</black>
menu/quests.Content.black_stained_glass_pane.Item.Hide_Tooltip: True
menu/quests.Content.black_stained_glass_pane.Item.Lore: []
menu/quests.Content.black_stained_glass_pane.Item.Material: minecraft:black_stained_glass_pane
menu/quests.Content.black_stained_glass_pane.Priority: -1
menu/quests.Content.black_stained_glass_pane.Slots: 0,1,2,3,4,5,6,7,8,36,37,38,39,40,41,42,43,44
menu/quests.Content.black_stained_glass_pane.Type: null
menu/quests.Content.gray_stained_glass_pane.Item.Hide_Tooltip: True
menu/quests.Content.gray_stained_glass_pane.Item.Lore: []
menu/quests.Content.gray_stained_glass_pane.Item.Material: minecraft:gray_stained_glass_pane
menu/quests.Content.gray_stained_glass_pane.Priority: -1
menu/quests.Content.gray_stained_glass_pane.Slots: 9,10,11,12,13,14,15,16,17,18,19,20,21,22,23,24,25,26,27,28,29,30,31,32,33,34,35
menu/quests.Content.gray_stained_glass_pane.Type: null
menu/quests.Content.quest_timer.Item.Display_Name: <yellow><b>Quest Timer</b></yellow>
menu/quests.Content.quest_timer.Item.Hide_Components: True
menu/quests.Content.quest_timer.Item.Lore: ['<gray>New quests in: <white>%refresh_time%</white></gray>']
menu/quests.Content.quest_timer.Item.Material: minecraft:clock
menu/quests.Content.quest_timer.Priority: 10
menu/quests.Content.quest_timer.Slots: 4
menu/quests.Content.quest_timer.Type: null
menu/quests.Quest.SlotsByCount.1: 22
menu/quests.Quest.SlotsByCount.10: 20,21,22,23,24,29,30,31,32,33
menu/quests.Quest.SlotsByCount.2: 21,23
menu/quests.Quest.SlotsByCount.3: 21,22,23
menu/quests.Quest.SlotsByCount.4: 21,22,24,25
menu/quests.Quest.SlotsByCount.5: 20,21,22,23,24
menu/quests.Quest.SlotsByCount.6: 20,21,22,23,24,31
menu/quests.Quest.SlotsByCount.7: 20,21,22,23,24,30,32
menu/quests.Quest.SlotsByCount.8: 20,21,22,23,24,30,31,32
menu/quests.Quest.SlotsByCount.9: 20,21,22,23,24,29,30,32,33
menu/quests.Settings.Auto_Refresh: 1
menu/quests.Settings.MenuType: minecraft:generic_9x5
menu/quests.Settings.PlaceholderAPI.Enabled: False
menu/quests.Settings.Title: <black>Daily Quests</black>
milestones/farming_beetroot.Category: farming
milestones/farming_beetroot.Description: []
milestones/farming_beetroot.Icon.Lore: []
milestones/farming_beetroot.Icon.Material: minecraft:beetroot
milestones/farming_beetroot.Levels: 9
milestones/farming_beetroot.Name: <lang:"item.minecraft.beetroot">
milestones/farming_beetroot.Objectives.List.minecraft:beetroot: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/farming_beetroot.Rewards.Custom: ['ms_cash_medium']
milestones/farming_beetroot.Type: block_loot
milestones/farming_carrot.Category: farming
milestones/farming_carrot.Description: []
milestones/farming_carrot.Icon.Lore: []
milestones/farming_carrot.Icon.Material: minecraft:carrot
milestones/farming_carrot.Levels: 9
milestones/farming_carrot.Name: <lang:"item.minecraft.carrot">
milestones/farming_carrot.Objectives.List.minecraft:carrot: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/farming_carrot.Rewards.Custom: ['ms_cash_medium']
milestones/farming_carrot.Type: block_loot
milestones/farming_melon_slice.Category: farming
milestones/farming_melon_slice.Description: []
milestones/farming_melon_slice.Icon.Lore: []
milestones/farming_melon_slice.Icon.Material: minecraft:melon_slice
milestones/farming_melon_slice.Levels: 9
milestones/farming_melon_slice.Name: <lang:"item.minecraft.melon_slice">
milestones/farming_melon_slice.Objectives.List.minecraft:melon_slice: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/farming_melon_slice.Rewards.Custom: ['ms_cash_medium']
milestones/farming_melon_slice.Type: block_loot
milestones/farming_nether_wart.Category: farming
milestones/farming_nether_wart.Description: []
milestones/farming_nether_wart.Icon.Lore: []
milestones/farming_nether_wart.Icon.Material: minecraft:nether_wart
milestones/farming_nether_wart.Levels: 9
milestones/farming_nether_wart.Name: <lang:"item.minecraft.nether_wart">
milestones/farming_nether_wart.Objectives.List.minecraft:nether_wart: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/farming_nether_wart.Rewards.Custom: ['ms_cash_medium']
milestones/farming_nether_wart.Type: block_loot
milestones/farming_potato.Category: farming
milestones/farming_potato.Description: []
milestones/farming_potato.Icon.Lore: []
milestones/farming_potato.Icon.Material: minecraft:potato
milestones/farming_potato.Levels: 9
milestones/farming_potato.Name: <lang:"item.minecraft.potato">
milestones/farming_potato.Objectives.List.minecraft:potato: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/farming_potato.Rewards.Custom: ['ms_cash_medium']
milestones/farming_potato.Type: block_loot
milestones/farming_sugar_cane.Category: farming
milestones/farming_sugar_cane.Description: []
milestones/farming_sugar_cane.Icon.Lore: []
milestones/farming_sugar_cane.Icon.Material: minecraft:sugar_cane
milestones/farming_sugar_cane.Levels: 9
milestones/farming_sugar_cane.Name: <lang:"block.minecraft.sugar_cane">
milestones/farming_sugar_cane.Objectives.List.minecraft:sugar_cane: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/farming_sugar_cane.Rewards.Custom: ['ms_cash_medium']
milestones/farming_sugar_cane.Type: block_loot
milestones/farming_wheat.Category: farming
milestones/farming_wheat.Description: []
milestones/farming_wheat.Icon.Lore: []
milestones/farming_wheat.Icon.Material: minecraft:wheat
milestones/farming_wheat.Levels: 9
milestones/farming_wheat.Name: <lang:"item.minecraft.wheat">
milestones/farming_wheat.Objectives.List.minecraft:wheat: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/farming_wheat.Rewards.Custom: ['ms_cash_medium']
milestones/farming_wheat.Type: block_loot
milestones/fishing_cod.Category: fishing
milestones/fishing_cod.Description: []
milestones/fishing_cod.Icon.Lore: []
milestones/fishing_cod.Icon.Material: minecraft:cod
milestones/fishing_cod.Levels: 9
milestones/fishing_cod.Name: <lang:"item.minecraft.cod">
milestones/fishing_cod.Objectives.List.minecraft:cod: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/fishing_cod.Rewards.Custom: ['ms_cash_medium']
milestones/fishing_cod.Type: fish_item
milestones/fishing_pufferfish.Category: fishing
milestones/fishing_pufferfish.Description: []
milestones/fishing_pufferfish.Icon.Lore: []
milestones/fishing_pufferfish.Icon.Material: minecraft:pufferfish
milestones/fishing_pufferfish.Levels: 9
milestones/fishing_pufferfish.Name: <lang:"item.minecraft.pufferfish">
milestones/fishing_pufferfish.Objectives.List.minecraft:pufferfish: 25 50 100 200 450 800 1500 3000 5000
milestones/fishing_pufferfish.Rewards.Custom: ['ms_cash_medium']
milestones/fishing_pufferfish.Type: fish_item
milestones/fishing_salmon.Category: fishing
milestones/fishing_salmon.Description: []
milestones/fishing_salmon.Icon.Lore: []
milestones/fishing_salmon.Icon.Material: minecraft:salmon
milestones/fishing_salmon.Levels: 9
milestones/fishing_salmon.Name: <lang:"item.minecraft.salmon">
milestones/fishing_salmon.Objectives.List.minecraft:salmon: 25 50 100 200 450 800 1500 3000 5000
milestones/fishing_salmon.Rewards.Custom: ['ms_cash_medium']
milestones/fishing_salmon.Type: fish_item
milestones/fishing_tropical_fish.Category: fishing
milestones/fishing_tropical_fish.Description: []
milestones/fishing_tropical_fish.Icon.Lore: []
milestones/fishing_tropical_fish.Icon.Material: minecraft:tropical_fish
milestones/fishing_tropical_fish.Levels: 9
milestones/fishing_tropical_fish.Name: <lang:"item.minecraft.tropical_fish">
milestones/fishing_tropical_fish.Objectives.List.minecraft:tropical_fish: 25 50 100 200 450 800 1500 3000 5000
milestones/fishing_tropical_fish.Rewards.Custom: ['ms_cash_medium']
milestones/fishing_tropical_fish.Type: fish_item
milestones/mining_acacia_log.Category: mining
milestones/mining_acacia_log.Description: []
milestones/mining_acacia_log.Icon.Lore: []
milestones/mining_acacia_log.Icon.Material: minecraft:acacia_log
milestones/mining_acacia_log.Levels: 9
milestones/mining_acacia_log.Name: <lang:"block.minecraft.acacia_log">
milestones/mining_acacia_log.Objectives.List.minecraft:acacia_log: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_acacia_log.Rewards.Custom: ['ms_cash_medium']
milestones/mining_acacia_log.Type: break_block
milestones/mining_andesite.Category: mining
milestones/mining_andesite.Description: []
milestones/mining_andesite.Icon.Lore: []
milestones/mining_andesite.Icon.Material: minecraft:andesite
milestones/mining_andesite.Levels: 9
milestones/mining_andesite.Name: <lang:"block.minecraft.andesite">
milestones/mining_andesite.Objectives.List.minecraft:andesite: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_andesite.Rewards.Custom: ['ms_cash_medium']
milestones/mining_andesite.Type: break_block
milestones/mining_birch_log.Category: mining
milestones/mining_birch_log.Description: []
milestones/mining_birch_log.Icon.Lore: []
milestones/mining_birch_log.Icon.Material: minecraft:birch_log
milestones/mining_birch_log.Levels: 9
milestones/mining_birch_log.Name: <lang:"block.minecraft.birch_log">
milestones/mining_birch_log.Objectives.List.minecraft:birch_log: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_birch_log.Rewards.Custom: ['ms_cash_medium']
milestones/mining_birch_log.Type: break_block
milestones/mining_cherry_log.Category: mining
milestones/mining_cherry_log.Description: []
milestones/mining_cherry_log.Icon.Lore: []
milestones/mining_cherry_log.Icon.Material: minecraft:cherry_log
milestones/mining_cherry_log.Levels: 9
milestones/mining_cherry_log.Name: <lang:"block.minecraft.cherry_log">
milestones/mining_cherry_log.Objectives.List.minecraft:cherry_log: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_cherry_log.Rewards.Custom: ['ms_cash_medium']
milestones/mining_cherry_log.Type: break_block
milestones/mining_dark_oak_log.Category: mining
milestones/mining_dark_oak_log.Description: []
milestones/mining_dark_oak_log.Icon.Lore: []
milestones/mining_dark_oak_log.Icon.Material: minecraft:dark_oak_log
milestones/mining_dark_oak_log.Levels: 9
milestones/mining_dark_oak_log.Name: <lang:"block.minecraft.dark_oak_log">
milestones/mining_dark_oak_log.Objectives.List.minecraft:dark_oak_log: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_dark_oak_log.Rewards.Custom: ['ms_cash_medium']
milestones/mining_dark_oak_log.Type: break_block
milestones/mining_deepslate.Category: mining
milestones/mining_deepslate.Description: []
milestones/mining_deepslate.Icon.Lore: []
milestones/mining_deepslate.Icon.Material: minecraft:deepslate
milestones/mining_deepslate.Levels: 9
milestones/mining_deepslate.Name: <lang:"block.minecraft.deepslate">
milestones/mining_deepslate.Objectives.List.minecraft:deepslate: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_deepslate.Rewards.Custom: ['ms_cash_medium']
milestones/mining_deepslate.Type: break_block
milestones/mining_deepslate_coal_ore.Category: mining
milestones/mining_deepslate_coal_ore.Description: []
milestones/mining_deepslate_coal_ore.Icon.Lore: []
milestones/mining_deepslate_coal_ore.Icon.Material: minecraft:deepslate_coal_ore
milestones/mining_deepslate_coal_ore.Levels: 9
milestones/mining_deepslate_coal_ore.Name: <lang:"block.minecraft.deepslate_coal_ore">
milestones/mining_deepslate_coal_ore.Objectives.List.minecraft:deepslate_coal_ore: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/mining_deepslate_coal_ore.Rewards.Custom: ['ms_cash_medium']
milestones/mining_deepslate_coal_ore.Type: break_block
milestones/mining_deepslate_copper_ore.Category: mining
milestones/mining_deepslate_copper_ore.Description: []
milestones/mining_deepslate_copper_ore.Icon.Lore: []
milestones/mining_deepslate_copper_ore.Icon.Material: minecraft:deepslate_copper_ore
milestones/mining_deepslate_copper_ore.Levels: 9
milestones/mining_deepslate_copper_ore.Name: <lang:"block.minecraft.deepslate_copper_ore">
milestones/mining_deepslate_copper_ore.Objectives.List.minecraft:deepslate_copper_ore: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/mining_deepslate_copper_ore.Rewards.Custom: ['ms_cash_medium']
milestones/mining_deepslate_copper_ore.Type: break_block
milestones/mining_deepslate_diamond_ore.Category: mining
milestones/mining_deepslate_diamond_ore.Description: []
milestones/mining_deepslate_diamond_ore.Icon.Lore: []
milestones/mining_deepslate_diamond_ore.Icon.Material: minecraft:deepslate_diamond_ore
milestones/mining_deepslate_diamond_ore.Levels: 9
milestones/mining_deepslate_diamond_ore.Name: <lang:"block.minecraft.deepslate_diamond_ore">
milestones/mining_deepslate_diamond_ore.Objectives.List.minecraft:deepslate_diamond_ore: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/mining_deepslate_diamond_ore.Rewards.Custom: ['ms_cash_medium']
milestones/mining_deepslate_diamond_ore.Type: break_block
milestones/mining_deepslate_emerald_ore.Category: mining
milestones/mining_deepslate_emerald_ore.Description: []
milestones/mining_deepslate_emerald_ore.Icon.Lore: []
milestones/mining_deepslate_emerald_ore.Icon.Material: minecraft:deepslate_emerald_ore
milestones/mining_deepslate_emerald_ore.Levels: 9
milestones/mining_deepslate_emerald_ore.Name: <lang:"block.minecraft.deepslate_emerald_ore">
milestones/mining_deepslate_emerald_ore.Objectives.List.minecraft:deepslate_emerald_ore: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/mining_deepslate_emerald_ore.Rewards.Custom: ['ms_cash_medium']
milestones/mining_deepslate_emerald_ore.Type: break_block
milestones/mining_deepslate_gold_ore.Category: mining
milestones/mining_deepslate_gold_ore.Description: []
milestones/mining_deepslate_gold_ore.Icon.Lore: []
milestones/mining_deepslate_gold_ore.Icon.Material: minecraft:deepslate_gold_ore
milestones/mining_deepslate_gold_ore.Levels: 9
milestones/mining_deepslate_gold_ore.Name: <lang:"block.minecraft.deepslate_gold_ore">
milestones/mining_deepslate_gold_ore.Objectives.List.minecraft:deepslate_gold_ore: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/mining_deepslate_gold_ore.Rewards.Custom: ['ms_cash_medium']
milestones/mining_deepslate_gold_ore.Type: break_block
milestones/mining_deepslate_iron_ore.Category: mining
milestones/mining_deepslate_iron_ore.Description: []
milestones/mining_deepslate_iron_ore.Icon.Lore: []
milestones/mining_deepslate_iron_ore.Icon.Material: minecraft:deepslate_iron_ore
milestones/mining_deepslate_iron_ore.Levels: 9
milestones/mining_deepslate_iron_ore.Name: <lang:"block.minecraft.deepslate_iron_ore">
milestones/mining_deepslate_iron_ore.Objectives.List.minecraft:deepslate_iron_ore: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/mining_deepslate_iron_ore.Rewards.Custom: ['ms_cash_medium']
milestones/mining_deepslate_iron_ore.Type: break_block
milestones/mining_deepslate_lapis_ore.Category: mining
milestones/mining_deepslate_lapis_ore.Description: []
milestones/mining_deepslate_lapis_ore.Icon.Lore: []
milestones/mining_deepslate_lapis_ore.Icon.Material: minecraft:deepslate_lapis_ore
milestones/mining_deepslate_lapis_ore.Levels: 9
milestones/mining_deepslate_lapis_ore.Name: <lang:"block.minecraft.deepslate_lapis_ore">
milestones/mining_deepslate_lapis_ore.Objectives.List.minecraft:deepslate_lapis_ore: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/mining_deepslate_lapis_ore.Rewards.Custom: ['ms_cash_medium']
milestones/mining_deepslate_lapis_ore.Type: break_block
milestones/mining_deepslate_redstone_ore.Category: mining
milestones/mining_deepslate_redstone_ore.Description: []
milestones/mining_deepslate_redstone_ore.Icon.Lore: []
milestones/mining_deepslate_redstone_ore.Icon.Material: minecraft:deepslate_redstone_ore
milestones/mining_deepslate_redstone_ore.Levels: 9
milestones/mining_deepslate_redstone_ore.Name: <lang:"block.minecraft.deepslate_redstone_ore">
milestones/mining_deepslate_redstone_ore.Objectives.List.minecraft:deepslate_redstone_ore: 100 250 500 1000 2000 4000 7500 10000 20000
milestones/mining_deepslate_redstone_ore.Rewards.Custom: ['ms_cash_medium']
milestones/mining_deepslate_redstone_ore.Type: break_block
milestones/mining_diorite.Category: mining
milestones/mining_diorite.Description: []
milestones/mining_diorite.Icon.Lore: []
milestones/mining_diorite.Icon.Material: minecraft:diorite
milestones/mining_diorite.Levels: 9
milestones/mining_diorite.Name: <lang:"block.minecraft.diorite">
milestones/mining_diorite.Objectives.List.minecraft:diorite: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_diorite.Rewards.Custom: ['ms_cash_medium']
milestones/mining_diorite.Type: break_block
milestones/mining_dirt.Category: mining
milestones/mining_dirt.Description: []
milestones/mining_dirt.Icon.Lore: []
milestones/mining_dirt.Icon.Material: minecraft:dirt
milestones/mining_dirt.Levels: 9
milestones/mining_dirt.Name: <lang:"block.minecraft.dirt">
milestones/mining_dirt.Objectives.List.minecraft:dirt: 1000 2000 3000 5000 7500 10000 12500 15000 20000
milestones/mining_dirt.Rewards.Custom: ['ms_cash_medium']
milestones/mining_dirt.Type: break_block
milestones/mining_granite.Category: mining
milestones/mining_granite.Description: []
milestones/mining_granite.Icon.Lore: []
milestones/mining_granite.Icon.Material: minecraft:granite
milestones/mining_granite.Levels: 9
milestones/mining_granite.Name: <lang:"block.minecraft.granite">
milestones/mining_granite.Objectives.List.minecraft:granite: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_granite.Rewards.Custom: ['ms_cash_medium']
milestones/mining_granite.Type: break_block
milestones/mining_jungle_log.Category: mining
milestones/mining_jungle_log.Description: []
milestones/mining_jungle_log.Icon.Lore: []
milestones/mining_jungle_log.Icon.Material: minecraft:jungle_log
milestones/mining_jungle_log.Levels: 9
milestones/mining_jungle_log.Name: <lang:"block.minecraft.jungle_log">
milestones/mining_jungle_log.Objectives.List.minecraft:jungle_log: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_jungle_log.Rewards.Custom: ['ms_cash_medium']
milestones/mining_jungle_log.Type: break_block
milestones/mining_mangrove_log.Category: mining
milestones/mining_mangrove_log.Description: []
milestones/mining_mangrove_log.Icon.Lore: []
milestones/mining_mangrove_log.Icon.Material: minecraft:mangrove_log
milestones/mining_mangrove_log.Levels: 9
milestones/mining_mangrove_log.Name: <lang:"block.minecraft.mangrove_log">
milestones/mining_mangrove_log.Objectives.List.minecraft:mangrove_log: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_mangrove_log.Rewards.Custom: ['ms_cash_medium']
milestones/mining_mangrove_log.Type: break_block
milestones/mining_oak_log.Category: mining
milestones/mining_oak_log.Description: []
milestones/mining_oak_log.Icon.Lore: []
milestones/mining_oak_log.Icon.Material: minecraft:oak_log
milestones/mining_oak_log.Levels: 9
milestones/mining_oak_log.Name: <lang:"block.minecraft.oak_log">
milestones/mining_oak_log.Objectives.List.minecraft:oak_log: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_oak_log.Rewards.Custom: ['ms_cash_medium']
milestones/mining_oak_log.Type: break_block
milestones/mining_pale_oak_log.Category: mining
milestones/mining_pale_oak_log.Description: []
milestones/mining_pale_oak_log.Icon.Lore: []
milestones/mining_pale_oak_log.Icon.Material: minecraft:pale_oak_log
milestones/mining_pale_oak_log.Levels: 9
milestones/mining_pale_oak_log.Name: <lang:"block.minecraft.pale_oak_log">
milestones/mining_pale_oak_log.Objectives.List.minecraft:pale_oak_log: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_pale_oak_log.Rewards.Custom: ['ms_cash_medium']
milestones/mining_pale_oak_log.Type: break_block
milestones/mining_sand.Category: mining
milestones/mining_sand.Description: []
milestones/mining_sand.Icon.Lore: []
milestones/mining_sand.Icon.Material: minecraft:sand
milestones/mining_sand.Levels: 9
milestones/mining_sand.Name: <lang:"block.minecraft.sand">
milestones/mining_sand.Objectives.List.minecraft:sand: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_sand.Rewards.Custom: ['ms_cash_medium']
milestones/mining_sand.Type: break_block
milestones/mining_spruce_log.Category: mining
milestones/mining_spruce_log.Description: []
milestones/mining_spruce_log.Icon.Lore: []
milestones/mining_spruce_log.Icon.Material: minecraft:spruce_log
milestones/mining_spruce_log.Levels: 9
milestones/mining_spruce_log.Name: <lang:"block.minecraft.spruce_log">
milestones/mining_spruce_log.Objectives.List.minecraft:spruce_log: 500 1250 2000 3500 5000 7500 10000 12500 15000
milestones/mining_spruce_log.Rewards.Custom: ['ms_cash_medium']
milestones/mining_spruce_log.Type: break_block
milestones/mining_stone.Category: mining
milestones/mining_stone.Description: []
milestones/mining_stone.Icon.Lore: []
milestones/mining_stone.Icon.Material: minecraft:stone
milestones/mining_stone.Levels: 9
milestones/mining_stone.Name: <lang:"block.minecraft.stone">
milestones/mining_stone.Objectives.List.minecraft:stone: 1000 2000 3000 5000 7500 10000 12500 15000 20000
milestones/mining_stone.Rewards.Custom: ['ms_cash_medium']
milestones/mining_stone.Type: break_block
rewards.Rewards.bp_cash_high.Commands: ['money give %player_name% %amount%']
rewards.Rewards.bp_cash_high.Name: $%amount%
rewards.Rewards.bp_cash_high.Variables.amount.Base: 1500.0
rewards.Rewards.bp_cash_high.Variables.amount.LevelBonus: []
rewards.Rewards.bp_cash_high.Variables.amount.UnitBonus: 0.0
rewards.Rewards.bp_cash_low.Commands: ['money give %player_name% %amount%']
rewards.Rewards.bp_cash_low.Name: $%amount%
rewards.Rewards.bp_cash_low.Variables.amount.Base: 300.0
rewards.Rewards.bp_cash_low.Variables.amount.LevelBonus: []
rewards.Rewards.bp_cash_low.Variables.amount.UnitBonus: 0.0
rewards.Rewards.bp_cash_medium.Commands: ['money give %player_name% %amount%']
rewards.Rewards.bp_cash_medium.Name: $%amount%
rewards.Rewards.bp_cash_medium.Variables.amount.Base: 750.0
rewards.Rewards.bp_cash_medium.Variables.amount.LevelBonus: []
rewards.Rewards.bp_cash_medium.Variables.amount.UnitBonus: 0.0
rewards.Rewards.bp_diamonds.Commands: ['give %player_name% diamond 3']
rewards.Rewards.bp_diamonds.Name: <aqua>3x Diamonds</aqua>
rewards.Rewards.bp_gold_ingots.Commands: ['give %player_name% gold_ingot 8']
rewards.Rewards.bp_gold_ingots.Name: <yellow>8x Gold Ingots</yellow>
rewards.Rewards.ms_cash_high.Commands: ['money give %player_name% %amount%']
rewards.Rewards.ms_cash_high.Name: $%amount%
rewards.Rewards.ms_cash_high.Variables.amount.Base: 0.0
rewards.Rewards.ms_cash_high.Variables.amount.LevelBonus: [1000.0, 1500.0, 2750.0, 4500.0, 7000.0, 10000.0, 15000.0, 20000.0, 25000.0]
rewards.Rewards.ms_cash_high.Variables.amount.UnitBonus: 0.0
rewards.Rewards.ms_cash_low.Commands: ['money give %player_name% %amount%']
rewards.Rewards.ms_cash_low.Name: $%amount%
rewards.Rewards.ms_cash_low.Variables.amount.Base: 0.0
rewards.Rewards.ms_cash_low.Variables.amount.LevelBonus: [150.0, 300.0, 500.0, 750.0, 1500.0, 3000.0, 5000.0, 7500.0, 10000.0]
rewards.Rewards.ms_cash_low.Variables.amount.UnitBonus: 0.0
rewards.Rewards.ms_cash_medium.Commands: ['money give %player_name% %amount%']
rewards.Rewards.ms_cash_medium.Name: $%amount%
rewards.Rewards.ms_cash_medium.Variables.amount.Base: 0.0
rewards.Rewards.ms_cash_medium.Variables.amount.LevelBonus: [500.0, 750.0, 1000.0, 1500.0, 3000.0, 5000.0, 7500.0, 10000.0, 15000.0]
rewards.Rewards.ms_cash_medium.Variables.amount.UnitBonus: 0.0
rewards.Rewards.quest_cash_high.Commands: ['money give %player_name% %amount%']
rewards.Rewards.quest_cash_high.Name: $%amount%
rewards.Rewards.quest_cash_high.Variables.amount.Base: 1000.0
rewards.Rewards.quest_cash_high.Variables.amount.LevelBonus: []
rewards.Rewards.quest_cash_high.Variables.amount.UnitBonus: 7.5
rewards.Rewards.quest_cash_low.Commands: ['money give %player_name% %amount%']
rewards.Rewards.quest_cash_low.Name: $%amount%
rewards.Rewards.quest_cash_low.Variables.amount.Base: 250.0
rewards.Rewards.quest_cash_low.Variables.amount.LevelBonus: []
rewards.Rewards.quest_cash_low.Variables.amount.UnitBonus: 3.5
rewards.Rewards.quest_cash_medium.Commands: ['money give %player_name% %amount%']
rewards.Rewards.quest_cash_medium.Name: $%amount%
rewards.Rewards.quest_cash_medium.Variables.amount.Base: 500.0
rewards.Rewards.quest_cash_medium.Variables.amount.LevelBonus: []
rewards.Rewards.quest_cash_medium.Variables.amount.UnitBonus: 5.0
```
