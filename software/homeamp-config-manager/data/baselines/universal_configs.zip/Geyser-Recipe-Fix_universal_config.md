# Geyser-Recipe-Fix - Universal Configuration

These settings are **identical across all applicable Paper 1.21.8 servers** that use this plugin.

## General

`debug` = false

## Anvil

`anvil.forward` = true

`anvil.mode` = "ENABLED"

## Smithing

`smithing.mode` = "ENABLED"

